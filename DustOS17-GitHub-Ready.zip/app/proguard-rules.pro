# Accessibility service and receivers are referenced from the manifest, R8 keeps them automatically.
-keepclassmembers class team.deltax.dustos.core.** { *; }
