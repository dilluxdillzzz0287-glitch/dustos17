package team.deltax.dustos.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs

class MiniJsonTests {
    @Test fun parsesNestedStructures() {
        val v = MiniJson.parse("""{"a":[1,2.5,-3e2],"b":{"c":"x\"yA","d":true,"e":null},"f":[]}""").asMap()!!
        assertEquals(listOf(1.0, 2.5, -300.0), v["a"].asList())
        val b = v["b"].asMap()!!
        assertEquals("x\"yA", b["c"])
        assertEquals(true, b["d"])
        assertTrue(b.containsKey("e") && b["e"] == null)
        assertEquals(emptyList<Any?>(), v["f"].asList())
    }

    @Test fun rejectsGarbage() {
        for (bad in listOf("{", "[1,", "{\"a\" 1}", "{} x", "tru", "")) {
            try { MiniJson.parse(bad); fail("should reject: $bad") } catch (e: IllegalArgumentException) { }
        }
    }
}

class WeatherTests {
    private val sample = """
      {"latitude":11.25,"longitude":75.77,"timezone":"Asia/Kolkata",
       "current":{"time":"2026-11-08T15:45","temperature_2m":28.1,"relative_humidity_2m":70,"apparent_temperature":31.2,
                  "is_day":1,"weather_code":2,"wind_speed_10m":9.4,"wind_direction_10m":240},
       "daily":{"time":["2026-11-08","2026-11-09"],"weather_code":[2,61],"temperature_2m_max":[31.0,29.5],
                "temperature_2m_min":[24.0,23.1],"sunrise":["2026-11-08T06:20","2026-11-09T06:21"],
                "sunset":["2026-11-08T17:55","2026-11-09T17:54"]}}"""

    @Test fun parsesForecast() {
        val w = WeatherParser.parseForecast(sample, 123L)!!
        assertEquals(28.1, w.tempC, 1e-9)
        assertEquals(31.2, w.feelsC, 1e-9)
        assertEquals(70, w.humidity)
        assertEquals(240, w.windDirDeg)
        assertTrue(w.isDay)
        assertEquals(2, w.code)
        assertEquals(2, w.daily.size)
        assertEquals("06:20", w.today!!.sunrise)
        assertEquals("17:55", w.today!!.sunset)
        assertEquals(61, w.daily[1].code)
        assertEquals(123L, w.fetchedAtMs)
    }

    @Test fun badPayloadsReturnNull() {
        assertNull(WeatherParser.parseForecast("not json", 0))
        assertNull(WeatherParser.parseForecast("""{"current":{}}""", 0))
        assertNull(WeatherParser.parseForecast("""{"hello":1}""", 0))
    }

    @Test fun parsesGeocoding() {
        val r = WeatherParser.parseGeocode("""{"results":[{"name":"Kozhikode","admin1":"Kerala","country":"India","latitude":11.248,"longitude":75.78},{"name":"bad"}]}""")
        assertEquals(1, r.size)
        assertEquals("Kozhikode, Kerala, India", r[0].label)
        assertTrue(WeatherParser.parseGeocode("{}").isEmpty())
        assertTrue(WeatherParser.parseGeocode("oops").isEmpty())
    }

    @Test fun codesMapToKinds() {
        assertEquals(WeatherKind.CLEAR, WeatherCodes.kind(0))
        assertEquals(WeatherKind.PARTLY_CLOUDY, WeatherCodes.kind(2))
        assertEquals(WeatherKind.FOG, WeatherCodes.kind(45))
        assertEquals(WeatherKind.DRIZZLE, WeatherCodes.kind(53))
        assertEquals(WeatherKind.RAIN, WeatherCodes.kind(63))
        assertEquals(WeatherKind.RAIN, WeatherCodes.kind(81))
        assertEquals(WeatherKind.SNOW, WeatherCodes.kind(75))
        assertEquals(WeatherKind.STORM, WeatherCodes.kind(96))
        assertEquals("Partly cloudy", WeatherCodes.text(2))
    }

    @Test fun urlsAreWellFormed() {
        assertTrue(WeatherParser.url(11.25, 75.77).startsWith("https://api.open-meteo.com/v1/forecast?latitude=11.25&longitude=75.77"))
        assertTrue(WeatherParser.geocodeUrl("New York").contains("name=New+York"))
    }
}

class FormatTests {
    @Test fun temperatureAndWind() {
        assertEquals("0°", Units.temp(0.0, false))
        assertEquals("32°", Units.temp(0.0, true))
        assertEquals("82°", Units.temp(28.0, true))
        assertEquals("-5°", Units.temp(-5.2, false))
        assertEquals("9 km/h", Units.wind(9.4, false))
        assertEquals("6 mph", Units.wind(9.4, true))
    }

    @Test fun compassPoints() {
        assertEquals("N", Units.compass(0)); assertEquals("N", Units.compass(350)); assertEquals("NE", Units.compass(45))
        assertEquals("E", Units.compass(90)); assertEquals("S", Units.compass(180)); assertEquals("W", Units.compass(260))
        assertEquals("W", Units.compass(270)); assertEquals("N", Units.compass(-10))
    }

    @Test fun bytesAndPercent() {
        assertEquals("512 B", Units.humanBytes(512))
        assertEquals("1.5 GB", Units.humanBytes(1536L * 1024 * 1024))
        assertEquals("512 MB", Units.humanBytes(512L * 1024 * 1024))
        assertEquals("1.0 KB", Units.humanBytes(1024))
        assertEquals(50, Units.percent(1, 2)); assertEquals(0, Units.percent(5, 0)); assertEquals(100, Units.percent(9, 3))
    }

    @Test fun clockText() {
        assertEquals("12:05 AM", ClockMath.timeText(0, 5, 9, false, false, true))
        assertEquals("12:00 PM", ClockMath.timeText(12, 0, 0, false, false, true))
        assertEquals("1:05 PM", ClockMath.timeText(13, 5, 9, false, false, true))
        assertEquals("13:05:09", ClockMath.timeText(13, 5, 9, true, true, true))
        assertEquals("07:05", ClockMath.timeText(7, 5, 0, true, false, true))
        assertEquals("7:05", ClockMath.timeText(7, 5, 0, false, false, false))
    }

    @Test fun clockAngles() {
        assertEquals(90f, ClockMath.hourAngle(3, 0, 0), 1e-4f)
        assertEquals(15f, ClockMath.hourAngle(12, 30, 0), 1e-4f)
        assertEquals(180f, ClockMath.minuteAngle(30, 0), 1e-4f)
        assertEquals(6f, ClockMath.secondAngle(1), 1e-4f)
    }

    @Test fun dates() {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")); cal.clear(); cal.set(2026, Calendar.NOVEMBER, 8)
        assertEquals("Sunday, 8 November", ClockMath.dateText(cal, Locale.ENGLISH, true, true))
        assertEquals("Sunday", ClockMath.dateText(cal, Locale.ENGLISH, true, false))
        assertEquals("8 November", ClockMath.dateText(cal, Locale.ENGLISH, false, true))
        assertEquals("", ClockMath.dateText(cal, Locale.ENGLISH, false, false))
        assertEquals("Sun", ClockMath.weekdayShort("2026-11-08", Locale.ENGLISH))
        assertEquals("6:20 AM", ClockMath.reformatHhmm("06:20", false))
        assertEquals("17:55", ClockMath.reformatHhmm("17:55", true))
    }

    @Test fun cpuLoad() {
        val a = CpuMath.parseProcStat("cpu  100 0 100 700 100 0 0 0 0 0\ncpu0 1 1 1 1")!!
        val b = CpuMath.parseProcStat("cpu  200 0 200 800 100 0 0 0 0 0")!!
        assertEquals(800L, a.idle); assertEquals(1000L, a.total)
        assertEquals(0.667f, CpuMath.load(a, b)!!, 0.01f)
        assertNull(CpuMath.load(a, a)); assertNull(CpuMath.parseProcStat("garbage"))
    }
}

class OseeParserTests {
    private fun p(s: String) = OseeParser.parse(s)

    @Test fun opensApps() {
        assertEquals(OseeAction.OpenApp("netflix"), p("Open Netflix"))
        assertEquals(OseeAction.OpenApp("youtube"), p("hey osee, open YouTube please"))
        assertEquals(OseeAction.OpenApp("prime video"), p("launch the Prime Video app"))
        assertEquals(OseeAction.OpenApp("netflix"), p("can you open netflix"))
        assertEquals(OseeAction.OpenApp("netflix"), p("Netflix"))
        assertEquals(OseeAction.OpenApp("disney plus"), p("open Disney+"))
    }

    @Test fun navigates() {
        assertEquals(OseeAction.Navigate(Section.GAMES), p("go to games"))
        assertEquals(OseeAction.Navigate(Section.APPS), p("show me apps"))
        assertEquals(OseeAction.Navigate(Section.SETTINGS), p("open settings"))
        assertEquals(OseeAction.Navigate(Section.HOME), p("go home"))
        assertEquals(OseeAction.OpenSystem(SystemTarget.WIFI), p("open wi-fi settings"))
        assertEquals(OseeAction.OpenSystem(SystemTarget.DISPLAY), p("open display settings"))
        assertEquals(OseeAction.OpenSystem(SystemTarget.BLUETOOTH), p("open bluetooth"))
        assertEquals(OseeAction.OpenSystem(SystemTarget.APP_MANAGER), p("manage apps".let { "open $it" }))
    }

    @Test fun answersInfoQuestions() {
        assertEquals(OseeAction.ShowTime, p("what time is it"))
        assertEquals(OseeAction.ShowTime, p("what's the time"))
        assertEquals(OseeAction.ShowDate, p("what day is it today"))
        assertEquals(OseeAction.ShowDate, p("what's today's date"))
        assertEquals(OseeAction.ShowWeather, p("what's the weather like"))
        assertEquals(OseeAction.ShowWeather, p("how hot is it"))
        assertEquals(OseeAction.ShowMemory, p("how much RAM is free"))
        assertEquals(OseeAction.ShowStorage, p("how much storage is left"))
        assertEquals(OseeAction.StartScreensaver, p("start screensaver"))
    }

    @Test fun searches() {
        assertEquals(OseeAction.Search("cats", "youtube", false), p("search for cats on youtube"))
        assertEquals(OseeAction.Search("lofi beats", "spotify", true), p("play lofi beats on spotify"))
        assertEquals(OseeAction.Search("cooking", "youtube", false), p("search youtube for cooking"))
        assertEquals(OseeAction.Search("pizza", null, false), p("search the web for pizza"))
        assertEquals(OseeAction.Search("dune part two", null, false), p("find dune part two"))
        assertEquals(OseeAction.ShowWeather, p("find out the weather"))
    }

    @Test fun controlsOptionsAndVolume() {
        assertEquals(OseeAction.SetOption(LauncherOption.CLOCK_24H, true), p("turn on 24 hour clock"))
        assertEquals(OseeAction.SetOption(LauncherOption.CLOCK_24H, false), p("use 12 hour clock"))
        assertEquals(OseeAction.SetOption(LauncherOption.ANIMATIONS, false), p("turn off animations"))
        assertEquals(OseeAction.SetOption(LauncherOption.WEATHER_CARD, false), p("hide the weather widget"))
        assertEquals(OseeAction.SetOption(LauncherOption.CLOCK_SECONDS, true), p("show seconds"))
        assertEquals(OseeAction.SetOption(LauncherOption.SYSTEM_WIDGET, true), p("show system widget"))
        assertEquals(OseeAction.Volume(VolumeCmd.UP), p("volume up"))
        assertEquals(OseeAction.Volume(VolumeCmd.DOWN), p("turn it down"))
        assertEquals(OseeAction.Volume(VolumeCmd.UNMUTE), p("unmute"))
        assertEquals(OseeAction.Volume(VolumeCmd.MUTE), p("mute"))
    }

    @Test fun conversationAndFallbacks() {
        assertEquals(OseeAction.Close, p("never mind"))
        assertEquals(OseeAction.Greeting, p("hello"))
        assertEquals(OseeAction.Greeting, p("hey osee"))
        assertEquals(OseeAction.Thanks, p("thank you"))
        assertEquals(OseeAction.WhoAreYou, p("who are you"))
        assertEquals(OseeAction.Help, p("what can you do"))
        assertEquals(OseeAction.Help, p("open"))
        assertEquals(OseeAction.Empty, p("  ?! "))
        assertTrue(p("why is the sky blue") is OseeAction.General)
        assertTrue(p("my favourite colour is a deep ocean blue") is OseeAction.General)
    }
}

class AppMatcherTests {
    private val labels = listOf("YouTube", "Netflix", "Prime Video", "Disney+ Hotstar", "Spotify", "Apple TV", "Settings", "Silk Browser")

    @Test fun matchesCommonNames() {
        assertEquals(0, AppMatcher.best("you tube", labels))
        assertEquals(0, AppMatcher.best("yt", labels))
        assertEquals(1, AppMatcher.best("net flix", labels))
        assertEquals(2, AppMatcher.best("prime", labels))
        assertEquals(3, AppMatcher.best("hotstar", labels))
        assertEquals(3, AppMatcher.best("disney plus", labels))
        assertEquals(4, AppMatcher.best("spotifi", labels))
        assertEquals(5, AppMatcher.best("tv", labels))
        assertEquals(7, AppMatcher.best("silk", labels))
    }

    @Test fun refusesUnknownNames() {
        assertNull(AppMatcher.best("zzz quantum", labels))
        assertNull(AppMatcher.best("", labels))
        assertNull(AppMatcher.best("netflix", emptyList()))
    }

    @Test fun levenshtein() {
        assertEquals(0, AppMatcher.levenshtein("abc", "abc")); assertEquals(3, AppMatcher.levenshtein("abc", "")); assertEquals(1, AppMatcher.levenshtein("abc", "abd"))
        assertEquals(3, AppMatcher.levenshtein("kitten", "sitting"))
    }
}

class WallpaperTests {
    @Test fun rendersDeterministicNonFlatImages() {
        for (spec in Wallpapers.all) {
            val a = WallpaperRenderer.render(spec, 96, 54)
            val b = WallpaperRenderer.render(spec, 96, 54)
            assertEquals(96 * 54, a.size)
            assertTrue("deterministic ${spec.id}", a.contentEquals(b))
            assertTrue("opaque ${spec.id}", a.all { (it ushr 24) == 0xFF })
            assertTrue("not flat ${spec.id}", a.distinct().size > 200)
        }
    }

    @Test fun themeLookups() {
        assertEquals("violet_flow", Wallpapers.themeById("aurora").wallpaperId)
        assertEquals("violet_flow", Wallpapers.byId("nope").id)
        for (t in Wallpapers.themes) assertNotNull(Wallpapers.all.firstOrNull { it.id == t.wallpaperId })
        assertEquals(Wallpapers.all.size, Wallpapers.all.map { it.id }.toSet().size)
    }

    @Test fun blurKeepsFlatColoursAndSmoothsEdges() {
        val flat = IntArray(40 * 30) { 0xFF336699.toInt() }
        assertTrue(BoxBlur.blur(flat, 40, 30, 5).all { it == 0xFF336699.toInt() })
        val dot = IntArray(41 * 31) { 0xFF000000.toInt() }
        for (yy in 13..17) for (xx in 18..22) dot[yy * 41 + xx] = 0xFFFFFFFF.toInt()
        val out = BoxBlur.blur(dot, 41, 31, 3, 2)
        assertNotEquals(0xFFFFFFFF.toInt(), out[15 * 41 + 20])
        assertTrue((out[15 * 41 + 25] and 255) > 0)
        val sumIn = dot.sumOf { (it and 255).toLong() }; val sumOut = out.sumOf { (it and 255).toLong() }
        assertTrue("energy roughly preserved", kotlin.math.abs(sumIn - sumOut) < sumIn / 10)
        assertEquals(dot.toList(), BoxBlur.blur(dot, 41, 31, 0).toList())
    }
}

class MathAnswerTests {
    private fun spoken(s: String) = MathAnswer.answer(s)?.spoken
    private fun shown(s: String) = MathAnswer.answer(s)?.display

    @Test fun basicArithmetic() {
        assertEquals("The answer is 96", spoken("what is 12 times 8"))
        assertEquals("The answer is 4", spoken("2 + 2"))
        assertEquals("The answer is 2.5", spoken("10 divided by 4"))
        assertEquals("The answer is -3", spoken("5 minus 8"))
        assertEquals("The answer is 20", spoken("calculate (2+3)*4"))
        assertEquals("The answer is 14", spoken("2 plus 3 times 4"))
        assertEquals("The answer is 15", spoken("what's 5 x 3"))
        assertEquals("The answer is 7", spoken("three plus four"))
    }

    @Test fun percentages() {
        assertEquals("The answer is 30", spoken("what is 15 percent of 200"))
        assertEquals("The answer is 12.5", spoken("25% of 50"))
    }

    @Test fun displayUsesProperSymbols() {
        assertEquals("12 × 8 = 96", shown("12 times 8"))
        assertEquals("9 ÷ 3 = 3", shown("9 / 3"))
    }

    @Test fun dividingByZeroIsReportedNotComputed() {
        val r = MathAnswer.answer("what is 5 divided by 0")!!
        assertTrue(r.display.contains("zero"))
        assertTrue(r.spoken.contains("zero"))
    }

    @Test fun nonMathIsLeftAlone() {
        assertNull(MathAnswer.answer("what is the weather"))
        assertNull(MathAnswer.answer("what is 42"))
        assertNull(MathAnswer.answer("who is the president"))
        assertNull(MathAnswer.answer("2026 11 09"))
        assertNull(MathAnswer.answer("5 + "))
        assertNull(MathAnswer.answer("(2 + 3"))
    }
}

class OseeTextTests {
    private val snap = WeatherParser.parseForecast(
        """{"current":{"temperature_2m":28.1,"relative_humidity_2m":70,"apparent_temperature":31.2,"is_day":1,"weather_code":2,
            "wind_speed_10m":9.4,"wind_direction_10m":240},
           "daily":{"time":["2026-11-08"],"weather_code":[2],"temperature_2m_max":[31.0],"temperature_2m_min":[24.0],
                    "sunrise":["2026-11-08T06:20"],"sunset":["2026-11-08T17:55"]}}""",
        1L,
    )!!

    @Test fun weatherSentence() {
        val s = OseeText.weather(snap, "Kozhikode, Kerala, India", false, false)
        assertTrue(s, s.startsWith("It's 28° and partly cloudy in Kozhikode."))
        assertTrue(s, s.contains("humidity 70 percent"))
        assertTrue(s, s.contains("wind 9 km/h from the SW"))
        assertTrue(s, s.contains("high is 31° and the low is 24°"))
        assertTrue(!s.contains("last saved"))
        assertTrue(OseeText.weather(snap, "", true, true).contains("last saved update"))
        assertTrue(OseeText.weather(snap, "", true, false).startsWith("It's 83° "))
    }

    @Test fun memorySentenceNeverClaimsToFreeAnything() {
        val s = OseeText.memory(2_000_000_000L, 500_000_000L, true)
        assertTrue(s, s.contains("75 percent in use"))
        assertTrue(s, s.contains("Android says memory is low"))
        assertTrue(s, s.contains("don't clear it"))
        assertTrue(!s.lowercase().contains("freed"))
        assertTrue(!s.lowercase().contains("cleaned"))
    }

    @Test fun storageAndTimeAndDate() {
        assertEquals("I couldn't read the storage size on this device.", OseeText.storage(0, 0))
        assertTrue(OseeText.storage(8_000_000_000L, 2_000_000_000L).contains("75 percent used"))
        assertEquals("It's 7:42 PM.", OseeText.time(19, 42, false))
        assertEquals("It's 19:42.", OseeText.time(19, 42, true))
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { clear(); set(2026, Calendar.NOVEMBER, 9) }
        assertEquals("Today is Monday, 9 November.", OseeText.date(cal, Locale.US))
    }

    @Test fun greetingFollowsTheHour() {
        assertTrue(OseeText.greeting(8).startsWith("Good morning!"))
        assertTrue(OseeText.greeting(14).startsWith("Good afternoon!"))
        assertTrue(OseeText.greeting(19).startsWith("Good evening!"))
        assertTrue(OseeText.greeting(2).startsWith("Hello!"))
    }

    @Test fun everyExampleIsUnderstoodByTheParser() {
        for (e in OseeText.EXAMPLES) {
            val a = OseeParser.parse(e)
            assertTrue("\"$e\" parsed as $a", a !is OseeAction.General && a !is OseeAction.Empty && a !is OseeAction.Help)
        }
    }
}

class SceneArtTests {
    @Test fun everyCatalogSceneExists() {
        for (s in SceneCatalog.all) assertEquals(s.id, SceneArt.byId(s.id).id)
    }

    @Test fun unknownSceneFallsBackToPeaks() {
        assertEquals("peaks", SceneArt.byId("nope").id)
        assertEquals("peaks", SceneArt.byId("").id)
    }

    @Test fun skyDataIsConsistent() {
        for (s in SceneCatalog.all) {
            val scene = SceneArt.byId(s.id)
            assertEquals(scene.sky.size, scene.skyStops.size)
            assertEquals(0f, scene.skyStops.first(), 0f)
            assertEquals(1f, scene.skyStops.last(), 0f)
            for (i in 1 until scene.skyStops.size) assertTrue(scene.skyStops[i] > scene.skyStops[i - 1])
        }
    }

    @Test fun everyLayerRendersWithTheRightSizeAndVisiblePixels() {
        val w = 240
        val h = 135
        for (info in SceneCatalog.all) {
            val scene = SceneArt.byId(info.id)
            assertTrue(scene.layers.isNotEmpty())
            for (l in scene.layers) {
                for (depth in listOf(0f, 1f)) {
                    val px = SceneArt.render(scene, l, depth, w, h)
                    assertEquals(w * SceneArt.bandHeight(l, h), px.size)
                    assertTrue("${info.id} z=${l.z} depth=$depth is empty", px.any { (it ushr 24) > 0 })
                }
            }
        }
    }

    @Test fun ridgesWrapWithoutASeam() {
        for (info in SceneCatalog.all) {
            val scene = SceneArt.byId(info.id)
            for (l in scene.layers) {
                if (l.kind != LayerKind.RIDGE && l.kind != LayerKind.PEAKS) continue
                assertEquals("${info.id} z=${l.z}", SceneArt.ridgeHeight(l, 0f), SceneArt.ridgeHeight(l, 1f), 1e-4f)
            }
        }
    }

    @Test fun ridgeBandsHaveAnEmptyTopRow() {
        val w = 240
        val h = 135
        for (info in SceneCatalog.all) {
            val scene = SceneArt.byId(info.id)
            for (l in scene.layers) {
                if (l.kind != LayerKind.RIDGE && l.kind != LayerKind.PEAKS) continue
                val px = SceneArt.render(scene, l, 0.5f, w, h)
                for (x in 0 until w) assertEquals("${info.id} z=${l.z} x=$x", 0, px[x] ushr 24)
            }
        }
    }

    @Test fun depthPullsFarLayersTowardsTheHaze() {
        val scene = SceneArt.byId("peaks")
        val far = scene.layers.filter { it.kind == LayerKind.PEAKS }.minByOrNull { it.z }!!
        fun dist(px: IntArray): Int {
            val c = px.last { (it ushr 24) > 200 }
            val dr = (c shr 16 and 255) - (scene.haze shr 16 and 255)
            val dg = (c shr 8 and 255) - (scene.haze shr 8 and 255)
            val db = (c and 255) - (scene.haze and 255)
            return abs(dr) + abs(dg) + abs(db)
        }
        val flat = dist(SceneArt.render(scene, far, 0f, 240, 135))
        val deep = dist(SceneArt.render(scene, far, 1f, 240, 135))
        assertTrue("flat=$flat deep=$deep", deep < flat)
    }

    @Test fun nearestLayerIgnoresDepthFade() {
        val scene = SceneArt.byId("peaks")
        val near = scene.layers.maxByOrNull { it.z }!!
        val a = SceneArt.render(scene, near, 0f, 120, 68)
        val b = SceneArt.render(scene, near, 1f, 120, 68)
        assertTrue(a.contentEquals(b))
    }

    @Test fun everySceneHasSomethingInFrontOfTheClock() {
        for (info in SceneCatalog.all) {
            val scene = SceneArt.byId(info.id)
            val front = scene.layers.any { it.z > scene.clockZ } || scene.bodies.any { it.z > scene.clockZ }
            assertTrue("${info.id} has nothing in front of the clock", front)
        }
    }

    @Test fun buildingsFillTheWholeWidth() {
        val scene = SceneArt.byId("city")
        val l = scene.layers.first { it.kind == LayerKind.BUILDINGS && it.z > 0.7f }
        val px = SceneArt.render(scene, l, 0.5f, 240, 135)
        val bh = SceneArt.bandHeight(l, 135)
        // the bottom row is solid building from the left edge to the right edge
        for (x in 0 until 240) assertTrue("x=$x", (px[(bh - 1) * 240 + x] ushr 24) > 0)
    }
}
