package team.deltax.dustos.launcher

import android.app.Activity
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import team.deltax.dustos.MainActivity

/**
 * Everything the platform officially allows for "be the Home app". None of it is silent: Android and Fire OS decide
 * whether DustOS becomes the default, and the helpers below only ask, report the real state, or open the right page.
 */
object LauncherControl {
    private fun homeIntent() = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)

    /** Package currently answering the Home button, or the system chooser ("android") when none is chosen. */
    fun currentHomePackage(ctx: Context): String? = try {
        ctx.packageManager.resolveActivity(homeIntent(), PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
    } catch (e: Exception) {
        null
    }

    fun isDefaultHome(ctx: Context): Boolean = currentHomePackage(ctx) == ctx.packageName

    /** Other launchers installed on the device, such as Fire TV's own. Used by the Home Guard. */
    fun otherHomePackages(ctx: Context): Set<String> = try {
        ctx.packageManager.queryIntentActivities(homeIntent(), 0).map { it.activityInfo.packageName }.toSet() - ctx.packageName
    } catch (e: Exception) {
        emptySet()
    }

    /** Android 10+ role request. Returns true if the system dialog was shown. Fire OS may not offer it. */
    fun requestDefaultHome(activity: Activity, requestCode: Int = 7017): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val rm = activity.getSystemService(Context.ROLE_SERVICE) as RoleManager
            if (!rm.isRoleAvailable(RoleManager.ROLE_HOME) || rm.isRoleHeld(RoleManager.ROLE_HOME)) return false
            @Suppress("DEPRECATION")
            activity.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), requestCode)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** "Default apps > Home app" page. Many Fire OS builds do not have it. */
    fun openHomeSettings(ctx: Context): Boolean {
        for (action in listOf(Settings.ACTION_HOME_SETTINGS, Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) {
            try {
                ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            } catch (e: Exception) {
                // next
            }
        }
        return false
    }

    /** "Display over other apps". Lets the boot receiver and Home Guard open DustOS from the background on Android 10+. */
    fun overlayGranted(ctx: Context): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    fun openOverlaySettings(ctx: Context): Boolean = try {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    /** True when the user has switched the Home Guard accessibility service on. */
    fun guardEnabled(ctx: Context): Boolean {
        val mine = ComponentName(ctx, LauncherGuardService::class.java)
        val enabled = try { Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) } catch (e: Exception) { null }
        if (enabled.isNullOrEmpty()) return false
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == mine }
    }

    /**
     * Fire OS often has no list of third party accessibility services. If the user grants DustOS this one permission
     * over ADB, the app can switch its own Home Guard on and off. Without it, [setGuardEnabled] does nothing.
     */
    fun canWriteSecure(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    /** Adds or removes only DustOS's own entry, keeping every other accessibility service the user has. */
    fun setGuardEnabled(ctx: Context, on: Boolean): Boolean {
        if (!canWriteSecure(ctx)) return false
        return try {
            val mine = ComponentName(ctx, LauncherGuardService::class.java)
            val cr = ctx.contentResolver
            val current = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            val parts = current.split(':').filter { it.isNotBlank() }.toMutableList()
            parts.removeAll { ComponentName.unflattenFromString(it) == mine }
            if (on) parts.add(mine.flattenToString())
            Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, parts.joinToString(":"))
            if (on) Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openAccessibilitySettings(ctx: Context): Boolean = try {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    /**
     * True when the system lets a background component (boot receiver, Home Guard) open a screen. Android 9 and older
     * always do; Android 10 and newer need "Display over other apps".
     */
    fun canStartFromBackground(ctx: Context): Boolean = Build.VERSION.SDK_INT < 29 || overlayGranted(ctx)

    /**
     * Brings the launcher to the front as if Home had been pressed (home page, no dialogs). On Android 10+ the system
     * ignores this from the background unless overlay permission is granted.
     */
    fun bringToFront(ctx: Context): Boolean = try {
        ctx.startActivity(
            Intent(ctx, MainActivity::class.java)
                .setAction(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
        true
    } catch (e: Exception) {
        false
    }
}
