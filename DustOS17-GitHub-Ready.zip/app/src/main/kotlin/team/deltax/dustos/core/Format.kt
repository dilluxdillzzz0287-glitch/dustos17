package team.deltax.dustos.core

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

object Units {
    fun cToF(c: Double): Double = c * 9.0 / 5.0 + 32.0
    fun kmhToMph(kmh: Double): Double = kmh * 0.621371

    fun temp(c: Double, fahrenheit: Boolean): String {
        val v = if (fahrenheit) cToF(c) else c
        return "${v.roundToInt()}°"
    }

    fun wind(kmh: Double, imperial: Boolean): String =
        if (imperial) "${kmhToMph(kmh).roundToInt()} mph" else "${kmh.roundToInt()} km/h"

    private val points = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    fun compass(deg: Int): String = points[(((deg % 360) + 360) % 360 + 22) / 45 % 8]

    fun humanBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = bytes.toDouble()
        var i = -1
        do {
            v /= 1024.0
            i++
        } while (v >= 1024.0 && i < units.lastIndex)
        return if (v >= 100.0) "${v.roundToInt()} ${units[i]}" else String.format(Locale.US, "%.1f %s", v, units[i])
    }

    fun percent(part: Long, whole: Long): Int =
        if (whole <= 0L) 0 else ((part.toDouble() / whole.toDouble()) * 100.0).roundToInt().coerceIn(0, 100)
}

object ClockMath {
    fun hour12(h: Int): Int = if (h % 12 == 0) 12 else h % 12
    fun two(n: Int): String = n.toString().padStart(2, '0')
    fun amPm(hour: Int): String = if (hour < 12) "AM" else "PM"
    fun hourText(hour: Int, is24: Boolean): String = if (is24) two(hour) else hour12(hour).toString()

    fun timeText(hour: Int, minute: Int, second: Int, is24: Boolean, showSeconds: Boolean, showAmPm: Boolean): String {
        val sb = StringBuilder(hourText(hour, is24)).append(':').append(two(minute))
        if (showSeconds) sb.append(':').append(two(second))
        if (!is24 && showAmPm) sb.append(' ').append(amPm(hour))
        return sb.toString()
    }

    /** Degrees clockwise from 12 o'clock. */
    fun hourAngle(h: Int, m: Int, s: Int): Float = ((h % 12) + m / 60f + s / 3600f) * 30f
    fun minuteAngle(m: Int, s: Int): Float = (m + s / 60f) * 6f
    fun secondAngle(s: Int, millis: Int = 0): Float = (s + millis / 1000f) * 6f

    fun dateText(cal: Calendar, locale: Locale, weekday: Boolean, date: Boolean): String {
        val pattern = when {
            weekday && date -> "EEEE, d MMMM"
            weekday -> "EEEE"
            date -> "d MMMM"
            else -> return ""
        }
        val f = SimpleDateFormat(pattern, locale)
        f.timeZone = cal.timeZone
        return f.format(cal.time)
    }

    /** "06:20" (24h text from the weather API) to the user's format. */
    fun reformatHhmm(hhmm: String, is24: Boolean): String {
        val parts = hhmm.split(':')
        val h = parts.getOrNull(0)?.toIntOrNull() ?: return hhmm
        val m = parts.getOrNull(1)?.toIntOrNull() ?: return hhmm
        return timeText(h, m, 0, is24, false, true)
    }

    /** "2026-11-08" to "Sun". */
    fun weekdayShort(dateIso: String, locale: Locale): String {
        val p = dateIso.split('-')
        val y = p.getOrNull(0)?.toIntOrNull() ?: return dateIso
        val mo = p.getOrNull(1)?.toIntOrNull() ?: return dateIso
        val d = p.getOrNull(2)?.toIntOrNull() ?: return dateIso
        val c = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        c.clear()
        c.set(y, mo - 1, d)
        val f = SimpleDateFormat("EEE", locale)
        f.timeZone = java.util.TimeZone.getTimeZone("UTC")
        return f.format(c.time)
    }
}

data class CpuTimes(val idle: Long, val total: Long)

object CpuMath {
    fun parseProcStat(text: String): CpuTimes? {
        val line = text.lineSequence().firstOrNull { it.startsWith("cpu ") } ?: return null
        val p = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (p.size < 4) return null
        val idle = p[3] + (p.getOrNull(4) ?: 0L)
        return CpuTimes(idle, p.take(8).sum())
    }

    /** 0..1 busy fraction between two samples, or null when no time elapsed. */
    fun load(prev: CpuTimes, cur: CpuTimes): Float? {
        val dt = cur.total - prev.total
        if (dt <= 0L) return null
        val di = cur.idle - prev.idle
        return ((dt - di).toFloat() / dt.toFloat()).coerceIn(0f, 1f)
    }
}
