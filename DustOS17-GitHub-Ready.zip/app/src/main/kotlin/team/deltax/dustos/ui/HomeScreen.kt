package team.deltax.dustos.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.Section

private class Rec(val title: String, val subtitle: String, val glyph: Glyph, val tint: Color, val onClick: () -> Unit)

/** Width of the card column on the right of the banner. */
private const val ColumnWidth = 370
private const val WeatherHeight = 134
private const val OseeHeight = 102
private const val ColumnGap = 14

/**
 * Home: featured banner with the weather, OSee and RAM cards beside it, then favourites, recently used, recommended
 * and installed apps. "Recommended" is built from what is on this device (apps you use, OSee shortcuts, launcher
 * tips). Fire OS does not give launchers access to other apps' content feeds, so there is no streaming catalogue here.
 */
@Composable
fun HomeScreen(vm: DustViewModel, firstFocus: FocusRequester) {
    val p = vm.prefs
    val pal = LocalPalette.current
    val favs = vm.favoriteEntries
    val recents = vm.recentEntries

    val recs = buildList {
        if (p.oseeEnabled) {
            add(Rec("Ask OSee", "“What’s the weather?”", Glyph.SPARK, pal.accent2) { vm.oseeQuery = "what's the weather"; vm.oseeVisible = true })
        }
        recents.firstOrNull()?.let { app ->
            add(Rec("Continue in ${app.label}", "Opened most recently", Glyph.PLAY, pal.accent) { vm.launch(app) })
        }
        add(Rec("Check your memory", "Real RAM and storage numbers", Glyph.INFO, Color(0xFF35E0B0)) { vm.systemDetail = true })
        add(Rec("Depth clock screensaver", "Preview the layered scenery", Glyph.MOON, Color(0xFF2DA8FF)) { vm.screensaverPreview = true })
        add(Rec("Make it yours", "Themes, wallpaper and glass", Glyph.SETTINGS, Color(0xFFFF9A3D)) { vm.settingsPage = "appearance"; vm.section = Section.SETTINGS })
        add(Rec("Clock styles", "Five designs, digital or analog", Glyph.CLOCK, Color(0xFFE0489F)) { vm.settingsPage = "clock"; vm.section = Section.SETTINGS })
    }

    val sysInColumn = p.sysEnabled && p.sysPos != 2
    val sysHeight = when (p.sysSize) { 0 -> 104; 1 -> 250; else -> 430 }
    val parts = buildList {
        if (p.wxEnabled) add(WeatherHeight)
        if (p.oseeEnabled) add(OseeHeight)
        if (sysInColumn) add(sysHeight)
    }
    val showColumn = parts.isNotEmpty()
    val columnHeight = if (showColumn) parts.sum() + ColumnGap * (parts.size - 1) else 0
    val topHeight = maxOf(340, columnHeight)

    val scroll = rememberScrollState()
    var handledHome by rememberSaveable { mutableStateOf(vm.homeTick) }
    LaunchedEffect(vm.homeTick) {
        if (vm.homeTick != handledHome) {
            handledHome = vm.homeTick
            scroll.animateScrollTo(0)
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
        if (p.showHero || showColumn) {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(30.dp)) {
                if (p.showHero) Hero(vm, firstFocus, Modifier.weight(1f).height(topHeight.dp))
                if (showColumn) {
                    Column(Modifier.width(ColumnWidth.dp), verticalArrangement = Arrangement.spacedBy(ColumnGap.dp)) {
                        if (sysInColumn && p.sysPos == 1) SystemWidget(vm, Modifier.fillMaxWidth())
                        if (p.wxEnabled) WeatherCard(vm, Modifier.fillMaxWidth())
                        if (p.oseeEnabled) OseeCard(vm, Modifier.fillMaxWidth())
                        if (sysInColumn && p.sysPos == 0) SystemWidget(vm, Modifier.fillMaxWidth())
                    }
                }
            }
        }
        if (p.sysEnabled && p.sysPos == 2) {
            VSpace(18)
            SystemWidget(vm, Modifier.fillMaxWidth(), wide = true)
        }

        if (p.showFavorites) {
            if (favs.isEmpty()) {
                Shelf("Favourites", listOf(0), rowHeight = 154.dp) {
                    SuggestionCard("Add your favourites", "Hold Select on any app and choose Add to Favourites", Glyph.STAR, pal.accent, onClick = {
                        vm.section = Section.APPS
                    })
                }
            } else {
                Shelf("Favourites", favs, rowHeight = 126.dp, hint = "Hold Select to edit", key = { it.pkg }) { app ->
                    IconTile(app, vm, Modifier.size(175.dp, 126.dp))
                }
            }
        }
        if (p.showRecents && recents.isNotEmpty()) {
            Shelf("Recently used", recents, rowHeight = 154.dp, gap = 21.dp, key = { it.pkg }) { app -> AppTile(app, vm, 352.dp, 154.dp) }
        }
        if (p.showRecommended) {
            Shelf("Recommended", recs, rowHeight = 154.dp, gap = 21.dp) { r -> SuggestionCard(r.title, r.subtitle, r.glyph, r.tint, onClick = r.onClick) }
        }
        if (p.showInstalled) {
            val all = vm.visibleApps
            if (all.isNotEmpty()) {
                Shelf("Installed apps", all, rowHeight = 126.dp, hint = "${all.size} apps", key = { it.pkg }) { app ->
                    IconTile(app, vm, Modifier.size(175.dp, 126.dp))
                }
            }
        }
        VSpace(90)
    }
}
