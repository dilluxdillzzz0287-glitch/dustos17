package team.deltax.dustos.core

enum class WeatherKind { CLEAR, PARTLY_CLOUDY, CLOUDY, FOG, DRIZZLE, RAIN, SNOW, STORM }

data class DailyForecast(
    val dateIso: String,
    val code: Int,
    val maxC: Double,
    val minC: Double,
    val sunrise: String,
    val sunset: String,
)

data class WeatherSnapshot(
    val tempC: Double,
    val feelsC: Double,
    val humidity: Int,
    val windKmh: Double,
    val windDirDeg: Int,
    val code: Int,
    val isDay: Boolean,
    val daily: List<DailyForecast>,
    val fetchedAtMs: Long,
) {
    val today: DailyForecast? get() = daily.firstOrNull()
}

data class GeoPlace(val name: String, val region: String, val country: String, val lat: Double, val lon: Double) {
    val label: String
        get() = listOf(name, region, country).filter { it.isNotBlank() }.distinct().joinToString(", ")
}

object WeatherCodes {
    /** WMO weather interpretation codes as used by Open-Meteo. */
    fun kind(code: Int): WeatherKind = when (code) {
        0, 1 -> WeatherKind.CLEAR
        2 -> WeatherKind.PARTLY_CLOUDY
        3 -> WeatherKind.CLOUDY
        45, 48 -> WeatherKind.FOG
        in 51..57 -> WeatherKind.DRIZZLE
        in 61..67, in 80..82 -> WeatherKind.RAIN
        in 71..77, 85, 86 -> WeatherKind.SNOW
        in 95..99 -> WeatherKind.STORM
        else -> WeatherKind.CLOUDY
    }

    fun text(code: Int): String = when (code) {
        0 -> "Clear sky"
        1 -> "Mainly clear"
        2 -> "Partly cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        51, 53, 55 -> "Drizzle"
        56, 57 -> "Freezing drizzle"
        61 -> "Light rain"
        63 -> "Rain"
        65 -> "Heavy rain"
        66, 67 -> "Freezing rain"
        71 -> "Light snow"
        73 -> "Snow"
        75 -> "Heavy snow"
        77 -> "Snow grains"
        80 -> "Light showers"
        81 -> "Rain showers"
        82 -> "Violent showers"
        85, 86 -> "Snow showers"
        95 -> "Thunderstorm"
        96, 99 -> "Thunderstorm with hail"
        else -> "Cloudy"
    }
}

object WeatherParser {
    fun url(lat: Double, lon: Double): String =
        "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset" +
            "&timezone=auto&forecast_days=5"

    fun geocodeUrl(query: String): String =
        "https://geocoding-api.open-meteo.com/v1/search?name=" +
            java.net.URLEncoder.encode(query.trim(), "UTF-8") + "&count=6&language=en&format=json"

    fun parseForecast(json: String, nowMs: Long): WeatherSnapshot? {
        return try {
            val root = MiniJson.parse(json).asMap() ?: return null
            val cur = root["current"].asMap() ?: return null
            val daily = root["daily"].asMap()
            val days = ArrayList<DailyForecast>()
            if (daily != null) {
                val times = daily["time"].asList() ?: emptyList()
                val codes = daily["weather_code"].asList()
                val maxs = daily["temperature_2m_max"].asList()
                val mins = daily["temperature_2m_min"].asList()
                val rises = daily["sunrise"].asList()
                val sets = daily["sunset"].asList()
                for (i in times.indices) {
                    days.add(
                        DailyForecast(
                            dateIso = times[i] as? String ?: "",
                            code = codes?.getOrNull(i).asDouble()?.toInt() ?: 3,
                            maxC = maxs?.getOrNull(i).asDouble() ?: 0.0,
                            minC = mins?.getOrNull(i).asDouble() ?: 0.0,
                            sunrise = (rises?.getOrNull(i) as? String ?: "").substringAfter('T', ""),
                            sunset = (sets?.getOrNull(i) as? String ?: "").substringAfter('T', ""),
                        )
                    )
                }
            }
            WeatherSnapshot(
                tempC = cur["temperature_2m"].asDouble() ?: return null,
                feelsC = cur["apparent_temperature"].asDouble() ?: cur["temperature_2m"].asDouble() ?: 0.0,
                humidity = cur["relative_humidity_2m"].asDouble()?.toInt() ?: 0,
                windKmh = cur["wind_speed_10m"].asDouble() ?: 0.0,
                windDirDeg = cur["wind_direction_10m"].asDouble()?.toInt() ?: 0,
                code = cur["weather_code"].asDouble()?.toInt() ?: 3,
                isDay = (cur["is_day"].asDouble() ?: 1.0) >= 0.5,
                daily = days,
                fetchedAtMs = nowMs,
            )
        } catch (e: Exception) {
            null
        }
    }

    fun parseGeocode(json: String): List<GeoPlace> {
        return try {
            val results = MiniJson.parse(json).asMap()?.get("results").asList() ?: return emptyList()
            results.mapNotNull { r ->
                val m = r.asMap() ?: return@mapNotNull null
                GeoPlace(
                    name = m["name"] as? String ?: return@mapNotNull null,
                    region = m["admin1"] as? String ?: "",
                    country = m["country"] as? String ?: "",
                    lat = m["latitude"].asDouble() ?: return@mapNotNull null,
                    lon = m["longitude"].asDouble() ?: return@mapNotNull null,
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
