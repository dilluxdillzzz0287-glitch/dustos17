package team.deltax.dustos.data

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.util.LruCache
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppEntry(
    val pkg: String,
    val label: String,
    val component: ComponentName,
    val gameByDefault: Boolean,
    val isSystem: Boolean,
    val tvApp: Boolean,
)

/** Package names of well known TV apps, used only to seed the first favourites row. */
val KnownTvApps = listOf(
    "com.google.android.youtube.tv", "com.amazon.firetv.youtube", "com.netflix.ninja", "com.amazon.amazonvideo.livingroom",
    "in.startv.hotstar", "com.disney.disneyplus", "com.spotify.tv.android", "com.apple.atve.amazon.appletv",
    "com.jio.media.stb.ondemand", "com.plexapp.android", "org.xbmc.kodi", "com.amazon.cloud9",
)

class AppRepository(private val ctx: Context) {
    private val pm = ctx.packageManager

    /** Blocking, call from a background thread. */
    fun scan(): List<AppEntry> {
        val seen = LinkedHashMap<String, AppEntry>()
        fun collect(category: String, tv: Boolean) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val ai = ri.activityInfo ?: continue
                val pkg = ai.packageName
                if (pkg == ctx.packageName || seen.containsKey(pkg)) continue
                val app = ai.applicationInfo
                val flags = app?.flags ?: 0
                val system = (flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                seen[pkg] = AppEntry(pkg, ri.loadLabel(pm).toString(), ComponentName(pkg, ai.name), detectGame(app), system, tv)
            }
        }
        collect(Intent.CATEGORY_LEANBACK_LAUNCHER, true)
        collect(Intent.CATEGORY_LAUNCHER, false)
        return seen.values.sortedBy { it.label.lowercase() }
    }

    @Suppress("DEPRECATION")
    private fun detectGame(ai: ApplicationInfo?): Boolean {
        if (ai == null) return false
        if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) return true
        return (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    }

    fun launchIntent(e: AppEntry): Intent =
        Intent(Intent.ACTION_MAIN)
            .addCategory(if (e.tvApp) Intent.CATEGORY_LEANBACK_LAUNCHER else Intent.CATEGORY_LAUNCHER)
            .setComponent(e.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)

    /** Opens the app. Returns false if Android refused. */
    fun launch(e: AppEntry): Boolean = try {
        ctx.startActivity(launchIntent(e)); true
    } catch (ex: Exception) {
        false
    }

    fun appInfoIntent(pkg: String): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Asks Android to show its own uninstall confirmation. DustOS never removes anything silently. */
    fun uninstallIntent(pkg: String): Intent =
        Intent(Intent.ACTION_DELETE, Uri.fromParts("package", pkg, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}

/** Small LRU of app banners and icons, capped so a 1 GB Fire TV Stick never feels it. */
class IconCache(ctx: Context) {
    private val pm = ctx.packageManager
    private val cap = (Runtime.getRuntime().maxMemory() / 12L).coerceAtMost(20L * 1024 * 1024).toInt()
    private val cache = object : LruCache<String, ImageBitmap>(cap) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }

    fun peek(e: AppEntry, banner: Boolean): ImageBitmap? = synchronized(cache) { cache.get(key(e, banner)) }

    private val tints = HashMap<String, Color>()

    fun peekTint(e: AppEntry): Color? = synchronized(tints) { tints[e.pkg] }

    /** The colour an app's icon is mostly made of. Tiles are tinted with it, so each app gets its own coloured glass. */
    suspend fun tint(e: AppEntry): Color? {
        peekTint(e)?.let { return it }
        val icon = load(e, false) ?: return null
        return withContext(Dispatchers.Default) {
            val c = averageColor(icon)
            synchronized(tints) { tints[e.pkg] = c }
            c
        }
    }

    private fun averageColor(img: ImageBitmap): Color {
        val src = img.asAndroidBitmap()
        val n = 12
        val small = Bitmap.createScaledBitmap(src, n, n, true)
        var r = 0.0
        var g = 0.0
        var b = 0.0
        var total = 0.0
        for (y in 0 until n) for (x in 0 until n) {
            val p = small.getPixel(x, y)
            val a = (p ushr 24) / 255.0
            if (a < 0.2) continue
            val pr = ((p shr 16) and 255) / 255.0
            val pg = ((p shr 8) and 255) / 255.0
            val pb = (p and 255) / 255.0
            val hi = maxOf(pr, pg, pb)
            val lo = minOf(pr, pg, pb)
            val sat = if (hi <= 0.0) 0.0 else (hi - lo) / hi
            val w = a * (0.6 + 0.4 * sat)
            r += pr * w
            g += pg * w
            b += pb * w
            total += w
        }
        if (small !== src) small.recycle()
        if (total <= 0.0) return Color(0xFF3A3F6A)
        return Color((r / total).toFloat(), (g / total).toFloat(), (b / total).toFloat(), 1f)
    }

    suspend fun load(e: AppEntry, banner: Boolean): ImageBitmap? {
        peek(e, banner)?.let { return it }
        return withContext(Dispatchers.IO) {
            val bmp = render(e, banner)
            if (bmp != null) synchronized(cache) { cache.put(key(e, banner), bmp) }
            bmp
        }
    }

    private fun key(e: AppEntry, banner: Boolean) = e.pkg + if (banner) "#b" else "#i"

    private fun render(e: AppEntry, banner: Boolean): ImageBitmap? {
        return try {
            val d: Drawable? = if (banner) {
                pm.getActivityBanner(e.component) ?: pm.getApplicationBanner(e.pkg)
            } else {
                pm.getActivityIcon(e.component)
            }
            val src = d ?: if (banner) null else pm.getApplicationIcon(e.pkg)
            src?.toBitmap(if (banner) 320 else 192, if (banner) 180 else 192, Bitmap.Config.ARGB_8888)?.asImageBitmap()
        } catch (ex: Exception) {
            null
        }
    }
}

/** "Recently used" across the whole device. Needs Usage access, which the user grants in system settings. */
object UsageRecents {
    fun hasAccess(ctx: Context): Boolean = try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        ops.checkOpNoThrow("android:get_usage_stats", Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) {
        false
    }

    @Suppress("DEPRECATION")
    fun recentPackages(ctx: Context, days: Int = 3): List<String> {
        if (!hasAccess(ctx)) return emptyList()
        return try {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val events = usm.queryEvents(now - days * 24L * 3600_000L, now)
            val ev = UsageEvents.Event()
            val last = HashMap<String, Long>()
            while (events.hasNextEvent()) {
                events.getNextEvent(ev)
                if (ev.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last[ev.packageName] = ev.timeStamp
            }
            last.entries.sortedByDescending { it.value }.map { it.key }
        } catch (e: Exception) {
            emptyList()
        }
    }
}

/** Opens Android's own settings pages. Fire OS hides some of them, so every target has fallbacks. */
object SystemIntents {
    fun appManager() = listOf(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS, Settings.ACTION_APPLICATION_SETTINGS, Settings.ACTION_SETTINGS)
    fun wifi() = listOf(Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS, Settings.ACTION_SETTINGS)
    fun display() = listOf(Settings.ACTION_DISPLAY_SETTINGS, Settings.ACTION_SETTINGS)
    fun sound() = listOf("android.settings.SOUND_SETTINGS", Settings.ACTION_SETTINGS)
    fun bluetooth() = listOf(Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_SETTINGS)
    fun all() = listOf(Settings.ACTION_SETTINGS)
    fun usageAccess() = listOf(Settings.ACTION_USAGE_ACCESS_SETTINGS, Settings.ACTION_SETTINGS)

    /** Tries each action in order. Returns true when one opened. */
    fun open(ctx: Context, actions: List<String>): Boolean {
        for (a in actions) {
            try {
                ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            } catch (e: ActivityNotFoundException) {
                // try the next one
            } catch (e: SecurityException) {
                // try the next one
            }
        }
        return false
    }
}
