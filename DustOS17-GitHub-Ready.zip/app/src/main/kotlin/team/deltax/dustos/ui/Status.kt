package team.deltax.dustos.ui

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

enum class NetKind { WIFI, ETHERNET, OTHER, NONE }

data class NetState(val kind: NetKind, val level: Int)

/** Live connectivity. Uses a network callback, so there is no polling while nothing changes. */
@Composable
fun rememberNetState(): State<NetState> {
    val ctx = LocalContext.current
    val state = remember { mutableStateOf(readNet(ctx)) }
    DisposableEffect(ctx) {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { state.value = readNet(ctx) }
            override fun onLost(network: Network) { state.value = readNet(ctx) }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { state.value = readNet(ctx) }
        }
        try { cm?.registerNetworkCallback(NetworkRequest.Builder().build(), cb) } catch (e: Exception) { }
        onDispose { try { cm?.unregisterNetworkCallback(cb) } catch (e: Exception) { } }
    }
    return state
}

@Suppress("DEPRECATION")
private fun readNet(ctx: Context): NetState {
    return try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetworkInfo
        if (net == null || !net.isConnected) return NetState(NetKind.NONE, 0)
        when (net.type) {
            ConnectivityManager.TYPE_WIFI -> {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val rssi = wm.connectionInfo?.rssi ?: -60
                NetState(NetKind.WIFI, WifiManager.calculateSignalLevel(rssi, 4).coerceIn(0, 3).coerceAtLeast(1))
            }
            ConnectivityManager.TYPE_ETHERNET -> NetState(NetKind.ETHERNET, 3)
            else -> NetState(NetKind.OTHER, 3)
        }
    } catch (e: Exception) {
        NetState(NetKind.NONE, 0)
    }
}

/** Wi-Fi / Ethernet / offline glyph, plus a red dot while the microphone is live. */
@Composable
fun StatusIcons(micLive: Boolean, modifier: Modifier = Modifier) {
    val net by rememberNetState()
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        if (micLive) {
            GlyphIcon(Glyph.MIC, Modifier.size(30.dp), tint = androidx.compose.ui.graphics.Color(0xFFFF5A6E))
            HSpace(10)
        }
        when (net.kind) {
            NetKind.WIFI -> GlyphIcon(Glyph.WIFI, Modifier.size(34.dp), level = net.level)
            NetKind.ETHERNET, NetKind.OTHER -> GlyphIcon(Glyph.ETHERNET, Modifier.size(34.dp))
            NetKind.NONE -> GlyphIcon(Glyph.OFFLINE, Modifier.size(34.dp))
        }
    }
}
