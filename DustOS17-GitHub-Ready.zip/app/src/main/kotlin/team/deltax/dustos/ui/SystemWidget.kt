package team.deltax.dustos.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.Units
import team.deltax.dustos.data.ProcUse
import team.deltax.dustos.data.SystemIntents
import team.deltax.dustos.data.SystemSnapshot
import kotlin.math.roundToInt

private class StatLine(val label: String, val value: String, val frac: Float?, val color: Color)

private val Amber = Color(0xFFFFB84D)
private val Rose = Color(0xFFFF5A6E)

private fun ramColor(pct: Int, low: Boolean, accent: Color): Color = when {
    low || pct >= 90 -> Rose
    pct >= 75 -> Amber
    else -> accent
}

@Composable
private fun RamGauge(pct: Int, low: Boolean, diameter: Dp) {
    val pal = LocalPalette.current
    val motion = LocalMotion.current
    val animated by animateFloatAsState(
        targetValue = pct / 100f,
        animationSpec = motion.spec(spring(dampingRatio = 0.70f, stiffness = 90f)),
        label = "ramGauge",
    )
    val color = ramColor(pct, low, pal.accent)
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = this.size.minDimension * 0.095f
            val arc = Size(this.size.width - sw, this.size.height - sw)
            drawArc(Color.White.copy(alpha = 0.14f), 135f, 270f, false, Offset(sw / 2f, sw / 2f), arc, style = Stroke(sw, cap = StrokeCap.Round))
            if (animated > 0.004f) drawArc(color, 135f, 270f * animated, false, Offset(sw / 2f, sw / 2f), arc, style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Txt("${(animated * 100f).roundToInt()}%", size = (diameter.value * 0.25f).sp, weight = FontWeight.Medium)
            if (diameter.value >= 90f) Txt("RAM", size = (diameter.value * 0.11f).sp, color = pal.textDim)
        }
    }
}

private fun lines(vm: DustViewModel, s: SystemSnapshot, accent: Color): List<StatLine> {
    val p = vm.prefs
    val out = ArrayList<StatLine>()
    if (p.sysRam) out.add(StatLine("Memory", "${Units.humanBytes(s.ramUsed)} / ${Units.humanBytes(s.ramTotal)}", s.ramPct / 100f, ramColor(s.ramPct, s.ramLow, accent)))
    if (p.sysCpu) {
        val c = s.cpu
        out.add(
            StatLine(
                "CPU",
                when {
                    c != null -> "${(c * 100f).roundToInt()}%"
                    !vm.stats.cpuReadable -> "Not available"
                    else -> "Measuring…"
                },
                c, accent,
            )
        )
    }
    if (p.sysStorage && s.storageTotal > 0) out.add(StatLine("Storage", "${Units.humanBytes(s.storageFree)} free", s.storagePct / 100f, accent))
    if (p.sysTemp) {
        val t = s.thermal ?: s.batteryTempC?.let { "%.1f°C".format(java.util.Locale.US, it) }
        if (t != null) out.add(StatLine("Temperature", t, null, accent))
    }
    if (p.sysBattery && s.batteryPct != null) out.add(StatLine("Battery", "${s.batteryPct}%" + if (s.charging) " charging" else "", s.batteryPct / 100f, accent))
    return out
}

@Composable
private fun RefreshButton(onClick: () -> Unit, modifier: Modifier) {
    Box(
        modifier.size(46.dp).tvFocus(CircleShape, onClick = onClick, scale = 1.15f).glass(CircleShape, 1.5f),
        contentAlignment = Alignment.Center,
    ) { GlyphIcon(Glyph.REFRESH, Modifier.size(26.dp)) }
}

@Composable
private fun MemoryText(s: SystemSnapshot, big: Boolean) {
    val pal = LocalPalette.current
    Column {
        Txt("${Units.humanBytes(s.ramAvail)} free", size = if (big) 32.sp else 26.sp, weight = FontWeight.Medium)
        Txt("of ${Units.humanBytes(s.ramTotal)} · ${s.ramPct}% used", size = if (big) 20.sp else 18.sp, color = pal.textDim)
        if (s.ramLow) Txt("Android is short on memory", size = 17.sp, color = Rose)
    }
}

@Composable
private fun NoStats() {
    Txt("No statistics selected. Turn some on in Settings > System widget.", size = 19.sp, color = LocalPalette.current.textDim, maxLines = 3)
}

/** The card that fits the 370 wide right column: small is one line of gauge and text, medium adds bars, large shows everything. */
@Composable
private fun CompactSystem(vm: DustViewModel, s: SystemSnapshot, size: Int) {
    val p = vm.prefs
    val pal = LocalPalette.current
    val others = lines(vm, s, pal.accent).filter { it.label != "Memory" }
    if (size == 0) {
        Row(Modifier.fillMaxSize().padding(start = 18.dp, end = 74.dp), verticalAlignment = Alignment.CenterVertically) {
            if (p.sysRam) {
                RamGauge(s.ramPct, s.ramLow, 74.dp)
                HSpace(16)
                MemoryText(s, big = false)
            } else {
                val first = others.firstOrNull()
                if (first == null) NoStats() else Column {
                    Txt(first.label, size = 19.sp, color = pal.textDim)
                    Txt(first.value, size = 25.sp, weight = FontWeight.Medium)
                }
            }
        }
        return
    }
    val big = size == 2
    val bars = if (big) others else if (p.sysDetailed) others.take(2) else emptyList()
    val gauge = if (big) 128.dp else if (bars.isEmpty()) 124.dp else 92.dp
    Column(Modifier.fillMaxSize().padding(start = 22.dp, end = 22.dp, top = 12.dp, bottom = 12.dp)) {
        Txt("System", size = 20.sp, color = pal.textDim, modifier = Modifier.height(36.dp).padding(top = 6.dp))
        if (p.sysRam) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                RamGauge(s.ramPct, s.ramLow, gauge)
                HSpace(16)
                MemoryText(s, big = bars.isEmpty())
            }
        }
        if (bars.isNotEmpty()) {
            if (p.sysRam) VSpace(4)
            for (l in bars) StatBar(l.label, l.value, l.frac, l.color)
        } else if (!p.sysRam) {
            val all = others
            if (all.isEmpty()) NoStats() else for (l in all) StatBar(l.label, l.value, l.frac, l.color)
        }
    }
}

/** The same widget laid out across the whole content width, for the "Own row" position. */
@Composable
private fun WideSystem(vm: DustViewModel, s: SystemSnapshot, size: Int, height: Dp) {
    val p = vm.prefs
    val pal = LocalPalette.current
    val others = lines(vm, s, pal.accent).filter { it.label != "Memory" }
    val cols = when (size) {
        0 -> emptyList()
        1 -> if (p.sysDetailed) others.take(3) else emptyList()
        else -> others
    }
    Row(Modifier.fillMaxSize().padding(start = 28.dp, end = 90.dp), verticalAlignment = Alignment.CenterVertically) {
        if (p.sysRam) {
            RamGauge(s.ramPct, s.ramLow, height - 28.dp)
            HSpace(24)
            Box(Modifier.width(330.dp)) { MemoryText(s, big = size > 0) }
            HSpace(30)
        } else if (cols.isEmpty() && others.isEmpty()) {
            NoStats()
        }
        val shown = if (p.sysRam) cols else others
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(32.dp), verticalAlignment = Alignment.CenterVertically) {
            for (l in shown) Box(Modifier.weight(1f)) { StatBar(l.label, l.value, l.frac, l.color) }
        }
    }
}

/**
 * RAM and system widget. It only reads Android's own numbers, only while the home screen is showing, and it never
 * claims to free anything. Refresh interval, size, position, mode and each statistic are in Settings > System widget.
 * Give it the column width in [modifier]; [wide] lays it out for the full-width "Own row" position instead.
 */
@Composable
fun SystemWidget(vm: DustViewModel, modifier: Modifier = Modifier, wide: Boolean = false) {
    val prefs = vm.prefs
    val pal = LocalPalette.current
    val motion = LocalMotion.current
    var snap by remember { mutableStateOf<SystemSnapshot?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val pulse = remember { Animatable(1f) }

    val active = LocalActive.current
    LaunchedEffect(prefs.sysRefresh, tick, active) {
        if (!active) return@LaunchedEffect
        var first = true
        while (true) {
            snap = withContext(Dispatchers.Default) { vm.stats.read() }
            if (first && vm.stats.cpuReadable && snap?.cpu == null) {
                delay(700)
                snap = withContext(Dispatchers.Default) { vm.stats.read() }
            }
            first = false
            val every = prefs.sysRefresh
            if (every <= 0) break
            delay(every * 1000L)
        }
    }
    LaunchedEffect(tick) {
        if (tick > 0 && motion.enabled) {
            pulse.animateTo(1.04f, tween(90))
            pulse.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 260f))
        }
    }

    val size = prefs.sysSize
    val height: Dp = if (wide) {
        when (size) { 0 -> 112.dp; 1 -> 172.dp; else -> 212.dp }
    } else {
        when (size) { 0 -> 104.dp; 1 -> 250.dp; else -> 430.dp }
    }
    val shape = rr(32)
    Box(modifier.height(height).graphicsLayer { scaleX = pulse.value; scaleY = pulse.value }) {
        Box(
            Modifier.fillMaxSize()
                .tvFocus(shape, onClick = { vm.systemDetail = true }, onLongClick = { tick++ }, memoryKey = "card:system")
                .glass(shape)
        ) {
            val s = snap
            if (s == null) {
                Box(Modifier.fillMaxSize(), Alignment.Center) { Txt("Reading system…", size = 21.sp, color = pal.textDim) }
            } else if (wide) {
                WideSystem(vm, s, size, height)
            } else {
                CompactSystem(vm, s, size)
            }
        }
        val centered = wide || size == 0
        RefreshButton(
            onClick = { tick++ },
            modifier = Modifier.align(if (centered) Alignment.CenterEnd else Alignment.TopEnd)
                .padding(top = if (centered) 0.dp else 12.dp, end = 16.dp),
        )
    }
}

/** Opened from the widget. Shows every number Android gives us, and the honest limits. */
@Composable
fun SystemDetail(vm: DustViewModel) {
    val ctx = LocalContext.current
    val pal = LocalPalette.current
    var snap by remember { mutableStateOf<SystemSnapshot?>(null) }
    var procs by remember { mutableStateOf<List<ProcUse>?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val close = remember { FocusRequester() }
    LaunchedEffect(tick) {
        withContext(Dispatchers.Default) {
            vm.stats.read()
            delay(500)
            val s = vm.stats.read()
            val p = vm.stats.topProcesses()
            snap = s
            procs = p
        }
    }
    Modal(onDismiss = { vm.systemDetail = false }, width = 1240.dp) {
        ModalTitle("System", "Real numbers from Android. DustOS never clears RAM or closes apps, because Android manages memory itself.")
        val s = snap
        Row(Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f).padding(end = 36.dp)) {
                if (s == null) Txt("Reading…", size = 22.sp, color = pal.textDim) else {
                    FactRow("Total memory", Units.humanBytes(s.ramTotal))
                    FactRow("In use", "${Units.humanBytes(s.ramUsed)} (${s.ramPct}%)")
                    FactRow("Available", Units.humanBytes(s.ramAvail))
                    FactRow("Low-memory state", if (s.ramLow) "Yes, Android is reclaiming memory" else "No")
                    FactRow("Storage", "${Units.humanBytes(s.storageFree)} free of ${Units.humanBytes(s.storageTotal)}")
                    FactRow("CPU", s.cpu?.let { "${(it * 100f).roundToInt()}%" } ?: "Android does not share CPU usage with apps on this device")
                    FactRow("Temperature", s.thermal ?: s.batteryTempC?.let { "%.1f°C".format(java.util.Locale.US, it) } ?: "Not reported by this device")
                    if (s.batteryPct != null) FactRow("Battery", "${s.batteryPct}%" + if (s.charging) " (charging)" else "")
                }
            }
            Column(Modifier.weight(1f)) {
                Txt("Memory use by app", size = 26.sp, weight = FontWeight.SemiBold)
                VSpace(10)
                val list = procs
                if (list == null) Txt("Reading…", size = 20.sp, color = pal.textDim)
                else {
                    for (p in list) {
                        val own = p.name == ctx.packageName
                        FactRow(if (own) "DustOS 17 (this launcher)" else p.name.substringAfterLast(':').take(34), "${p.pssKb / 1024} MB")
                    }
                    if (list.size <= 1) {
                        VSpace(8)
                        Txt(
                            "Since Android 5.1, apps can only see their own memory use, so other apps cannot be listed here. " +
                                "Use Android's app settings to review the apps you installed.",
                            size = 19.sp, color = pal.textDim, maxLines = 4,
                        )
                    }
                }
            }
        }
        VSpace(26)
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            GlassButton("Refresh", { tick++ })
            GlassButton("Android app settings", {
                if (!SystemIntents.open(ctx, SystemIntents.appManager())) vm.showToast("This device has no app settings page")
            })
            GlassButton("Close", { vm.systemDetail = false }, requester = close, primary = true)
        }
    }
    AutoFocus(close)
}
