package team.deltax.dustos.data

import android.content.Context
import android.os.Environment
import java.io.File

/**
 * Video screensavers are plain files the user puts on the device. There is no file picker on most TV sticks, so the
 * launcher looks in a few well known folders instead. The app-private folder needs no permission.
 */
object VideoSources {
    private val extensions = setOf("mp4", "m4v", "webm", "mkv", "mov", "3gp")

    fun folders(ctx: Context): List<File> {
        val out = ArrayList<File>()
        ctx.getExternalFilesDir("screensavers")?.let { out.add(it) }
        try {
            val root = Environment.getExternalStorageDirectory()
            out.add(File(root, "DustOS/screensavers"))
            out.add(File(root, "Movies"))
            out.add(File(root, "Download"))
        } catch (e: Exception) {
            // no shared storage
        }
        return out
    }

    /** Blocking, call from a background thread. */
    fun list(ctx: Context): List<File> {
        val found = LinkedHashMap<String, File>()
        for (dir in folders(ctx)) {
            val files = try { dir.listFiles() } catch (e: Exception) { null } ?: continue
            for (f in files) {
                if (f.isFile && f.extension.lowercase() in extensions && f.length() > 0L) found[f.absolutePath] = f
            }
            if (found.size >= 30) break
        }
        return found.values.sortedBy { it.name.lowercase() }.take(30)
    }
}
