package team.deltax.dustos.ui

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import team.deltax.dustos.Backdrop
import team.deltax.dustos.core.Wallpapers
import team.deltax.dustos.data.LauncherPrefs

class Palette(val accent: Color, val accent2: Color) {
    val text = Color(0xFFF7F5FF)
    val textDim = Color(0xB8F7F5FF)
    val textFaint = Color(0x80F7F5FF)
    val ink = Color(0xFF0B0A18)
}

/** Animation switchboard from Settings > Animations. */
class Motion(val enabled: Boolean, val speed: Float) {
    fun <T> spec(spec: AnimationSpec<T>): AnimationSpec<T> = if (enabled) spec else snap()
    fun ms(base: Int): Int = if (enabled) (base / speed).toInt().coerceAtLeast(1) else 1
}

val LocalPrefs = staticCompositionLocalOf<LauncherPrefs> { error("LauncherPrefs not provided") }
val LocalBackdrop = compositionLocalOf<Backdrop?> { null }
val LocalPalette = staticCompositionLocalOf { Palette(Color(0xFF9B7BFF), Color(0xFFFF7AB6)) }
val LocalMotion = compositionLocalOf { Motion(true, 1f) }
val LocalRootSize = compositionLocalOf { IntSize(1920, 1080) }

/** False while the launcher is stopped (TV off, another app in front). Loops and animations check it and stand down. */
val LocalActive = compositionLocalOf { true }

private fun argb(rgb: Int): Color = Color(0xFF000000.toInt() or rgb)

/**
 * The whole UI is laid out on a 1920 x 1080 "design pixel" canvas: 1.dp is 1/1920 of the screen width, so the same
 * layout is correct on 720p, 1080p and 4K sticks. Settings > Display > UI size scales it further.
 */
@Composable
fun DustTheme(prefs: LauncherPrefs, backdrop: Backdrop?, active: Boolean, content: @Composable () -> Unit) {
    val theme = Wallpapers.themeById(prefs.themeId)
    val palette = remember(theme.id) { Palette(argb(theme.accent), argb(theme.accent2)) }
    val motion = Motion(prefs.animations, prefs.animSpeed / 100f)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wPx = constraints.maxWidth
        val hPx = constraints.maxHeight
        val d = (wPx / 1920f) * (prefs.uiScale / 100f)
        CompositionLocalProvider(
            LocalDensity provides Density(d, 1f),
            LocalPrefs provides prefs,
            LocalBackdrop provides backdrop,
            LocalPalette provides palette,
            LocalMotion provides motion,
            LocalRootSize provides IntSize(wPx, hPx),
            LocalActive provides active,
        ) { content() }
    }
}

/** Corner radius that follows Settings > Appearance > Corners. */
@Composable
fun rr(base: Int): RoundedCornerShape {
    val k = 0.6f + 0.4f * LocalPrefs.current.corners
    return RoundedCornerShape((base * k).dp)
}

@Composable
fun Txt(
    text: String,
    size: TextUnit = 22.sp,
    weight: FontWeight = FontWeight.Normal,
    color: Color = LocalPalette.current.text,
    modifier: Modifier = Modifier,
    maxLines: Int = 1,
    align: TextAlign = TextAlign.Unspecified,
    family: FontFamily? = null,
    spacing: TextUnit = TextUnit.Unspecified,
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(
            color = color,
            fontSize = size,
            fontWeight = weight,
            fontFamily = family,
            textAlign = align,
            letterSpacing = spacing,
        ),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}
