package team.deltax.dustos.osee

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import team.deltax.dustos.core.VolumeCmd
import java.net.URLEncoder

/**
 * The few things OSee can hand to Android. Each one reports whether Android accepted the hand-off. A true result
 * means "the intent started", not "the other app found what you wanted", and OSee words its replies that way.
 */
object OseeLaunch {
    private fun start(ctx: Context, intent: Intent): Boolean = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    /** Opens a web search in whatever browser the device has. False when there is none. */
    fun webSearch(ctx: Context, query: String): Boolean {
        val uri = Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8"))
        return start(ctx, Intent(Intent.ACTION_VIEW, uri))
    }

    /** Android TV's system wide search, where the device has one. */
    fun globalSearch(ctx: Context, query: String): Boolean =
        start(ctx, Intent("android.search.action.GLOBAL_SEARCH").putExtra(SearchManager.QUERY, query))

    /** Standard search and play-from-search intents, aimed at one app. Many apps ignore them. */
    fun searchInApp(ctx: Context, pkg: String, query: String, play: Boolean): Boolean {
        val search = Intent(Intent.ACTION_SEARCH).putExtra(SearchManager.QUERY, query).setPackage(pkg)
        val playFromSearch = Intent("android.media.action.MEDIA_PLAY_FROM_SEARCH").putExtra(SearchManager.QUERY, query).setPackage(pkg)
        val order = if (play) listOf(playFromSearch, search) else listOf(search, playFromSearch)
        for (i in order) if (start(ctx, i)) return true
        return false
    }

    /** Packages that say they accept a search or play-from-search intent. Needs the matching <queries> entries. */
    fun searchablePackages(ctx: Context): Set<String> {
        val pm = ctx.packageManager
        val out = HashSet<String>()
        for (action in listOf(Intent.ACTION_SEARCH, "android.media.action.MEDIA_PLAY_FROM_SEARCH")) {
            try {
                for (ri in pm.queryIntentActivities(Intent(action), 0)) ri.activityInfo?.packageName?.let { out.add(it) }
            } catch (e: Exception) {
                // package visibility or a broken package manager: report what we have
            }
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun setMuted(am: AudioManager, mute: Boolean) {
        if (Build.VERSION.SDK_INT >= 23) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
        } else {
            am.setStreamMute(AudioManager.STREAM_MUSIC, mute)
        }
    }

    /** Changes this device's media volume. A TV that has its own volume is not affected. */
    fun volume(ctx: Context, cmd: VolumeCmd): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return "This device has no volume control I can use."
        return try {
            when (cmd) {
                VolumeCmd.UP -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "Volume up." }
                VolumeCmd.DOWN -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "Volume down." }
                VolumeCmd.MUTE -> { setMuted(am, true); "Muted." }
                VolumeCmd.UNMUTE -> { setMuted(am, false); "Unmuted." }
            }
        } catch (e: SecurityException) {
            "Android wouldn't let me change the volume."
        }
    }
}
