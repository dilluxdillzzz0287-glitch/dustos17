package team.deltax.dustos.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.constrainWidth
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.data.AppEntry

private class TileImage(val bitmap: ImageBitmap, val isBanner: Boolean)

@Composable
private fun rememberTileImage(vm: DustViewModel, app: AppEntry, wantBanner: Boolean): TileImage? {
    val image by produceState<TileImage?>(
        initialValue = (if (wantBanner) vm.icons.peek(app, true)?.let { TileImage(it, true) } else null)
            ?: vm.icons.peek(app, false)?.let { TileImage(it, false) },
        key1 = app.pkg, key2 = wantBanner,
    ) {
        val banner = if (wantBanner) vm.icons.load(app, true) else null
        value = if (banner != null) TileImage(banner, true) else vm.icons.load(app, false)?.let { TileImage(it, false) }
    }
    return image
}

private val TileDark = Color(0xFF120C32)

/** An icon's average colour turned into a tile colour that stays dark enough for white labels, whatever the icon is. */
private fun tileTop(avg: Color): Color {
    val l = avg.luminance()
    val c = if (l > 0.40f) lerp(avg, TileDark, (0.25f + (l - 0.40f)).coerceAtMost(0.75f)) else avg
    return c.copy(alpha = 0.82f)
}

private fun tileBottom(top: Color): Color = lerp(top, TileDark, 0.55f).copy(alpha = 0.94f)

@Composable
private fun rememberTileTint(vm: DustViewModel, app: AppEntry, needed: Boolean): Color? {
    val tint by produceState<Color?>(initialValue = vm.icons.peekTint(app), key1 = app.pkg, key2 = needed) {
        if (needed) value = vm.icons.tint(app) ?: value
    }
    return tint
}

@Composable
private fun Badge(text: String, modifier: Modifier) {
    Box(modifier.padding(10.dp).glass(rr(14), 1.6f).padding(horizontal = 12.dp, vertical = 4.dp)) {
        Txt(text, size = 16.sp, weight = FontWeight.SemiBold)
    }
}

/**
 * Coloured app tile: the app's icon on glass tinted with the icon's own colour, name underneath. Focus brightens it,
 * scales it and adds the glow. Hold Select for the app options.
 */
@Composable
fun IconTile(
    app: AppEntry,
    vm: DustViewModel,
    modifier: Modifier = Modifier,
    iconSize: Dp = 58.dp,
    labelSize: TextUnit = 20.sp,
    requester: FocusRequester? = null,
    badge: String? = null,
) {
    val shape = rr(26)
    val pal = LocalPalette.current
    val img = rememberTileImage(vm, app, false)
    val tint = rememberTileTint(vm, app, true)
    var focused by remember { mutableStateOf(false) }
    val top = tileTop(tint ?: pal.accent)
    Box(
        modifier
            .tvFocus(shape, onClick = { vm.launch(app) }, onLongClick = { vm.optionsFor = app }, requester = requester, onFocusChange = { focused = it }, memoryKey = "${LocalRowKey.current}/${app.pkg}")
            .glass(shape, 0.8f)
    ) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(top, tileBottom(top)))))
        if (focused) Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.22f)))
        Column(
            Modifier.fillMaxSize().padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                val i = img
                if (i != null) Image(i.bitmap, null, Modifier.size(iconSize).clip(rr(16)), contentScale = ContentScale.Fit)
            }
            Txt(app.label, size = labelSize, weight = FontWeight.Medium, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
        if (badge != null) Badge(badge, Modifier.align(Alignment.TopEnd))
    }
}

/** Wide app card for "Recently used". Banner art fills the card; apps without a banner get a tinted card with the icon. */
@Composable
fun AppTile(
    app: AppEntry,
    vm: DustViewModel,
    width: Dp,
    height: Dp,
    modifier: Modifier = Modifier,
    requester: FocusRequester? = null,
    badge: String? = null,
) {
    val shape = rr(28)
    val pal = LocalPalette.current
    val img = rememberTileImage(vm, app, true)
    val hasBanner = img?.isBanner == true
    val tint = rememberTileTint(vm, app, !hasBanner)
    val top = tileTop(tint ?: pal.accent)
    Box(
        modifier
            .size(width, height)
            .tvFocus(shape, onClick = { vm.launch(app) }, onLongClick = { vm.optionsFor = app }, requester = requester, memoryKey = "${LocalRowKey.current}/${app.pkg}")
            .glass(shape)
    ) {
        val i = img
        if (i != null && i.isBanner) {
            Image(i.bitmap, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(top, tileBottom(top)))))
            if (i != null) {
                Image(i.bitmap, null, Modifier.align(Alignment.Center).padding(bottom = 22.dp).size(height * 0.44f).clip(rr(18)), contentScale = ContentScale.Fit)
            }
        }
        Box(
            Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xB3060512))))
                .padding(start = 18.dp, end = 18.dp, top = 30.dp, bottom = 12.dp)
        ) {
            Txt(app.label, size = 23.sp, weight = FontWeight.Medium, align = TextAlign.Start)
        }
        if (badge != null) Badge(badge, Modifier.align(Alignment.TopEnd))
    }
}

/** Card for suggestions and tips: a glyph on a tinted glass card, title and one line of explanation. */
@Composable
fun SuggestionCard(
    title: String,
    subtitle: String,
    glyph: Glyph,
    tint: Color,
    modifier: Modifier = Modifier,
    width: Dp = 352.dp,
    height: Dp = 154.dp,
    onClick: () -> Unit,
) {
    val shape = rr(28)
    var focused by remember { mutableStateOf(false) }
    Box(modifier.size(width, height).tvFocus(shape, onClick = onClick, onFocusChange = { focused = it }).glass(shape)) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(tint.copy(alpha = 0.58f), tint.copy(alpha = 0.10f)))))
        if (focused) Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.16f)))
        Row(Modifier.fillMaxSize().padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(64.dp).background(Color.White.copy(alpha = 0.22f), rr(20)), contentAlignment = Alignment.Center) {
                GlyphIcon(glyph, Modifier.size(34.dp), tint = Color.White)
            }
            HSpace(18)
            Column {
                Txt(title, size = 23.sp, weight = FontWeight.SemiBold, maxLines = 2)
                Txt(subtitle, size = 17.sp, color = LocalPalette.current.textDim, maxLines = 2)
            }
        }
    }
}

private val Bleed = 14.dp
private val ShelfPad = 22.dp

/** Lets a row grow a little past the content edge on both sides so the focus glow of the first and last tile isn't cut off. */
private fun Modifier.bleed(by: Dp): Modifier = layout { measurable, constraints ->
    val px = by.roundToPx()
    val wide = if (constraints.hasBoundedWidth) constraints.maxWidth + 2 * px else constraints.maxWidth
    val placeable = measurable.measure(constraints.copy(minWidth = 0, maxWidth = wide))
    layout(constraints.constrainWidth(placeable.width - 2 * px), placeable.height) { placeable.place(-px, 0) }
}

/** A titled, horizontally scrolling shelf. */
@Composable
fun <T> Shelf(
    title: String,
    items: List<T>,
    rowHeight: Dp,
    modifier: Modifier = Modifier,
    hint: String? = null,
    gap: Dp = 18.dp,
    key: ((T) -> Any)? = null,
    itemContent: @Composable (T) -> Unit,
) {
    CompositionLocalProvider(LocalRowKey provides title) {
    Column(modifier.bleed(Bleed)) {
        Box(Modifier.fillMaxWidth().padding(start = Bleed + 6.dp, end = Bleed + 6.dp, top = 8.dp)) {
            Txt(title, size = 30.sp, weight = FontWeight.SemiBold)
            if (hint != null) Txt(hint, size = 18.sp, color = LocalPalette.current.textFaint, modifier = Modifier.align(Alignment.CenterEnd))
        }
        LazyRow(
            Modifier.fillMaxWidth().height(rowHeight + 2 * ShelfPad),
            contentPadding = PaddingValues(horizontal = Bleed, vertical = ShelfPad),
            horizontalArrangement = Arrangement.spacedBy(gap),
        ) {
            items(items, key = key) { itemContent(it) }
        }
    }
    }
}
