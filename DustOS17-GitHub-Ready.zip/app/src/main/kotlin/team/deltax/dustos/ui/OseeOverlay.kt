package team.deltax.dustos.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.OseeText
import team.deltax.dustos.osee.FollowUp
import team.deltax.dustos.osee.OseeSession
import team.deltax.dustos.osee.OseeState
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

/** A looping 0..1 value. Stands still when animations are switched off. */
@Composable
private fun rememberPhase(periodMs: Int): Float {
    val motion = LocalMotion.current
    if (!motion.enabled) return 0f
    val transition = rememberInfiniteTransition(label = "osee")
    val v by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(periodMs, easing = LinearEasing)),
        label = "phase",
    )
    return v
}

/** The OSee logo: a glowing sphere with a turning ring. It swells with the real microphone level while listening. */
@Composable
private fun OseeOrb(state: OseeState, level: Float, diameter: Dp) {
    val pal = LocalPalette.current
    val spin = rememberPhase(5200)
    val pulse = rememberPhase(1800)
    val smooth by animateFloatAsState(level, spring(stiffness = 300f), label = "orbLevel")
    val energy = when (state) {
        OseeState.Listening -> 0.35f + 0.65f * smooth
        OseeState.Processing -> 0.55f
        OseeState.Responding -> 0.40f
        OseeState.Idle -> 0.12f
    }
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            val c = Offset(this.size.width / 2f, this.size.height / 2f)
            val breath = 0.5f + 0.5f * sin(pulse * 2f * PI.toFloat())
            val glowR = r * (1.20f + 0.25f * breath * energy + 0.35f * energy)
            drawCircle(
                Brush.radialGradient(listOf(pal.accent.copy(alpha = 0.55f), pal.accent2.copy(alpha = 0.22f), Color.Transparent), c, glowR),
                glowR, c,
            )
            val ringR = r * 0.80f
            rotate(spin * 360f, c) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Color.Transparent, pal.accent2, Color.White.copy(alpha = 0.92f), Color.Transparent), c),
                    startAngle = 0f,
                    sweepAngle = 300f,
                    useCenter = false,
                    topLeft = Offset(c.x - ringR, c.y - ringR),
                    size = Size(ringR * 2f, ringR * 2f),
                    style = Stroke(width = r * 0.06f, cap = StrokeCap.Round),
                )
            }
            val core = r * 0.52f * (1f + 0.07f * energy * breath)
            drawCircle(
                Brush.radialGradient(
                    listOf(Color.White, Color(0xFFB7C6FF), pal.accent, pal.accent2),
                    Offset(c.x - core * 0.30f, c.y - core * 0.35f),
                    core * 1.5f,
                ),
                core, c,
            )
            drawCircle(Color.White.copy(alpha = 0.8f), core, c, style = Stroke(width = 2.dp.toPx()))
        }
        GlyphIcon(Glyph.SPARK, Modifier.size(diameter * 0.28f), tint = Color(0xFF2B2370))
    }
}

/** Bars that move with what OSee is doing: the microphone level while listening, a sweep while thinking, a swell while replying. */
@Composable
private fun Waveform(state: OseeState, level: Float, modifier: Modifier) {
    val pal = LocalPalette.current
    val phase = rememberPhase(1600)
    val smooth by animateFloatAsState(level, spring(stiffness = 400f), label = "waveLevel")
    Canvas(modifier) {
        val n = 56
        val gap = 6.dp.toPx()
        val barW = (this.size.width - gap * (n - 1)) / n
        val mid = this.size.height / 2f
        val ph = phase * 2f * PI.toFloat()
        for (i in 0 until n) {
            val x = i * (barW + gap)
            val u = i / (n - 1f)
            val env = 0.35f + 0.65f * sin(u * PI.toFloat())
            val a = when (state) {
                OseeState.Listening -> 0.10f + (0.25f + 0.75f * smooth) * (0.5f + 0.5f * sin(ph * 2f + i * 0.55f)) * env
                OseeState.Processing -> 0.10f + 0.55f * max(0f, sin(ph * 2f - i * 0.30f)) * env
                OseeState.Responding -> 0.10f + 0.28f * (0.5f + 0.5f * sin(ph + i * 0.40f)) * env
                OseeState.Idle -> 0.07f
            }
            val h = (this.size.height * a).coerceAtLeast(barW)
            val color = lerp(pal.accent, pal.accent2, u).copy(alpha = if (state == OseeState.Idle) 0.45f else 0.95f)
            drawRoundRect(color, Offset(x, mid - h / 2f), Size(barW, h), CornerRadius(barW / 2f))
        }
    }
}

@Composable
private fun Chip(text: String, onClick: () -> Unit) {
    val shape = rr(32)
    Box(Modifier.tvFocus(shape, onClick = onClick, scale = 1.05f).glass(shape, 1.1f).padding(horizontal = 26.dp, vertical = 12.dp)) {
        Txt(text, size = 22.sp)
    }
}

/** Shows that the microphone is open, or says plainly that it is not. */
@Composable
private fun MicBadge(on: Boolean) {
    val pal = LocalPalette.current
    val blink = rememberPhase(1100)
    Row(
        Modifier.glass(rr(30), 1.5f).padding(horizontal = 22.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (on) {
            val a = 0.65f + 0.35f * sin(blink * 2f * PI.toFloat())
            Box(Modifier.size(16.dp).background(Color(0xFFFF4D66).copy(alpha = a), CircleShape))
            HSpace(12)
            Txt("Microphone on", size = 21.sp, weight = FontWeight.SemiBold)
        } else {
            GlyphIcon(Glyph.MIC, Modifier.size(24.dp), tint = pal.textFaint)
            HSpace(10)
            Txt("Microphone off", size = 21.sp, color = pal.textDim)
        }
    }
}

private fun stateTitle(s: OseeState) = when (s) {
    OseeState.Idle -> "Ready when you are"
    OseeState.Listening -> "Listening…"
    OseeState.Processing -> "Thinking…"
    OseeState.Responding -> "Here you go"
}

/**
 * OSee AI. A glass panel over a dimmed screen with the animated logo, the waveform, what OSee heard, its answer, and
 * buttons for the next step. The microphone opens only after Talk is pressed, for one phrase, and the badge top right
 * says so. Closing this screen releases the microphone and the speech engine.
 */
@Composable
fun OseeOverlay(vm: DustViewModel) {
    val ctx = LocalContext.current
    val host = LocalHost.current
    val pal = LocalPalette.current
    val scope = rememberCoroutineScope()
    val session = remember { OseeSession(ctx, vm, host) { vm.oseeVisible = false } }
    DisposableEffect(session) { onDispose { session.release() } }

    val talk = remember { FocusRequester() }
    var typed by remember { mutableStateOf("") }
    val voiceAvailable = remember { host.speechAvailable() }

    fun refocus() {
        scope.launch {
            delay(90)
            try { talk.requestFocus() } catch (e: Exception) { }
        }
    }

    LaunchedEffect(vm.oseeQuery) { vm.oseeQuery?.let { q -> vm.oseeQuery = null; session.submit(q) } }
    LaunchedEffect(vm.oseeAutoListen) { if (vm.oseeAutoListen) { vm.oseeAutoListen = false; session.startListening() } }
    LaunchedEffect(vm.weather) { session.weatherArrived() }
    LaunchedEffect(vm.permTick) { session.onPermissionResult() }
    BackHandler { if (session.state != OseeState.Idle) session.cancel() else vm.oseeVisible = false }

    val state = session.state
    val busy = state != OseeState.Idle
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xD0100A2C), Color(0xEB1A0F40))))
    ) {
        Column(
            Modifier.align(Alignment.Center).width(1240.dp).glass(rr(48), 1.7f).padding(horizontal = 44.dp, vertical = 36.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OseeOrb(state, session.level, 112.dp)
                HSpace(24)
                Column(Modifier.weight(1f)) {
                    Txt("OSee AI", size = 46.sp, weight = FontWeight.SemiBold)
                    Txt(stateTitle(state), size = 25.sp, color = pal.textDim)
                }
                MicBadge(session.micOn)
            }
            VSpace(10)
            Waveform(state, session.level, Modifier.fillMaxWidth().height(80.dp))
            VSpace(10)
            Column(Modifier.fillMaxWidth().height(196.dp).padding(horizontal = 6.dp)) {
                val heard = session.heard
                val reply = session.reply
                if (heard.isNotEmpty()) {
                    Txt("“$heard”", size = 33.sp, weight = FontWeight.Medium, color = if (session.heardFinal) pal.text else pal.textDim, maxLines = 2)
                    VSpace(10)
                }
                if (reply.isNotEmpty()) {
                    Txt(reply, size = 27.sp, color = if (heard.isEmpty()) pal.text else pal.textDim, maxLines = if (heard.isEmpty()) 6 else 4)
                } else if (heard.isEmpty()) {
                    Txt(
                        if (voiceAvailable) "Press Talk and say what you need, or pick something below." else "This device has no speech recognizer. Type to OSee, or pick something below.",
                        size = 27.sp, color = pal.textDim, maxLines = 3,
                    )
                }
            }
            Column(Modifier.fillMaxWidth().height(136.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                val follow = session.followUps
                if (follow.isNotEmpty()) {
                    for (row in follow.chunked(2)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            for (f in row) Chip(f.label) { f.run(); refocus() }
                        }
                    }
                } else if (!busy) {
                    for (row in OseeText.EXAMPLES.take(6).chunked(3)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            for (ex in row) Chip(ex) { session.submit(ex); refocus() }
                        }
                    }
                }
            }
            VSpace(10)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                GlassButton(
                    text = when (state) { OseeState.Idle -> "Talk"; OseeState.Listening -> "Stop"; else -> "Cancel" },
                    onClick = { session.toggleMic() },
                    glyph = Glyph.MIC,
                    primary = true,
                    requester = talk,
                )
                TvTextField(
                    value = typed,
                    onValueChange = { typed = it },
                    placeholder = "Type to OSee",
                    onSubmit = { val t = typed; typed = ""; session.submit(t); refocus() },
                    modifier = Modifier.weight(1f),
                )
                GlassButton("Close", { vm.oseeVisible = false })
            }
            Txt(
                "OSee is DustOS's own assistant. It is not Alexa and does not replace it. It listens only while you press Talk, for one phrase.",
                size = 18.sp, color = pal.textFaint, maxLines = 2, modifier = Modifier.padding(top = 14.dp, start = 6.dp),
            )
        }
    }
    AutoFocus(talk)
}
