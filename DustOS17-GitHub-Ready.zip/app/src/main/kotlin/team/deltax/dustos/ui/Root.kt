package team.deltax.dustos.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.Section

/** Entry point of the UI: theme, the activity's [Host], then the screen. */
@Composable
fun DustRoot(vm: DustViewModel, host: Host) {
    DustTheme(vm.prefs, vm.backdrop, vm.active) {
        CompositionLocalProvider(LocalHost provides host) {
            RootScreen(vm)
        }
    }
}

private fun FocusRequester.tryFocus(): Boolean = try {
    requestFocus()
    true
} catch (e: Exception) {
    false
}

/**
 * The whole launcher screen: wallpaper, header, sidebar and the page, with dialogs, OSee and the toast above them.
 * While the screensaver is showing, none of that is composed, so an idle TV does no other drawing work.
 */
@Composable
private fun RootScreen(vm: DustViewModel) {
    val prefs = vm.prefs
    val motion = LocalMotion.current
    val root = LocalRootSize.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    val showSaver = vm.screensaverActive || vm.screensaverPreview
    // Read inside focusProperties below, so Compose re-checks focusability the moment a dialog opens or closes.
    val blocked = remember(vm) {
        derivedStateOf { vm.oseeVisible || vm.optionsFor != null || vm.weatherDetail || vm.systemDetail || vm.info != null }
    }
    val overlay = blocked.value

    val side = remember { SidebarFocus() }
    val entries = remember { Section.values().associateWith { FocusRequester() } }
    val holder = rememberSaveableStateHolder()
    var anyFocus by remember { mutableStateOf(false) }

    // Back: from any page it returns to Home. On Home it stays here when "Keep Back inside DustOS" is on; when it is
    // off, Back on Home is left to the system. Dialogs and OSee register their own handlers later, which win.
    BackHandler(enabled = vm.section != Section.HOME || prefs.overrideBack) {
        if (vm.section != Section.HOME) {
            vm.section = Section.HOME
            scope.launch {
                delay(40)
                side.home.tryFocus()
            }
        }
    }

    // First focus, and focus after a dialog or the screensaver closes: put it back where it was, else on the sidebar.
    LaunchedEffect(showSaver, overlay) {
        if (showSaver || overlay) return@LaunchedEffect
        delay(140)
        if (!anyFocus && !FocusMemory.restore()) side.of(vm.section).tryFocus()
    }
    // A button on a page can switch the page (Launcher settings, Open Apps). Its old focus is gone, so pick up on the new page.
    LaunchedEffect(vm.section) {
        delay(motion.ms(300) + 60L)
        if (!showSaver && !blocked.value && !anyFocus) entries.getValue(vm.section).tryFocus()
    }
    // Home pressed: back to the sidebar's Home entry.
    LaunchedEffect(vm.homeTick) {
        if (vm.homeTick > 0) {
            delay(90)
            if (!vm.screensaverActive && !vm.screensaverPreview && !blocked.value) side.home.tryFocus()
        }
    }

    val safeX = with(density) { (root.width * prefs.safeArea / 100f).toDp() }
    val safeY = with(density) { (root.height * prefs.safeArea / 100f).toDp() }

    Box(Modifier.fillMaxSize().background(Color(0xFF0B0A18))) {
        if (showSaver) {
            ScreensaverOverlay(vm)
        } else {
            WallpaperLayer(animate = true)
            Column(
                Modifier.fillMaxSize()
                    .padding(start = 48.dp + safeX, end = 48.dp + safeX, top = 22.dp + safeY, bottom = 18.dp + safeY)
                    .onFocusChanged { anyFocus = it.hasFocus }
                    .focusProperties { canFocus = !blocked.value }
            ) {
                Header(vm, vm.micLive)
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    Sidebar(vm, side, entries.getValue(vm.section))
                    HSpace(30)
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        AnimatedContent(
                            targetState = vm.section,
                            transitionSpec = {
                                if (motion.enabled) fadeIn(tween(motion.ms(260))) togetherWith fadeOut(tween(motion.ms(160)))
                                else EnterTransition.None togetherWith ExitTransition.None
                            },
                            label = "section",
                        ) { section ->
                            // Keeps each page's scroll position while another page (or the screensaver) is showing.
                            holder.SaveableStateProvider(section.name) {
                                when (section) {
                                    Section.HOME -> HomeScreen(vm, entries.getValue(Section.HOME))
                                    Section.APPS -> AppGridScreen(
                                        vm, "Apps", vm.visibleApps,
                                        "No apps found yet. Give DustOS a moment to look.",
                                        entries.getValue(Section.APPS),
                                    )
                                    Section.GAMES -> AppGridScreen(
                                        vm, "Games", vm.games,
                                        "No games yet. Hold Select on an app and choose Show in Games.",
                                        entries.getValue(Section.GAMES),
                                    )
                                    Section.SETTINGS -> SettingsScreen(vm, entries.getValue(Section.SETTINGS))
                                }
                            }
                        }
                    }
                }
            }

            vm.optionsFor?.let { AppOptionsDialog(vm, it) }
            if (vm.weatherDetail) WeatherDetail(vm)
            if (vm.systemDetail) SystemDetail(vm)
            vm.info?.let { InfoModal(vm, it) }
            if (vm.oseeVisible) OseeOverlay(vm)
        }
        ToastHost(vm)
    }
}

/** One line of feedback near the bottom, such as "Couldn't open Netflix". Fades in and out. */
@Composable
private fun BoxScope.ToastHost(vm: DustViewModel) {
    val motion = LocalMotion.current
    val msg = vm.toast
    var last by remember { mutableStateOf("") }
    LaunchedEffect(msg) { if (msg != null) last = msg }
    AnimatedVisibility(
        visible = msg != null,
        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 84.dp),
        enter = if (motion.enabled) fadeIn(tween(motion.ms(180))) + slideInVertically(tween(motion.ms(220))) { it / 2 } else EnterTransition.None,
        exit = if (motion.enabled) fadeOut(tween(motion.ms(260))) else ExitTransition.None,
    ) {
        Box(Modifier.glass(rr(40), 2.2f).padding(horizontal = 36.dp, vertical = 16.dp)) {
            Txt(msg ?: last, size = 25.sp, weight = FontWeight.Medium, maxLines = 2)
        }
    }
}
