package team.deltax.dustos.ui

import android.os.SystemClock
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex

/** Name of the shelf or grid an item sits in, so the same app shown in two rows has two different focus keys. */
val LocalRowKey = compositionLocalOf { "" }

/**
 * Remembers which item had focus before a dialog, OSee or the screensaver took over, so closing it puts focus back
 * exactly there. Items opt in by passing a key to [tvFocus]. If the item is gone, the caller falls back to the sidebar.
 */
object FocusMemory {
    private val requesters = HashMap<String, FocusRequester>()
    var last: String? = null

    /** Until this uptime the sidebar leaves focus where it was put, instead of redirecting it to the selected section. */
    var quietUntil = 0L

    fun register(key: String, r: FocusRequester) { requesters[key] = r }

    fun unregister(key: String, r: FocusRequester) { if (requesters[key] === r) requesters.remove(key) }

    fun restore(): Boolean {
        val k = last ?: return false
        val r = requesters[k] ?: return false
        quietUntil = SystemClock.uptimeMillis() + 500L
        return try { r.requestFocus(); true } catch (e: Exception) { quietUntil = 0L; false }
    }
}

private val RimBrush = Brush.linearGradient(
    listOf(Color.White.copy(alpha = 0.72f), Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.36f))
)

/**
 * Frosted glass without a live blur. The launcher keeps one pre-blurred copy of the wallpaper (see DustViewModel)
 * and every panel just draws the slice of it that sits behind the panel, then adds a milky veil, a top sheen and a
 * light rim. That looks like blurred glass but costs one textured quad per panel, which a Fire TV Stick can afford.
 */
@Composable
fun Modifier.glass(shape: Shape, veil: Float = 1f, rim: Boolean = true): Modifier {
    val backdrop = LocalBackdrop.current
    val strength = LocalPrefs.current.glass / 100f
    val root = LocalRootSize.current
    val origin = remember { mutableStateOf(Offset.Zero) }
    val veilAlpha = (0.06f + 0.16f * strength) * veil
    return this
        .onGloballyPositioned { origin.value = it.positionInRoot() }
        .clip(shape)
        .drawBehind {
            val b = backdrop
            if (b != null) {
                val o = origin.value
                translate(-o.x, -o.y) {
                    drawImage(b.blurred, dstSize = root, filterQuality = FilterQuality.Low)
                }
            }
            drawRect(Color(0xFF150B3A).copy(alpha = 0.10f * veil))
            drawRect(Color.White.copy(alpha = veilAlpha))
            drawRect(
                Brush.verticalGradient(
                    0f to Color.White.copy(alpha = 0.20f * veil),
                    0.55f to Color.Transparent,
                    startY = 0f,
                    endY = size.height,
                )
            )
        }
        .then(if (rim) Modifier.border(1.dp, RimBrush, shape) else Modifier)
}

/**
 * D-pad focus for anything selectable. Focus gives a spring scale, a soft accent glow and a light ring.
 * Select / Enter clicks, long Select or Menu calls [onLongClick] (the app options menu).
 */
@Composable
fun Modifier.tvFocus(
    shape: Shape,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    scale: Float = 1.07f,
    requester: FocusRequester? = null,
    onFocusChange: ((Boolean) -> Unit)? = null,
    memoryKey: String? = null,
): Modifier {
    val prefs = LocalPrefs.current
    val motion = LocalMotion.current
    val accent = LocalPalette.current.accent
    var focused by remember { mutableStateOf(false) }
    val longFired = remember { BooleanArray(1) }
    val k by animateFloatAsState(
        targetValue = if (focused) 1f else 0f,
        animationSpec = motion.spec(spring(dampingRatio = 0.68f, stiffness = 380f * motion.speed)),
        label = "focus",
    )
    val glowOn = prefs.focusGlow
    val own = requester ?: if (memoryKey != null) remember { FocusRequester() } else null
    if (memoryKey != null && own != null) {
        DisposableEffect(memoryKey, own) {
            FocusMemory.register(memoryKey, own)
            onDispose { FocusMemory.unregister(memoryKey, own) }
        }
    }
    return this
        .then(if (own != null) Modifier.focusRequester(own) else Modifier)
        .onFocusChanged {
            focused = it.isFocused
            if (it.isFocused && memoryKey != null) FocusMemory.last = memoryKey
            onFocusChange?.invoke(it.isFocused)
        }
        .onKeyEvent { ev ->
            val key = ev.key
            val select = key == Key.DirectionCenter || key == Key.Enter || key == Key.NumPadEnter || key == Key.ButtonA
            when {
                select && ev.type == KeyEventType.KeyDown -> {
                    if (onLongClick != null && ev.nativeKeyEvent.isLongPress && !longFired[0]) {
                        longFired[0] = true
                        onLongClick()
                        true
                    } else {
                        if (ev.nativeKeyEvent.repeatCount == 0) longFired[0] = false
                        onClick != null || onLongClick != null
                    }
                }
                select && ev.type == KeyEventType.KeyUp -> {
                    if (longFired[0]) {
                        longFired[0] = false
                        true
                    } else if (onClick != null) {
                        onClick()
                        true
                    } else false
                }
                key == Key.Menu && ev.type == KeyEventType.KeyUp && onLongClick != null -> {
                    onLongClick()
                    true
                }
                else -> false
            }
        }
        .focusable()
        .zIndex(if (focused) 2f else 0f)
        .graphicsLayer {
            val s = 1f + (scale - 1f) * k
            scaleX = s
            scaleY = s
        }
        .drawWithContent {
            if (glowOn && k > 0.01f) {
                val pad = 30.dp.toPx()
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(accent.copy(alpha = 0.50f * k), Color.Transparent),
                        center = Offset(size.width / 2f, size.height / 2f),
                        radius = maxOf(size.width, size.height) * 0.78f,
                    ),
                    topLeft = Offset(-pad, -pad),
                    size = Size(size.width + 2 * pad, size.height + 2 * pad),
                )
            }
            drawContent()
            if (k > 0.01f) {
                val outline = shape.createOutline(size, layoutDirection, this)
                drawOutline(outline, color = Color.White.copy(alpha = 0.92f * k), style = Stroke(width = 2.5.dp.toPx()))
            }
        }
}

@Composable
fun GlassPanel(modifier: Modifier = Modifier, radius: Int = 32, veil: Float = 1f, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.glass(rr(radius), veil), content = content)
}

/** A text button: glass at rest, accent filled when it has focus. */
@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    glyph: Glyph? = null,
    requester: FocusRequester? = null,
    primary: Boolean = false,
    onFocusChange: ((Boolean) -> Unit)? = null,
) {
    val accent = LocalPalette.current.accent
    val shape = rr(40)
    Box(
        modifier
            .tvFocus(shape, onClick = onClick, scale = 1.05f, requester = requester, onFocusChange = onFocusChange)
            .glass(shape, veil = if (primary) 1.8f else 1f)
            .then(if (primary) Modifier.drawBehind { drawRect(accent.copy(alpha = 0.32f)) } else Modifier)
            .padding(horizontal = 30.dp, vertical = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (glyph != null) {
                GlyphIcon(glyph, Modifier.size(26.dp))
                Spacer(Modifier.width(12.dp))
            }
            Txt(text, size = 24.sp, weight = FontWeight.Medium)
        }
    }
}

/** White pill with dark text and an accent play triangle, the "Watch Now" style button on the featured banner. */
@Composable
fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    requester: FocusRequester? = null,
    onFocusChange: ((Boolean) -> Unit)? = null,
    memoryKey: String? = null,
) {
    val pal = LocalPalette.current
    val shape = rr(44)
    Row(
        modifier
            .tvFocus(shape, onClick = onClick, scale = 1.06f, requester = requester, onFocusChange = onFocusChange, memoryKey = memoryKey)
            .background(Color.White.copy(alpha = 0.92f), shape)
            .padding(start = 26.dp, end = 34.dp, top = 15.dp, bottom = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GlyphIcon(Glyph.PLAY, Modifier.size(24.dp), tint = pal.accent)
        Spacer(Modifier.width(14.dp))
        Txt(text, size = 24.sp, weight = FontWeight.SemiBold, color = pal.ink)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Txt(text, size = 30.sp, weight = FontWeight.SemiBold, modifier = modifier.padding(start = 6.dp, bottom = 6.dp))
}

@Composable
fun VSpace(h: Int) = Spacer(Modifier.height(h.dp))

@Composable
fun HSpace(w: Int) = Spacer(Modifier.width(w.dp))
