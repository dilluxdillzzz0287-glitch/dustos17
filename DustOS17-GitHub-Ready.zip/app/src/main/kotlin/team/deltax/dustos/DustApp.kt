package team.deltax.dustos

import android.app.Application

/**
 * Application class. Deliberately empty: DustOS starts no service, worker or thread of its own at process start.
 * Settings are read when first needed ([team.deltax.dustos.data.LauncherPrefs.get]) and everything else belongs to the
 * launcher screen, which stops when the screen is not in front.
 */
class DustApp : Application()
