package team.deltax.dustos.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import team.deltax.dustos.core.CpuMath
import team.deltax.dustos.core.CpuTimes
import team.deltax.dustos.core.Units
import java.io.File

data class SystemSnapshot(
    val ramTotal: Long,
    val ramAvail: Long,
    val ramLow: Boolean,
    val cpu: Float?,            // 0..1, null when Android does not let apps read it
    val storageTotal: Long,
    val storageFree: Long,
    val thermal: String?,       // Android thermal status, API 29+
    val batteryTempC: Float?,
    val batteryPct: Int?,       // null on devices without a battery, which includes Fire TV sticks
    val charging: Boolean,
) {
    val ramUsed: Long get() = (ramTotal - ramAvail).coerceAtLeast(0L)
    val ramPct: Int get() = Units.percent(ramUsed, ramTotal)
    val storageUsed: Long get() = (storageTotal - storageFree).coerceAtLeast(0L)
    val storagePct: Int get() = Units.percent(storageUsed, storageTotal)
}

data class ProcUse(val name: String, val pssKb: Int)

/** Real numbers from Android APIs only. Nothing here changes system state. */
class SystemStats(private val ctx: Context) {
    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val mem = ActivityManager.MemoryInfo()
    private var prevCpu: CpuTimes? = null
    private var cpuDenied = false

    fun read(): SystemSnapshot {
        am.getMemoryInfo(mem)
        val (stTotal, stFree) = try {
            val sf = StatFs(Environment.getDataDirectory().path)
            sf.totalBytes to sf.availableBytes
        } catch (e: Exception) {
            0L to 0L
        }
        val batt: Intent? = try { ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) } catch (e: Exception) { null }
        val present = batt?.getBooleanExtra(BatteryManager.EXTRA_PRESENT, false) == true
        val level = batt?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batt?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = batt?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val temp = batt?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        return SystemSnapshot(
            ramTotal = mem.totalMem,
            ramAvail = mem.availMem,
            ramLow = mem.lowMemory,
            cpu = cpuLoad(),
            storageTotal = stTotal,
            storageFree = stFree,
            thermal = thermalText(),
            batteryTempC = if (present && temp != Int.MIN_VALUE) temp / 10f else null,
            batteryPct = if (present && level >= 0 && scale > 0) level * 100 / scale else null,
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
        )
    }

    /** /proc/stat is blocked for apps on Android 8 and newer on most devices. Then this stays null and the UI says so. */
    private fun cpuLoad(): Float? {
        if (cpuDenied) return null
        return try {
            val cur = CpuMath.parseProcStat(File("/proc/stat").readText())
            if (cur == null) { cpuDenied = true; return null }
            val prev = prevCpu
            prevCpu = cur
            if (prev == null) null else CpuMath.load(prev, cur)
        } catch (e: Exception) {
            cpuDenied = true
            null
        }
    }

    val cpuReadable: Boolean get() = !cpuDenied

    private fun thermalText(): String? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Light"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
                PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Largest processes Android is willing to show us. Since Android 5.1 a normal app only sees its own process,
     * so the result is often a single entry. Callers should say that instead of implying a full list.
     */
    fun topProcesses(limit: Int = 6): List<ProcUse> {
        return try {
            val procs = am.runningAppProcesses ?: return emptyList()
            if (procs.isEmpty()) return emptyList()
            val infos = am.getProcessMemoryInfo(procs.map { it.pid }.toIntArray())
            procs.indices.map { ProcUse(procs[it].processName, infos[it].totalPss) }
                .sortedByDescending { it.pssKb }
                .take(limit)
        } catch (e: Exception) {
            emptyList()
        }
    }
}
