package team.deltax.dustos.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.InfoDialog

private class Category(val id: String, val title: String, val glyph: Glyph)

private val Categories = listOf(
    Category("appearance", "Appearance", Glyph.PALETTE),
    Category("wallpaper", "Wallpaper", Glyph.IMAGE),
    Category("home", "Home layout", Glyph.HOME),
    Category("display", "Display", Glyph.TV),
    Category("clock", "Clock", Glyph.CLOCK),
    Category("screensaver", "Screensaver", Glyph.MOON),
    Category("weather", "Weather", Glyph.CLOUD),
    Category("system", "System widget", Glyph.CHIP),
    Category("animations", "Animations", Glyph.SPARK),
    Category("launcher", "Launcher", Glyph.SETTINGS),
    Category("boot", "Boot", Glyph.POWER),
    Category("osee", "OSee AI", Glyph.MIC),
    Category("apps", "Apps", Glyph.APPS),
    Category("about", "About", Glyph.INFO),
)

@Composable
private fun PageContent(vm: DustViewModel, id: String) {
    when (id) {
        "appearance" -> AppearancePage(vm)
        "wallpaper" -> WallpaperPage(vm)
        "home" -> HomeLayoutPage(vm)
        "display" -> DisplayPage(vm)
        "clock" -> ClockPage(vm)
        "screensaver" -> ScreensaverPage(vm)
        "weather" -> WeatherPage(vm)
        "system" -> SystemPage(vm)
        "animations" -> AnimationsPage(vm)
        "launcher" -> LauncherPage(vm)
        "boot" -> BootPage(vm)
        "osee" -> OseePage(vm)
        "apps" -> AppsPage(vm)
        else -> AboutPage(vm)
    }
}

/**
 * ColorOS style settings: categories on the left, the selected page on the right. Moving down the list previews each
 * page after a short pause. Left from the left edge of a page returns to the category you came from.
 */
@Composable
fun SettingsScreen(vm: DustViewModel, entry: FocusRequester) {
    val motion = LocalMotion.current
    val page = if (Categories.any { it.id == vm.settingsPage }) vm.settingsPage else "appearance"
    val requesters = remember { Categories.associate { it.id to FocusRequester() } }
    // The selected category carries [entry], so Right from the sidebar and Left from a page both land on it.
    val selectedRequester = entry
    val title = Categories.first { it.id == page }.title

    Row(Modifier.fillMaxSize().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(28.dp)) {
        Column(
            Modifier.width(400.dp).fillMaxHeight().glass(rr(40), 1.2f).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            for (c in Categories) {
                key(c.id) {
                    CategoryItem(c.title, c.glyph, page == c.id, onFocused = { vm.settingsPage = c.id }, requester = if (page == c.id) entry else requesters.getValue(c.id))
                }
            }
        }
        key(page) {
            val fade = remember { Animatable(if (motion.enabled) 0f else 1f) }
            LaunchedEffect(Unit) { if (motion.enabled) fade.animateTo(1f, tween(motion.ms(200))) }
            Box(Modifier.weight(1f).fillMaxHeight().glass(rr(40), 0.9f)) {
                Column(
                    Modifier.fillMaxSize()
                        .graphicsLayer { alpha = fade.value }
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 34.dp, vertical = 26.dp),
                ) {
                    Txt(title, size = 42.sp, weight = FontWeight.SemiBold, modifier = Modifier.padding(start = 10.dp, bottom = 8.dp))
                    CompositionLocalProvider(LocalPageExit provides selectedRequester) {
                        PageContent(vm, page)
                    }
                    VSpace(40)
                }
            }
        }
    }
}

/** Explanation dialog for steps the launcher cannot do by itself. "$ " lines are commands. */
@Composable
fun InfoModal(vm: DustViewModel, info: InfoDialog) {
    val pal = LocalPalette.current
    val first = remember { FocusRequester() }
    val act = info.action
    val label = info.actionLabel
    Modal(onDismiss = { vm.info = null }, width = 1120.dp) {
        ModalTitle(info.title)
        Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
            for (line in info.lines) {
                if (line.startsWith("$ ")) {
                    Txt(
                        line.removePrefix("$ "),
                        size = 21.sp,
                        color = pal.accent2,
                        family = FontFamily.Monospace,
                        maxLines = 3,
                        modifier = Modifier.padding(vertical = 6.dp).fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.30f), rr(14))
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                    )
                } else {
                    Txt(line, size = 23.sp, color = pal.textDim, maxLines = 8, modifier = Modifier.padding(vertical = 6.dp))
                }
            }
        }
        VSpace(24)
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            if (act != null && label != null) {
                GlassButton(label, onClick = { act(); vm.info = null }, primary = true, requester = first)
            }
            GlassButton("Close", onClick = { vm.info = null }, requester = if (act == null || label == null) first else null)
        }
    }
    AutoFocus(first)
}
