package team.deltax.dustos

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import team.deltax.dustos.core.Section
import team.deltax.dustos.launcher.LauncherControl
import team.deltax.dustos.ui.DustRoot
import team.deltax.dustos.ui.FocusMemory
import team.deltax.dustos.ui.Host

/**
 * The launcher screen. It is a single Compose root; this class only does what Compose cannot: Home and assistant
 * intents, runtime permissions, the idle timer for the screensaver, and swallowing the button that wakes it.
 *
 * Nothing runs in the background. The idle timer is one Handler callback that exists only while the launcher is in
 * front, and it is re-armed by each button press.
 */
class MainActivity : ComponentActivity(), Host {
    companion object {
        /** Set by [team.deltax.dustos.osee.OseeEntryActivity] when the system hands the assistant request to DustOS. */
        const val EXTRA_OSEE = "team.deltax.dustos.extra.OSEE"
        const val EXTRA_LISTEN = "team.deltax.dustos.extra.LISTEN"
        private const val NO_KEY = -1
    }

    private val vm: DustViewModel by viewModels()
    private val handler = Handler(Looper.getMainLooper())
    private val idleTask = Runnable { onIdle() }

    /** Key whose press woke the screensaver. Its repeats and its release must not reach the launcher underneath. */
    private var swallowUntilUp = NO_KEY

    private val micRequest = registerForActivityResult(ActivityResultContracts.RequestPermission()) { vm.permTick++ }
    private val locationRequest = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.permTick++
        if (granted) vm.refreshWeather(true)
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent { DustRoot(vm, this@MainActivity) }
        hideSystemUi()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        vm.active = true
        vm.resumeTick++
        vm.refreshUsageRecents()
        vm.refreshWeather(false)
        armIdle()
    }

    override fun onStop() {
        // The TV turned off or another app is in front: stop everything that animates, release the microphone.
        vm.active = false
        handler.removeCallbacks(idleTask)
        vm.oseeVisible = false
        vm.oseeAutoListen = false
        vm.screensaverActive = false
        vm.screensaverPreview = false
        keepAwake(false)
        super.onStop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    private fun hideSystemUi() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ------------------------------------------------------------------ intents

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.getBooleanExtra(EXTRA_OSEE, false)) {
            val listen = i.getBooleanExtra(EXTRA_LISTEN, false)
            // Remove them so the same intent is never acted on twice.
            i.removeExtra(EXTRA_OSEE)
            i.removeExtra(EXTRA_LISTEN)
            endScreensaver()
            if (vm.prefs.oseeEnabled) {
                vm.oseeVisible = true
                if (listen) vm.oseeAutoListen = true
            }
        } else if (i.action == Intent.ACTION_MAIN && i.hasCategory(Intent.CATEGORY_HOME)) {
            goHome()
        }
    }

    /** What a Home press means inside the launcher: close everything and show the home page. */
    private fun goHome() {
        endScreensaver()
        vm.oseeVisible = false
        vm.oseeAutoListen = false
        vm.optionsFor = null
        vm.weatherDetail = false
        vm.systemDetail = false
        vm.info = null
        vm.section = Section.HOME
        FocusMemory.last = null
        vm.homeTick++
    }

    // ------------------------------------------------------------------ screensaver

    private fun armIdle() {
        handler.removeCallbacks(idleTask)
        val p = vm.prefs
        if (!vm.active || !p.ssEnabled || vm.screensaverActive || vm.screensaverPreview) return
        handler.postDelayed(idleTask, p.ssDelay * 60_000L)
    }

    private fun onIdle() {
        val p = vm.prefs
        if (!vm.active || !p.ssEnabled || vm.screensaverActive) return
        // Start from a clean launcher: no dialog, and OSee (with its microphone) closed.
        vm.oseeVisible = false
        vm.oseeAutoListen = false
        vm.optionsFor = null
        vm.weatherDetail = false
        vm.systemDetail = false
        vm.info = null
        vm.screensaverActive = true
        keepAwake(p.ssAwake)
    }

    private fun endScreensaver() {
        vm.screensaverActive = false
        vm.screensaverPreview = false
        keepAwake(false)
        armIdle()
    }

    private fun keepAwake(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ------------------------------------------------------------------ input

    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        val code = ev.keyCode
        if (code == swallowUntilUp) {
            if (ev.action == KeyEvent.ACTION_UP) swallowUntilUp = NO_KEY
            return true
        }
        if (vm.screensaverActive || vm.screensaverPreview) {
            // Any button only closes the screensaver. It does nothing else.
            if (ev.action == KeyEvent.ACTION_DOWN) {
                swallowUntilUp = code
                endScreensaver()
            }
            return true
        }
        if (ev.action == KeyEvent.ACTION_DOWN) armIdle()
        if (isAssistKey(code) && vm.prefs.oseeEnabled && vm.prefs.oseeKeys) {
            // A real button press, so OSee may open the microphone. If it is already open, the key means "talk".
            if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                vm.oseeVisible = true
                vm.oseeAutoListen = true
            }
            return true
        }
        return super.dispatchKeyEvent(ev)
    }

    private fun isAssistKey(code: Int) =
        code == KeyEvent.KEYCODE_ASSIST || code == KeyEvent.KEYCODE_VOICE_ASSIST || code == KeyEvent.KEYCODE_SEARCH

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            if (vm.screensaverActive || vm.screensaverPreview) {
                endScreensaver()
                return true
            }
            armIdle()
        }
        return super.dispatchTouchEvent(ev)
    }

    // ------------------------------------------------------------------ Host (used by Settings and OSee)

    override fun requestHomeRole(): Boolean = LauncherControl.requestDefaultHome(this)

    override fun requestMicPermission() {
        try { micRequest.launch(Manifest.permission.RECORD_AUDIO) } catch (e: Exception) { vm.permTick++ }
    }

    override fun requestLocationPermission() {
        try { locationRequest.launch(Manifest.permission.ACCESS_COARSE_LOCATION) } catch (e: Exception) { vm.permTick++ }
    }

    override fun micGranted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun locationGranted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun speechAvailable(): Boolean = try {
        SpeechRecognizer.isRecognitionAvailable(this)
    } catch (e: Exception) {
        false
    }
}
