package team.deltax.dustos.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * A text box that works with a remote: it is a normal focus target, Select opens the on-screen keyboard, and the
 * keyboard's search / done key submits. If a device has no keyboard app, the typed paths simply are not available.
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun TvTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier,
    outer: FocusRequester = remember { FocusRequester() },
    startEditing: Boolean = false,
) {
    val pal = LocalPalette.current
    val keyboard = LocalSoftwareKeyboardController.current
    val inner = remember { FocusRequester() }
    var editing by remember { mutableStateOf(startEditing) }
    val shape = rr(28)
    LaunchedEffect(editing) {
        if (editing) {
            delay(60)
            try { inner.requestFocus() } catch (e: Exception) { }
            keyboard?.show()
        }
    }
    fun finish() {
        editing = false
        keyboard?.hide()
    }
    Box(
        modifier.fillMaxWidth()
            .leftToCategories()
            .tvFocus(shape, onClick = { editing = true }, scale = 1.012f, requester = outer)
            .glass(shape, 0.8f)
            .padding(horizontal = 28.dp, vertical = 18.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        if (editing) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = TextStyle(color = pal.text, fontSize = 26.sp),
                cursorBrush = SolidColor(pal.accent2),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { finish(); onSubmit() }, onDone = { finish(); onSubmit() }),
                modifier = Modifier.fillMaxWidth().focusRequester(inner).onFocusChanged { if (!it.isFocused && editing) editing = false },
            )
        } else {
            Txt(if (value.isEmpty()) placeholder else value, size = 26.sp, color = if (value.isEmpty()) pal.textFaint else pal.text)
        }
    }
}
