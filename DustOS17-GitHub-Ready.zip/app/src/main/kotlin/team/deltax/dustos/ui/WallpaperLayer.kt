package team.deltax.dustos.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.IntSize
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * The wallpaper behind everything. When live wallpaper is on it breathes very slowly (a few percent of scale and drift,
 * plus two soft light orbs), which is one bitmap draw and two gradients per frame. When animations are off, or the
 * caller says the screen is idle, nothing animates at all.
 */
@Composable
fun WallpaperLayer(animate: Boolean, modifier: Modifier = Modifier) {
    val prefs = LocalPrefs.current
    val motion = LocalMotion.current
    val backdrop = LocalBackdrop.current
    val accent = LocalPalette.current.accent
    val accent2 = LocalPalette.current.accent2
    val live = animate && LocalActive.current && motion.enabled && prefs.liveWallpaper
    val phase: State<Float> = if (live) {
        rememberInfiniteTransition(label = "wallpaper").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween((70_000 / motion.speed).toInt(), easing = LinearEasing), RepeatMode.Restart),
            label = "wallpaperPhase",
        )
    } else {
        remember { mutableFloatStateOf(0f) }
    }
    Box(modifier.fillMaxSize()) {
        Canvas(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val a = phase.value * 2f * PI.toFloat()
                    val sc = if (live) 1.05f + 0.012f * sin(a) else 1f
                    scaleX = sc
                    scaleY = sc
                    if (live) {
                        translationX = size.width * 0.010f * cos(a)
                        translationY = size.height * 0.008f * sin(a * 2f)
                    }
                }
        ) {
            val b = backdrop
            if (b != null) {
                drawImage(b.sharp, dstSize = IntSize(size.width.toInt(), size.height.toInt()), filterQuality = FilterQuality.Medium)
            }
            if (live) {
                val a = phase.value * 2f * PI.toFloat()
                orb(Offset(size.width * (0.28f + 0.10f * cos(a)), size.height * (0.30f + 0.08f * sin(a))), size.height * 0.55f, accent2, 0.20f)
                orb(Offset(size.width * (0.78f + 0.08f * sin(a)), size.height * (0.72f + 0.07f * cos(a))), size.height * 0.62f, accent, 0.18f)
            }
            // keeps text readable on bright wallpapers
            drawRect(Brush.verticalGradient(listOf(Color(0x30100828), Color.Transparent, Color(0x2A100828))))
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.orb(center: Offset, radius: Float, color: Color, alpha: Float) {
    drawCircle(Brush.radialGradient(listOf(color.copy(alpha = alpha), Color.Transparent), center, radius), radius, center)
}
