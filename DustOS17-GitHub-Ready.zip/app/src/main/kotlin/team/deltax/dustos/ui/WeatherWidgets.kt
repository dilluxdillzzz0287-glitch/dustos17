package team.deltax.dustos.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.ClockMath
import team.deltax.dustos.core.Units
import team.deltax.dustos.core.WeatherCodes
import team.deltax.dustos.core.WeatherSnapshot
import team.deltax.dustos.data.WeatherState
import java.util.Calendar
import java.util.Locale

private fun unitSuffix(f: Boolean) = if (f) "F" else "C"

/** Home screen weather summary: icon, temperature, conditions and place. Select opens the detail, holding Select refreshes. */
@Composable
fun WeatherCard(vm: DustViewModel, modifier: Modifier = Modifier) {
    val prefs = vm.prefs
    val pal = LocalPalette.current
    val f = prefs.wxFahrenheit
    val shape = rr(32)
    Box(
        modifier.height(134.dp)
            .tvFocus(shape, onClick = { vm.weatherDetail = true }, onLongClick = { vm.refreshWeather(true) }, memoryKey = "card:weather")
            .glass(shape)
    ) {
        when (val st = vm.weather) {
            is WeatherState.Ready -> {
                val w = st.snap
                Row(Modifier.fillMaxSize().padding(start = 16.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    WeatherIcon(WeatherCodes.kind(w.code), w.isDay, Modifier.size(96.dp))
                    HSpace(14)
                    Column(Modifier.weight(1f)) {
                        Txt(Units.temp(w.tempC, f) + unitSuffix(f), size = 44.sp, weight = FontWeight.Medium)
                        Txt(WeatherCodes.text(w.code), size = 23.sp)
                        Txt(
                            if (st.stale) st.place.substringBefore(',') + " · offline" else st.place.substringBefore(','),
                            size = 19.sp, color = pal.textDim,
                        )
                    }
                    GlyphIcon(Glyph.CHEVRON, Modifier.size(28.dp), tint = pal.textDim)
                }
            }
            WeatherState.Idle, WeatherState.Loading ->
                Box(Modifier.fillMaxSize(), Alignment.Center) { Txt("Loading weather…", size = 23.sp, color = pal.textDim) }
            is WeatherState.Failed ->
                Box(Modifier.fillMaxSize().padding(horizontal = 20.dp), Alignment.Center) {
                    Txt(st.message + " Hold Select to retry.", size = 18.sp, color = pal.textDim, maxLines = 3, align = TextAlign.Center)
                }
        }
    }
}

/** OSee AI shortcut card. Select opens the assistant. It listens only after you press the mic button inside it. */
@Composable
fun OseeCard(vm: DustViewModel, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    val shape = rr(32)
    Row(
        modifier.height(102.dp)
            .tvFocus(shape, onClick = { vm.oseeVisible = true }, memoryKey = "card:osee")
            .glass(shape)
            .padding(start = 18.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(68.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF8FB0FF), Color(0xFFB77CFF), Color(0xFFFF8AC0))), CircleShape)
                .border(2.dp, Color.White.copy(alpha = 0.85f), CircleShape),
            contentAlignment = Alignment.Center,
        ) { GlyphIcon(Glyph.SPARK, Modifier.size(36.dp), tint = Color.White) }
        HSpace(16)
        Column(Modifier.weight(1f)) {
            Txt("OSee AI", size = 24.sp, weight = FontWeight.Medium)
            Txt("Your smart TV assistant", size = 18.sp, color = pal.textDim)
        }
        GlyphIcon(Glyph.CHEVRON, Modifier.size(28.dp), tint = pal.textDim)
    }
}

private fun updatedText(w: WeatherSnapshot, is24: Boolean): String {
    val c = Calendar.getInstance().apply { timeInMillis = w.fetchedAtMs }
    return ClockMath.timeText(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), 0, is24, false, true)
}

/** Full weather: current conditions, feels-like, humidity, wind, sunrise and sunset, and the optional forecast. */
@Composable
fun WeatherDetail(vm: DustViewModel) {
    val prefs = vm.prefs
    val pal = LocalPalette.current
    val f = prefs.wxFahrenheit
    val close = remember { FocusRequester() }
    Modal(onDismiss = { vm.weatherDetail = false }, width = 1300.dp) {
        when (val st = vm.weather) {
            is WeatherState.Ready -> {
                val w = st.snap
                val today = w.today
                ModalTitle(
                    st.place,
                    (if (st.stale) "Offline. Showing the update from " else "Updated ") + updatedText(w, prefs.clock24h) + (st.note?.let { "  ·  $it" } ?: ""),
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    WeatherIcon(WeatherCodes.kind(w.code), w.isDay, Modifier.size(190.dp))
                    HSpace(30)
                    Column(Modifier.weight(1f)) {
                        Txt(Units.temp(w.tempC, f) + unitSuffix(f), size = 96.sp, weight = FontWeight.Light)
                        Txt(WeatherCodes.text(w.code), size = 30.sp, weight = FontWeight.Medium)
                    }
                    Column(Modifier.width(520.dp)) {
                        FactRow("Feels like", Units.temp(w.feelsC, f) + unitSuffix(f))
                        FactRow("Humidity", "${w.humidity}%")
                        FactRow("Wind", Units.wind(w.windKmh, f) + " " + Units.compass(w.windDirDeg))
                        if (today != null) {
                            FactRow("High / Low", Units.temp(today.maxC, f) + " / " + Units.temp(today.minC, f))
                            FactRow("Sunrise", ClockMath.reformatHhmm(today.sunrise, prefs.clock24h))
                            FactRow("Sunset", ClockMath.reformatHhmm(today.sunset, prefs.clock24h))
                        }
                    }
                }
                if (prefs.wxForecast && w.daily.size > 1) {
                    VSpace(18)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        w.daily.take(5).forEachIndexed { i, d ->
                            Column(
                                Modifier.weight(1f).glass(rr(26), 0.8f).padding(vertical = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Txt(if (i == 0) "Today" else ClockMath.weekdayShort(d.dateIso, Locale.getDefault()), size = 21.sp, color = pal.textDim)
                                WeatherIcon(WeatherCodes.kind(d.code), true, Modifier.padding(vertical = 6.dp).size(72.dp))
                                Txt(Units.temp(d.maxC, f) + "  " + Units.temp(d.minC, f), size = 21.sp, weight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
            is WeatherState.Failed -> { ModalTitle("Weather", st.message) }
            else -> { ModalTitle("Weather", "Loading…") }
        }
        VSpace(26)
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            GlassButton("Refresh", { vm.refreshWeather(true) })
            GlassButton(if (f) "Use °C" else "Use °F", { prefs.wxFahrenheit = !f })
            GlassButton("Weather settings", { vm.weatherDetail = false; vm.settingsPage = "weather"; vm.section = team.deltax.dustos.core.Section.SETTINGS })
            GlassButton("Close", { vm.weatherDetail = false }, requester = close, primary = true)
        }
    }
    AutoFocus(close)
}
