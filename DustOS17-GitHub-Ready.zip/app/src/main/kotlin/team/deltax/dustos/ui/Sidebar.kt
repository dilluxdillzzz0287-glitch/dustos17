package team.deltax.dustos.ui

import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.Section

private val SelectedFrom = Color(0xFF7E9CFF)
private val SelectedTo = Color(0xFFB59BFF)

/** Focus handles for the four section entries. The root screen owns them so it can send focus to the selected one. */
class SidebarFocus {
    val home = FocusRequester()
    val apps = FocusRequester()
    val games = FocusRequester()
    val settings = FocusRequester()

    fun of(section: Section): FocusRequester = when (section) {
        Section.HOME -> home
        Section.APPS -> apps
        Section.GAMES -> games
        Section.SETTINGS -> settings
    }
}

/**
 * One sidebar entry. Moving the D-pad across the sections previews each one after a short pause, so flicking past a
 * section never loads it. The selected section gets the glowing blue-lilac pill.
 */
@Composable
private fun SideItem(
    label: String,
    glyph: Glyph,
    selected: Boolean,
    dwell: Boolean,
    requester: FocusRequester? = null,
    onPick: () -> Unit,
) {
    val shape = rr(46)
    var focused by remember { mutableStateOf(false) }
    if (dwell) {
        LaunchedEffect(focused) {
            if (focused) {
                delay(240)
                onPick()
            }
        }
    }
    val fill = Brush.horizontalGradient(listOf(SelectedFrom.copy(alpha = 0.95f), SelectedTo.copy(alpha = 0.95f)))
    Row(
        Modifier.fillMaxWidth()
            .tvFocus(shape, onClick = onPick, scale = 1.04f, requester = requester, onFocusChange = { focused = it }, memoryKey = "side:$label")
            .then(if (selected) Modifier.background(fill, shape).border(1.5.dp, Color.White.copy(alpha = 0.85f), shape) else Modifier)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(58.dp).background(if (selected) Color.White.copy(alpha = 0.92f) else Color.White.copy(alpha = 0.20f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            GlyphIcon(glyph, Modifier.size(30.dp), tint = if (selected) Color(0xFF5B6CFF) else Color.White)
        }
        HSpace(18)
        Txt(label, size = 26.sp, weight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
    }
}

/**
 * Left glass navigation: Home, Apps, Games, Settings, then OSee AI, which opens the assistant instead of a page.
 *
 * Focus rules: Right always goes to [contentEntry] (the first item of the page on screen). Focus that arrives from the
 * page area, for example with Left, is sent to the selected section, so passing by never previews another page.
 */
@Composable
fun Sidebar(vm: DustViewModel, focus: SidebarFocus, contentEntry: FocusRequester, modifier: Modifier = Modifier) {
    var hasFocus by remember { mutableStateOf(false) }
    LaunchedEffect(hasFocus) {
        if (hasFocus && SystemClock.uptimeMillis() >= FocusMemory.quietUntil) {
            try { focus.of(vm.section).requestFocus() } catch (e: Exception) { }
        }
    }
    Column(
        modifier
            .width(258.dp)
            .onFocusChanged { hasFocus = it.hasFocus }
            .onKeyEvent { ev ->
                if (ev.type == KeyEventType.KeyDown && ev.key == Key.DirectionRight) {
                    try { contentEntry.requestFocus(); true } catch (e: Exception) { false }
                } else false
            }
            .glass(rr(46), 1.2f)
            .padding(horizontal = 14.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        SideItem("Home", Glyph.HOME, vm.section == Section.HOME, dwell = true, requester = focus.home) { vm.section = Section.HOME }
        SideItem("Apps", Glyph.APPS, vm.section == Section.APPS, dwell = true, requester = focus.apps) { vm.section = Section.APPS }
        SideItem("Games", Glyph.GAMES, vm.section == Section.GAMES, dwell = true, requester = focus.games) { vm.section = Section.GAMES }
        SideItem("Settings", Glyph.SETTINGS, vm.section == Section.SETTINGS, dwell = true, requester = focus.settings) { vm.section = Section.SETTINGS }
        if (vm.prefs.oseeEnabled) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).height(1.dp).background(Color.White.copy(alpha = 0.24f)))
            SideItem("OSee AI", Glyph.SPARK, selected = false, dwell = false) { vm.oseeVisible = true }
        }
    }
}
