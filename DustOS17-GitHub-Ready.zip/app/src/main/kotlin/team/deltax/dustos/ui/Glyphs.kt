package team.deltax.dustos.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import team.deltax.dustos.core.WeatherKind
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Icons are drawn from a few lines and arcs so the launcher ships without an icon font or the Material icon pack. */
enum class Glyph {
    HOME, APPS, GAMES, SETTINGS, SEARCH, WIFI, ETHERNET, OFFLINE, MIC, PLAY, CHEVRON, CLOSE, CHECK,
    STAR, INFO, MORE, TRASH, EYE_OFF, ARROW_LEFT, ARROW_RIGHT, SPARK, MOON, REFRESH,
    PALETTE, IMAGE, CLOCK, CLOUD, CHIP, POWER, TV,
}

@Composable
fun GlyphIcon(glyph: Glyph, modifier: Modifier = Modifier, tint: Color = LocalPalette.current.text, level: Int = 3) {
    Canvas(modifier) { drawGlyph(glyph, tint, level) }
}

fun DrawScope.drawGlyph(g: Glyph, c: Color, level: Int = 3) {
    val s = size.minDimension
    val sw = s * 0.075f
    val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(x * s, y * s)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, a: Float = 1f) =
        drawLine(c.copy(alpha = c.alpha * a), p(x1, y1), p(x2, y2), strokeWidth = sw, cap = StrokeCap.Round)
    when (g) {
        Glyph.HOME -> {
            val path = Path().apply {
                moveTo(.14f * s, .50f * s); lineTo(.50f * s, .17f * s); lineTo(.86f * s, .50f * s)
                moveTo(.24f * s, .44f * s); lineTo(.24f * s, .82f * s); lineTo(.76f * s, .82f * s); lineTo(.76f * s, .44f * s)
            }
            drawPath(path, c, style = stroke)
            line(.50f, .82f, .50f, .60f)
        }
        Glyph.APPS -> {
            val r = CornerRadius(.07f * s)
            for (ix in 0..1) for (iy in 0..1) {
                drawRoundRect(c, p(.16f + ix * .38f, .16f + iy * .38f), Size(.30f * s, .30f * s), r, Fill)
            }
        }
        Glyph.GAMES -> {
            drawRoundRect(c, p(.10f, .30f), Size(.80f * s, .42f * s), CornerRadius(.20f * s), stroke)
            line(.30f, .43f, .30f, .59f); line(.22f, .51f, .38f, .51f)
            drawCircle(c, .045f * s, p(.64f, .46f)); drawCircle(c, .045f * s, p(.74f, .56f))
        }
        Glyph.SETTINGS -> {
            drawCircle(c, .27f * s, p(.5f, .5f), style = stroke)
            drawCircle(c, .10f * s, p(.5f, .5f), style = stroke)
            for (i in 0 until 8) {
                val a = i * PI.toFloat() / 4f
                line(.5f + .33f * cos(a), .5f + .33f * sin(a), .5f + .43f * cos(a), .5f + .43f * sin(a))
            }
        }
        Glyph.SEARCH -> {
            drawCircle(c, .26f * s, p(.44f, .44f), style = stroke)
            line(.63f, .63f, .85f, .85f)
        }
        Glyph.WIFI, Glyph.OFFLINE -> {
            val dim = g == Glyph.OFFLINE
            for (i in 0..2) {
                val r = (.16f + .16f * i) * s
                val on = !dim && i < level
                drawArc(
                    c.copy(alpha = c.alpha * (if (on) 1f else .28f)), -135f, 90f, false,
                    p(.5f, .80f) - Offset(r, r), Size(2 * r, 2 * r), style = stroke,
                )
            }
            drawCircle(c.copy(alpha = c.alpha * (if (dim) .28f else 1f)), .05f * s, p(.5f, .80f))
            if (dim) line(.16f, .16f, .84f, .88f)
        }
        Glyph.ETHERNET -> {
            drawRoundRect(c, p(.18f, .20f), Size(.64f * s, .46f * s), CornerRadius(.06f * s), stroke)
            line(.36f, .40f, .36f, .56f); line(.50f, .40f, .50f, .56f); line(.64f, .40f, .64f, .56f)
            line(.50f, .66f, .50f, .84f)
        }
        Glyph.MIC -> {
            drawRoundRect(c, p(.38f, .12f), Size(.24f * s, .42f * s), CornerRadius(.12f * s), stroke)
            drawArc(c, 0f, 180f, false, p(.5f - .22f, .46f - .22f), Size(.44f * s, .44f * s), style = stroke)
            line(.50f, .68f, .50f, .84f); line(.36f, .86f, .64f, .86f)
        }
        Glyph.PLAY -> {
            val path = Path().apply { moveTo(.30f * s, .18f * s); lineTo(.82f * s, .50f * s); lineTo(.30f * s, .82f * s); close() }
            drawPath(path, c, style = Fill)
        }
        Glyph.CHEVRON, Glyph.ARROW_RIGHT -> {
            val path = Path().apply { moveTo(.38f * s, .18f * s); lineTo(.66f * s, .50f * s); lineTo(.38f * s, .82f * s) }
            drawPath(path, c, style = stroke)
        }
        Glyph.ARROW_LEFT -> {
            val path = Path().apply { moveTo(.62f * s, .18f * s); lineTo(.34f * s, .50f * s); lineTo(.62f * s, .82f * s) }
            drawPath(path, c, style = stroke)
        }
        Glyph.CLOSE -> { line(.22f, .22f, .78f, .78f); line(.78f, .22f, .22f, .78f) }
        Glyph.CHECK -> {
            val path = Path().apply { moveTo(.20f * s, .54f * s); lineTo(.42f * s, .74f * s); lineTo(.80f * s, .28f * s) }
            drawPath(path, c, style = stroke)
        }
        Glyph.STAR -> {
            val path = Path()
            for (i in 0 until 10) {
                val r = if (i % 2 == 0) .42f else .18f
                val a = (-PI / 2 + i * PI / 5).toFloat()
                val x = (.5f + r * cos(a)) * s
                val y = (.54f + r * sin(a)) * s
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            drawPath(path, c, style = Fill)
        }
        Glyph.INFO -> {
            drawCircle(c, .38f * s, p(.5f, .5f), style = stroke)
            drawCircle(c, .04f * s, p(.5f, .32f)); line(.50f, .46f, .50f, .70f)
        }
        Glyph.MORE -> { for (i in 0..2) drawCircle(c, .06f * s, p(.24f + i * .26f, .5f)) }
        Glyph.TRASH -> {
            line(.22f, .28f, .78f, .28f)
            val body = Path().apply { moveTo(.30f * s, .28f * s); lineTo(.34f * s, .84f * s); lineTo(.66f * s, .84f * s); lineTo(.70f * s, .28f * s) }
            drawPath(body, c, style = stroke)
            line(.42f, .28f, .42f, .17f); line(.42f, .17f, .58f, .17f); line(.58f, .17f, .58f, .28f)
        }
        Glyph.EYE_OFF -> {
            drawOval(c, p(.10f, .30f), Size(.80f * s, .40f * s), style = stroke)
            drawCircle(c, .08f * s, p(.5f, .5f)); line(.18f, .14f, .82f, .86f)
        }
        Glyph.SPARK -> {
            val path = Path().apply {
                moveTo(.5f * s, .06f * s)
                quadraticBezierTo(.56f * s, .44f * s, .94f * s, .5f * s)
                quadraticBezierTo(.56f * s, .56f * s, .5f * s, .94f * s)
                quadraticBezierTo(.44f * s, .56f * s, .06f * s, .5f * s)
                quadraticBezierTo(.44f * s, .44f * s, .5f * s, .06f * s)
                close()
            }
            drawPath(path, c, style = Fill)
        }
        Glyph.MOON -> {
            val a = Path().apply { addOval(androidx.compose.ui.geometry.Rect(p(.14f, .18f), Size(.64f * s, .64f * s))) }
            val b = Path().apply { addOval(androidx.compose.ui.geometry.Rect(p(.36f, .08f), Size(.58f * s, .58f * s))) }
            drawPath(pathDifference(a, b), c, style = Fill)
        }
        Glyph.REFRESH -> {
            drawArc(c, -60f, 280f, false, p(.2f, .2f), Size(.6f * s, .6f * s), style = stroke)
            line(.74f, .14f, .74f, .34f); line(.74f, .34f, .54f, .34f)
        }
        Glyph.PALETTE -> {
            drawCircle(c, .38f * s, p(.5f, .5f), style = stroke)
            drawCircle(c, .055f * s, p(.36f, .42f)); drawCircle(c, .055f * s, p(.54f, .32f)); drawCircle(c, .055f * s, p(.68f, .50f))
        }
        Glyph.IMAGE -> {
            drawRoundRect(c, p(.12f, .20f), Size(.76f * s, .60f * s), CornerRadius(.08f * s), stroke)
            drawCircle(c, .06f * s, p(.34f, .40f))
            val hills = Path().apply {
                moveTo(.18f * s, .74f * s); lineTo(.42f * s, .52f * s); lineTo(.58f * s, .66f * s); lineTo(.68f * s, .58f * s); lineTo(.82f * s, .74f * s)
            }
            drawPath(hills, c, style = stroke)
        }
        Glyph.CLOCK -> {
            drawCircle(c, .38f * s, p(.5f, .5f), style = stroke)
            line(.50f, .50f, .50f, .27f); line(.50f, .50f, .66f, .58f)
        }
        Glyph.CLOUD -> {
            drawCircle(c, .17f * s, p(.34f, .56f)); drawCircle(c, .22f * s, p(.52f, .46f)); drawCircle(c, .17f * s, p(.68f, .58f))
            drawRoundRect(c, p(.20f, .56f), Size(.60f * s, .22f * s), CornerRadius(.11f * s), Fill)
        }
        Glyph.CHIP -> {
            drawRoundRect(c, p(.26f, .26f), Size(.48f * s, .48f * s), CornerRadius(.06f * s), stroke)
            for (i in 0..2) {
                val v = .38f + i * .12f
                line(v, .12f, v, .26f); line(v, .74f, v, .88f); line(.12f, v, .26f, v); line(.74f, v, .88f, v)
            }
        }
        Glyph.POWER -> {
            drawArc(c, -60f, 300f, false, p(.2f, .24f), Size(.6f * s, .6f * s), style = stroke)
            line(.50f, .12f, .50f, .48f)
        }
        Glyph.TV -> {
            drawRoundRect(c, p(.10f, .18f), Size(.80f * s, .50f * s), CornerRadius(.07f * s), stroke)
            line(.50f, .68f, .50f, .84f); line(.34f, .84f, .66f, .84f)
        }
    }
}

/** Weather art drawn in code: no image assets, scales to any size, and day and night variants. */
@Composable
fun WeatherIcon(kind: WeatherKind, isDay: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) { drawWeather(kind, isDay) }
}

private val SunBrush = listOf(Color(0xFFFFE27A), Color(0xFFFFA63D))
private val CloudTop = Color(0xFFFFFFFF)
private val CloudBottom = Color(0xFFC9C6EE)
private val StormTop = Color(0xFF8D88B8)
private val StormBottom = Color(0xFF55507F)

private fun DrawScope.sun(cx: Float, cy: Float, r: Float) {
    for (i in 0 until 8) {
        val a = i * PI.toFloat() / 4f
        drawLine(
            Color(0xFFFFC857), Offset(cx + r * 1.4f * cos(a), cy + r * 1.4f * sin(a)),
            Offset(cx + r * 1.8f * cos(a), cy + r * 1.8f * sin(a)), strokeWidth = r * 0.24f, cap = StrokeCap.Round,
        )
    }
    drawCircle(Brush.radialGradient(SunBrush, Offset(cx, cy), r), r, Offset(cx, cy))
}

/** Shape [a] with [b] cut out of it. Uses the instance method Path.op, which every Compose version has. */
private fun pathDifference(a: Path, b: Path): Path {
    val out = Path()
    out.op(a, b, PathOperation.Difference)
    return out
}

private fun DrawScope.moon(cx: Float, cy: Float, r: Float) {
    val a = Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(cx - r, cy - r), Size(2 * r, 2 * r))) }
    val b = Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(cx - r * .35f, cy - r * 1.2f), Size(2 * r * .95f, 2 * r * .95f))) }
    drawPath(pathDifference(a, b), Color(0xFFFFF1B8), style = Fill)
}

private fun DrawScope.cloud(cx: Float, cy: Float, w: Float, top: Color = CloudTop, bottom: Color = CloudBottom) {
    val brush = Brush.verticalGradient(listOf(top, bottom), startY = cy - w * .32f, endY = cy + w * .22f)
    drawCircle(brush, w * .17f, Offset(cx - w * .22f, cy + w * .03f))
    drawCircle(brush, w * .24f, Offset(cx - w * .02f, cy - w * .08f))
    drawCircle(brush, w * .15f, Offset(cx + w * .24f, cy + w * .04f))
    drawRoundRect(brush, Offset(cx - w * .38f, cy - w * .02f), Size(w * .76f, w * .22f), CornerRadius(w * .11f))
}

private fun DrawScope.drops(cx: Float, y: Float, w: Float, color: Color) {
    for (i in -1..1) {
        val x = cx + i * w * .2f
        drawLine(color, Offset(x + w * .03f, y), Offset(x - w * .03f, y + w * .15f), strokeWidth = w * .045f, cap = StrokeCap.Round)
    }
}

fun DrawScope.drawWeather(kind: WeatherKind, isDay: Boolean) {
    val s = size.minDimension
    val cx = size.width / 2f
    val cy = size.height / 2f
    when (kind) {
        WeatherKind.CLEAR -> if (isDay) sun(cx, cy, s * .24f) else moon(cx, cy, s * .30f)
        WeatherKind.PARTLY_CLOUDY -> {
            if (isDay) sun(cx - s * .13f, cy - s * .13f, s * .17f) else moon(cx - s * .13f, cy - s * .13f, s * .20f)
            cloud(cx + s * .06f, cy + s * .12f, s * .78f)
        }
        WeatherKind.CLOUDY -> {
            cloud(cx - s * .10f, cy - s * .08f, s * .62f, Color(0xFFD9D7F2), Color(0xFF9E9AC8))
            cloud(cx + s * .06f, cy + s * .08f, s * .78f)
        }
        WeatherKind.FOG -> {
            cloud(cx, cy - s * .12f, s * .66f, Color(0xFFE6E4F6), Color(0xFFB4B1D8))
            for (i in 0..2) drawLine(
                Color.White.copy(alpha = .75f), Offset(cx - s * .30f, cy + s * (.14f + i * .11f)),
                Offset(cx + s * (.30f - i * .06f), cy + s * (.14f + i * .11f)), strokeWidth = s * .05f, cap = StrokeCap.Round,
            )
        }
        WeatherKind.DRIZZLE -> {
            cloud(cx, cy - s * .08f, s * .80f)
            drops(cx, cy + s * .22f, s * .60f, Color(0xFF8FD3FF).copy(alpha = .8f))
        }
        WeatherKind.RAIN -> {
            cloud(cx, cy - s * .10f, s * .82f, Color(0xFFDAD8F0), Color(0xFF9692C4))
            drops(cx, cy + s * .20f, s * .70f, Color(0xFF58B9FF))
        }
        WeatherKind.SNOW -> {
            cloud(cx, cy - s * .10f, s * .82f)
            for (i in -1..1) drawCircle(Color.White, s * .035f, Offset(cx + i * s * .16f, cy + s * (.27f + (if (i == 0) .05f else 0f))))
        }
        WeatherKind.STORM -> {
            cloud(cx, cy - s * .12f, s * .84f, StormTop, StormBottom)
            val bolt = Path().apply {
                moveTo(cx + s * .04f, cy + s * .06f); lineTo(cx - s * .08f, cy + s * .26f)
                lineTo(cx, cy + s * .26f); lineTo(cx - s * .06f, cy + s * .44f)
                lineTo(cx + s * .12f, cy + s * .20f); lineTo(cx + s * .03f, cy + s * .20f); close()
            }
            drawPath(bolt, Color(0xFFFFD84D), style = Fill)
        }
    }
}
