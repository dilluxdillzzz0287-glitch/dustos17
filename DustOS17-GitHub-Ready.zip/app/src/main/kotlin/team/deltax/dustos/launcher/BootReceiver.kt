package team.deltax.dustos.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import team.deltax.dustos.data.LauncherPrefs

/**
 * Opens the launcher a couple of seconds after the device has booted, but only when "Open DustOS after a restart" is
 * on. The short wait lets the system finish showing its own home screen first, so DustOS ends up in front.
 *
 * On Android 10 and newer the system only allows this when DustOS has "Display over other apps". Without it the
 * start is silently ignored by Android. Nothing else happens here and nothing stays running afterwards.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != "android.intent.action.QUICKBOOT_POWERON") return
        val app = context.applicationContext
        if (!LauncherPrefs.get(app).startOnBoot) return
        val pending = goAsync()
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                LauncherControl.bringToFront(app)
            } finally {
                pending.finish()
            }
        }, 2000L)
    }
}
