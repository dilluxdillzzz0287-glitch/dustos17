package team.deltax.dustos.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Centered glass dialog over a dimmed scrim. Back closes it. Springs in unless animations are off. */
@Composable
fun Modal(
    onDismiss: () -> Unit,
    width: Dp,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    val motion = LocalMotion.current
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val k by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = motion.spec(spring(dampingRatio = 0.78f, stiffness = 320f * motion.speed)),
        label = "modal",
    )
    BackHandler(onBack = onDismiss)
    Box(Modifier.fillMaxSize().background(Color(0xFF050410).copy(alpha = 0.66f * k.coerceIn(0f, 1f)))) {
        Column(
            modifier
                .align(Alignment.Center)
                .graphicsLayer {
                    val s = 0.92f + 0.08f * k
                    scaleX = s
                    scaleY = s
                    alpha = k.coerceIn(0f, 1f)
                }
                .width(width)
                .glass(rr(40), 1.6f)
                .padding(40.dp),
            content = content,
        )
    }
}

/** Requests focus once the target is on screen. Safe to call when the requester is not attached yet. */
@Composable
fun AutoFocus(requester: FocusRequester, key: Any? = Unit) {
    LaunchedEffect(key) {
        kotlinx.coroutines.delay(60)
        try { requester.requestFocus() } catch (e: Exception) { }
    }
}

@Composable
fun ModalTitle(title: String, subtitle: String? = null) {
    Txt(title, size = 38.sp, weight = FontWeight.SemiBold)
    if (subtitle != null) Txt(subtitle, size = 20.sp, color = LocalPalette.current.textDim, maxLines = 2)
    VSpace(22)
}

/** Two column label / value line for detail dialogs. */
@Composable
fun FactRow(label: String, value: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(vertical = 7.dp)) {
        Txt(label, size = 23.sp, color = LocalPalette.current.textDim, modifier = Modifier.width(250.dp))
        Txt(value, size = 23.sp, weight = FontWeight.Medium, maxLines = 2)
    }
}

/** Thin labelled progress bar: the label on the left, the value on the right, the bar underneath. */
@Composable
fun StatBar(label: String, valueText: String, frac: Float?, color: Color, modifier: Modifier = Modifier) {
    val motion = LocalMotion.current
    val animated by animateFloatAsState(
        targetValue = (frac ?: 0f).coerceIn(0f, 1f),
        animationSpec = motion.spec(spring(dampingRatio = 0.8f, stiffness = 140f)),
        label = "bar",
    )
    Column(modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Txt(label, size = 19.sp, color = LocalPalette.current.textDim, modifier = Modifier.weight(1f))
            Txt(valueText, size = 19.sp, weight = FontWeight.Medium)
        }
        if (frac != null) {
            Box(Modifier.padding(top = 5.dp).fillMaxWidth().height(7.dp).background(Color.White.copy(alpha = 0.16f), rr(8))) {
                Box(Modifier.fillMaxWidth(animated).height(7.dp).background(color, rr(8)))
            }
        }
    }
}
