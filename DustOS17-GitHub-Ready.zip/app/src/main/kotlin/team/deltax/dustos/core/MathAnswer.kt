package team.deltax.dustos.core

import java.math.BigDecimal
import java.math.RoundingMode

/** Result of a spoken or typed calculation. [display] is for the screen, [spoken] for text-to-speech. */
data class MathResult(val display: String, val spoken: String)

/**
 * OSee has no cloud brain, so it only answers what it can prove: simple arithmetic and percentages.
 * Anything else is passed on honestly (see OseeSession). Works on the raw text because normalising it
 * would throw away the operator symbols.
 */
object MathAnswer {
    private val numberWords = mapOf(
        "zero" to "0", "one" to "1", "two" to "2", "three" to "3", "four" to "4", "five" to "5", "six" to "6",
        "seven" to "7", "eight" to "8", "nine" to "9", "ten" to "10", "eleven" to "11", "twelve" to "12",
        "thirteen" to "13", "fourteen" to "14", "fifteen" to "15", "sixteen" to "16", "seventeen" to "17",
        "eighteen" to "18", "nineteen" to "19", "twenty" to "20", "thirty" to "30", "forty" to "40",
        "fifty" to "50", "sixty" to "60", "seventy" to "70", "eighty" to "80", "ninety" to "90",
    )

    private val percentOf = Regex("""(-?\d+(?:\.\d+)?)\s*(?:percent|per cent|%)\s*of\s*(-?\d+(?:\.\d+)?)""")

    fun answer(raw: String): MathResult? {
        var t = " " + raw.lowercase().replace('×', '*').replace('÷', '/').replace('−', '-').replace(',', ' ') + " "
        for ((w, d) in numberWords) t = t.replace(Regex("\\b$w\\b"), d)

        percentOf.find(t)?.let { m ->
            val pct = m.groupValues[1].toBigDecimalOrNull() ?: return null
            val whole = m.groupValues[2].toBigDecimalOrNull() ?: return null
            val v = pct.multiply(whole).divide(BigDecimal(100))
            val shown = fmt(v)
            return MathResult("${m.groupValues[1]}% of ${m.groupValues[2]} = $shown", "The answer is $shown")
        }

        t = t.replace(" multiplied by ", " * ").replace(" times ", " * ").replace(" into ", " * ")
            .replace(" divided by ", " / ").replace(" over ", " / ")
            .replace(" plus ", " + ").replace(" add ", " + ").replace(" minus ", " - ").replace(" subtract ", " - ")
        t = Regex("""(?<=\d)\s*x\s*(?=\d)""").replace(t, " * ")

        val kept = StringBuilder()
        for (ch in t) if (ch.isDigit() || ch in ".+-*/()") kept.append(ch) else kept.append(' ')
        val expr = kept.toString().trim().replace(Regex("\\s+"), " ")
        if (expr.none { it.isDigit() } || expr.none { it in "+-*/" }) return null

        val value = try { Parser(expr).parseAll() } catch (e: DivideByZero) {
            return MathResult("Can't divide by zero", "That can't be done, you can't divide by zero")
        } catch (e: Exception) {
            return null
        } ?: return null
        val shown = fmt(value)
        val pretty = expr.replace("*", "×").replace("/", "÷")
        return MathResult("$pretty = $shown", "The answer is $shown")
    }

    private fun fmt(v: BigDecimal): String {
        if (v.abs() >= BigDecimal("1e15")) return String.format(java.util.Locale.US, "%.6e", v)
        val s = v.setScale(6, RoundingMode.HALF_UP).stripTrailingZeros()
        return if (s.scale() < 0) s.setScale(0).toPlainString() else s.toPlainString()
    }

    private class DivideByZero : RuntimeException()

    /** expr := term (("+" | "-") term)*, term := factor (("*" | "/") factor)*, factor := "-"? (number | "(" expr ")") */
    private class Parser(private val s: String) {
        private var i = 0

        fun parseAll(): BigDecimal? {
            val v = expr()
            skip()
            return if (i == s.length) v else null
        }

        private fun skip() { while (i < s.length && s[i] == ' ') i++ }

        private fun expr(): BigDecimal {
            var v = term()
            while (true) {
                skip()
                if (i < s.length && s[i] == '+') { i++; v = v.add(term()) }
                else if (i < s.length && s[i] == '-') { i++; v = v.subtract(term()) }
                else return v
            }
        }

        private fun term(): BigDecimal {
            var v = factor()
            while (true) {
                skip()
                if (i < s.length && s[i] == '*') { i++; v = v.multiply(factor()) }
                else if (i < s.length && s[i] == '/') {
                    i++
                    val d = factor()
                    if (d.signum() == 0) throw DivideByZero()
                    v = v.divide(d, 12, RoundingMode.HALF_UP)
                } else return v
            }
        }

        private fun factor(): BigDecimal {
            skip()
            if (i < s.length && s[i] == '-') { i++; return factor().negate() }
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                skip()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException("missing )")
                i++
                return v
            }
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (start == i) throw IllegalArgumentException("number expected")
            return BigDecimal(s.substring(start, i))
        }
    }
}
