package team.deltax.dustos.ui

import android.graphics.Bitmap
import android.widget.VideoView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.Body
import team.deltax.dustos.core.ClockMath
import team.deltax.dustos.core.LayerDef
import team.deltax.dustos.core.LayerKind
import team.deltax.dustos.core.SceneArt
import team.deltax.dustos.core.SceneDef
import team.deltax.dustos.core.Units
import team.deltax.dustos.core.WeatherCodes
import team.deltax.dustos.data.WeatherState
import java.io.File
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** Screen pixels per second that the nearest layer drifts at 100% speed on a 1920 wide screen. */
private const val DriftPxPerSecond = 28f

private class BakedLayer(val def: LayerDef, val image: ImageBitmap)

private fun rgb(c: Int) = Color(0xFF000000.toInt() or c)

/** Bakes the scene's layers off the main thread. Null until they are ready, so the sky shows first and the layers fade in. */
@Composable
private fun rememberBakedLayers(sceneId: String, depthPct: Int): State<List<BakedLayer>?> =
    produceState<List<BakedLayer>?>(null, sceneId, depthPct) {
        value = null
        value = withContext(Dispatchers.Default) {
            val scene = SceneArt.byId(sceneId)
            scene.layers.sortedBy { it.z }.map { def ->
                val px = SceneArt.render(scene, def, depthPct / 100f)
                val bh = SceneArt.bandHeight(def, SceneArt.RENDER_H)
                BakedLayer(def, Bitmap.createBitmap(px, SceneArt.RENDER_W, bh, Bitmap.Config.ARGB_8888).asImageBitmap())
            }
        }
    }

/** Seconds since the scene started, advanced about 30 times a second. It stands still when [running] is false. */
@Composable
private fun rememberSceneSeconds(running: Boolean): State<Float> {
    val t = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        var last = withFrameNanos { it }
        var acc = 0L
        while (true) {
            val now = withFrameNanos { it }
            acc += now - last
            last = now
            if (acc >= 33_000_000L) {
                t.floatValue += acc / 1_000_000_000f
                acc = 0L
            }
        }
    }
    return t
}

private fun DrawScope.drawBody(b: Body, t: Float) {
    val sway = b.z.coerceAtLeast(0.05f)
    val c = Offset(size.width * b.x + 12f * sin(t / 40f) * sway * 4f, size.height * b.y + 6f * cos(t / 55f))
    val r = size.height * b.r
    val glow = rgb(b.glow)
    val core = rgb(b.color)
    val glowR = r * 4.2f
    drawCircle(Brush.radialGradient(listOf(glow.copy(alpha = 0.55f), glow.copy(alpha = 0.16f), Color.Transparent), c, glowR), glowR, c)
    if (!b.ring) {
        drawCircle(core, r, c)
        return
    }
    // A planet: the far half of the ring, the shaded disc, then the near half of the ring.
    val ringTop = Offset(c.x - r * 1.55f, c.y - r * 0.30f)
    val ringSize = Size(r * 3.1f, r * 0.60f)
    val ringColor = Color.White.copy(alpha = 0.34f)
    val stroke = Stroke(width = r * 0.045f)
    rotate(-14f, c) {
        drawArc(ringColor, 180f, 180f, false, ringTop, ringSize, style = stroke)
    }
    drawCircle(
        Brush.radialGradient(listOf(lerp(core, Color.White, 0.35f), core, lerp(core, Color.Black, 0.55f)), Offset(c.x - r * 0.35f, c.y - r * 0.35f), r * 1.5f),
        r, c,
    )
    rotate(-14f, c) {
        drawArc(ringColor, 0f, 180f, false, ringTop, ringSize, style = stroke)
    }
}

private fun DrawScope.drawLayers(layers: List<BakedLayer>, t: Float, depth: Float, speed: Float) {
    val w = size.width
    val h = size.height
    val scale = w / SceneArt.RENDER_W
    for (l in layers) {
        val z = l.def.z
        // Far layers crawl, near layers glide. Depth 0 makes them all move together, which flattens the scene.
        val v = DriftPxPerSecond * speed * (0.5f + (z - 0.5f) * depth) * (w / 1920f)
        val shift = (t * v) % w
        val bob = (0.5f + 0.5f * sin(t * 0.21f + z * 5f)) * 9f * z * depth * (h / 1080f)
        val top = SceneArt.bandTop(l.def, SceneArt.RENDER_H) * scale + bob
        val dst = IntSize(w.roundToInt(), (l.image.height * scale).roundToInt() + 1)
        val alpha = when (l.def.kind) {
            LayerKind.STARS -> 0.82f + 0.18f * sin(t * 1.3f + z * 9f)
            LayerKind.RIBBON, LayerKind.NEBULA -> 0.86f + 0.14f * sin(t * 0.35f + z * 7f)
            else -> 1f
        }
        translate(left = -shift, top = top) {
            drawImage(l.image, dstSize = dst, alpha = alpha, filterQuality = FilterQuality.Low)
            if (shift > 0.5f) translate(left = w) { drawImage(l.image, dstSize = dst, alpha = alpha, filterQuality = FilterQuality.Low) }
        }
    }
}

/**
 * The layered scene with the clock between the layers: far layers are drawn first, then the clock, then the near
 * layers, so mountains, buildings or ribbons pass in front of the digits as they drift. Everything is two canvases and
 * a handful of textured quads, drawn about 30 times a second, and nothing is drawn when the launcher is stopped.
 */
@Composable
private fun SceneStage(sceneId: String, depthPct: Int, speedPct: Int, parallax: Boolean, running: Boolean, clock: @Composable () -> Unit) {
    val scene: SceneDef = remember(sceneId) { SceneArt.byId(sceneId) }
    val baked by rememberBakedLayers(sceneId, depthPct)
    val back = remember(baked, scene) { baked?.filter { it.def.z <= scene.clockZ } }
    val front = remember(baked, scene) { baked?.filter { it.def.z > scene.clockZ } }
    val time = rememberSceneSeconds(running)
    // Depth parallax off: every layer drifts at the same speed and none bobs, so the scene reads as one flat picture.
    val depth = if (parallax) depthPct / 100f else 0f
    val speed = speedPct / 100f
    val reveal by animateFloatAsState(if (baked != null) 1f else 0f, tween(900), label = "layers")
    val skyStops = remember(sceneId) { Array(scene.sky.size) { i -> scene.skyStops[i] to rgb(scene.sky[i]) } }

    Box(Modifier.fillMaxSize()) {
        // sky and the bodies that sit behind the clock
        Box(
            Modifier.fillMaxSize().drawWithCache {
                val sky = Brush.verticalGradient(*skyStops, startY = 0f, endY = size.height)
                onDrawBehind {
                    drawRect(sky)
                    val t = time.value
                    for (b in scene.bodies) if (b.z <= scene.clockZ) drawBody(b, t)
                }
            }
        )
        // far layers, behind the clock
        Box(
            Modifier.fillMaxSize().graphicsLayer { alpha = reveal.coerceIn(0f, 1f) }.drawWithCache {
                onDrawBehind {
                    val layers = back
                    if (layers != null) drawLayers(layers, time.value, depth, speed)
                }
            }
        )
        Box(
            Modifier.fillMaxSize().graphicsLayer {
                // A slow drift of a few pixels keeps a static clock from burning into the panel.
                val t = time.value
                translationX = 14f * sin(t / 23f)
                translationY = 10f * cos(t / 31f)
            }
        ) { clock() }
        // near layers and foreground bodies, in front of the clock
        Box(
            Modifier.fillMaxSize().graphicsLayer { alpha = reveal.coerceIn(0f, 1f) }.drawWithCache {
                onDrawBehind {
                    val t = time.value
                    for (b in scene.bodies) if (b.z > scene.clockZ) drawBody(b, t)
                    val layers = front
                    if (layers != null) drawLayers(layers, t, depth, speed)
                }
            }
        )
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
private fun VideoStage(file: File, onError: () -> Unit) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            VideoView(ctx).apply {
                setOnPreparedListener { mp ->
                    mp.isLooping = true
                    try { mp.setVolume(0f, 0f) } catch (e: Exception) { }
                }
                setOnErrorListener { _, _, _ -> onError(); true }
                setVideoPath(file.absolutePath)
                start()
            }
        },
        onRelease = { v -> try { v.stopPlayback() } catch (e: Exception) { } },
    )
}

@Composable
private fun Divider() {
    Box(Modifier.padding(horizontal = 26.dp).width(1.dp).height(72.dp).background(Color.White.copy(alpha = 0.22f)))
}

/** The weather strip: conditions, feels-like, humidity, wind, sunrise and sunset, place, and the next days if forecast is on. */
@Composable
private fun ScreensaverWeather(vm: DustViewModel, modifier: Modifier) {
    val st = vm.weather as? WeatherState.Ready ?: return
    val p = vm.prefs
    val pal = LocalPalette.current
    val f = p.wxFahrenheit
    val w = st.snap
    val today = w.today
    val shape = rr(36)
    val unit = if (f) "F" else "C"
    Row(
        modifier.background(Color(0x7010082A), shape).border(1.dp, Color.White.copy(alpha = 0.22f), shape)
            .padding(horizontal = 30.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        WeatherIcon(WeatherCodes.kind(w.code), w.isDay, Modifier.size(88.dp))
        HSpace(18)
        Column {
            Txt(Units.temp(w.tempC, f) + unit, size = 52.sp, weight = FontWeight.Light)
            Txt(WeatherCodes.text(w.code), size = 22.sp)
        }
        Divider()
        Column {
            Txt("Feels like ${Units.temp(w.feelsC, f)}", size = 21.sp)
            Txt("Humidity ${w.humidity}%", size = 21.sp)
            Txt("Wind ${Units.wind(w.windKmh, f)} ${Units.compass(w.windDirDeg)}", size = 21.sp)
        }
        Divider()
        Column {
            Txt(st.place.substringBefore(',') + if (st.stale) " · offline" else "", size = 21.sp, weight = FontWeight.Medium)
            if (today != null) {
                Txt("Sunrise ${ClockMath.reformatHhmm(today.sunrise, p.clock24h)}", size = 20.sp, color = pal.textDim)
                Txt("Sunset ${ClockMath.reformatHhmm(today.sunset, p.clock24h)}", size = 20.sp, color = pal.textDim)
            }
        }
        if (p.wxForecast && w.daily.size > 1) {
            Divider()
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(22.dp)) {
                for (d in w.daily.drop(1).take(4)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Txt(ClockMath.weekdayShort(d.dateIso, Locale.getDefault()), size = 19.sp, color = pal.textDim)
                        WeatherIcon(WeatherCodes.kind(d.code), true, Modifier.padding(vertical = 2.dp).size(44.dp))
                        Txt(Units.temp(d.maxC, f) + " " + Units.temp(d.minC, f), size = 19.sp)
                    }
                }
            }
        }
    }
}

/**
 * The DustOS screensaver. Started by the idle timer or by Preview, closed by any button. It shows either a layered
 * scene with the clock inside it, or a looping video from the app's own folder, with the weather on top. The Home
 * screen is not composed while this is up, and the whole thing stops when the launcher is no longer in front.
 */
@Composable
fun ScreensaverOverlay(vm: DustViewModel) {
    val p = vm.prefs
    val motion = LocalMotion.current
    val active = LocalActive.current
    val nowMs by rememberNowMs(everySecond = p.clockSeconds)
    val file = remember(p.ssVideo) { if (p.ssVideo.isNotEmpty()) File(p.ssVideo).takeIf { it.isFile && it.canRead() } else null }
    var videoFailed by remember(p.ssVideo) { mutableStateOf(false) }
    val showVideo = file != null && !videoFailed
    val preview = vm.screensaverPreview && !vm.screensaverActive

    LaunchedEffect(Unit) { if (p.ssWeather && p.wxEnabled) vm.refreshWeather(false) }

    var hint by remember { mutableStateOf(preview) }
    LaunchedEffect(preview) {
        if (preview) {
            hint = true
            delay(4500)
            hint = false
        }
    }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val fade by animateFloatAsState(if (shown) 1f else 0f, tween(motion.ms(700)), label = "screensaverFade")

    Box(Modifier.fillMaxSize().background(Color.Black).graphicsLayer { alpha = fade }) {
        if (showVideo) {
            VideoStage(file!!) { videoFailed = true }
            if (p.ssClock) PositionedClock(p.clockSpec(), p.clockPos, p.clockOffX, p.clockOffY, nowMs, Modifier.fillMaxSize())
        } else {
            SceneStage(p.ssScene, p.ssDepth, p.ssSpeed, p.parallax, running = active && motion.enabled) {
                if (p.ssClock) PositionedClock(p.clockSpec(), p.clockPos, p.clockOffX, p.clockOffY, nowMs, Modifier.fillMaxSize())
            }
        }
        if (p.ssWeather && p.wxEnabled) ScreensaverWeather(vm, Modifier.align(Alignment.BottomCenter).padding(bottom = 54.dp))
        if (p.ssDim > 0) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = p.ssDim / 100f)))
        if (hint) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = 40.dp)
                    .background(Color(0x99100A2C), rr(30)).padding(horizontal = 28.dp, vertical = 10.dp)
            ) { Txt("Preview. Press any button to come back.", size = 21.sp) }
        }
    }
}
