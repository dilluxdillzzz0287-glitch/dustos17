package team.deltax.dustos.core

import java.util.Calendar
import java.util.Locale

/** The sentences OSee says for questions it can answer from real device data. Pure text, so it is unit tested. */
object OseeText {
    fun greeting(hour: Int): String {
        val hello = when (hour) {
            in 5..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            in 17..21 -> "Good evening"
            else -> "Hello"
        }
        return "$hello! Ask me to open an app, search, or change a setting. Say help to hear what I can do."
    }

    fun time(hour: Int, minute: Int, is24: Boolean): String =
        "It's ${ClockMath.timeText(hour, minute, 0, is24, false, true)}."

    fun date(cal: Calendar, locale: Locale): String =
        "Today is ${ClockMath.dateText(cal, locale, true, true)}."

    fun weather(snap: WeatherSnapshot, place: String, fahrenheit: Boolean, stale: Boolean): String {
        val where = place.substringBefore(',').trim().let { if (it.isEmpty()) "" else " in $it" }
        val sb = StringBuilder()
        sb.append("It's ${Units.temp(snap.tempC, fahrenheit)} and ${WeatherCodes.text(snap.code).lowercase()}$where. ")
        sb.append("Feels like ${Units.temp(snap.feelsC, fahrenheit)}, humidity ${snap.humidity} percent, ")
        sb.append("wind ${Units.wind(snap.windKmh, fahrenheit)} from the ${Units.compass(snap.windDirDeg)}.")
        snap.today?.let {
            sb.append(" Today's high is ${Units.temp(it.maxC, fahrenheit)} and the low is ${Units.temp(it.minC, fahrenheit)}.")
        }
        if (stale) sb.append(" This is the last saved update, the network wasn't reachable.")
        return sb.toString()
    }

    /** Never says anything was cleared or freed. Android manages RAM, and DustOS only reads the numbers. */
    fun memory(total: Long, avail: Long, low: Boolean): String {
        val used = (total - avail).coerceAtLeast(0L)
        val sb = StringBuilder("Memory is ${Units.percent(used, total)} percent in use: ${Units.humanBytes(used)} of ${Units.humanBytes(total)}, with ${Units.humanBytes(avail)} available.")
        if (low) sb.append(" Android says memory is low right now.")
        sb.append(" Android manages RAM itself, so I don't clear it.")
        return sb.toString()
    }

    fun storage(total: Long, free: Long): String {
        if (total <= 0L) return "I couldn't read the storage size on this device."
        val used = (total - free).coerceAtLeast(0L)
        return "Storage has ${Units.humanBytes(free)} free of ${Units.humanBytes(total)}, ${Units.percent(used, total)} percent used."
    }

    const val WHO =
        "I'm OSee, the assistant built into DustOS 17. I'm not Alexa. Alexa is separate and still has its own button."

    const val HELP =
        "I can open apps, search, go to Home, Apps, Games or Settings, tell you the time, date, weather, memory and storage, " +
            "change a few launcher settings, open Wi-Fi, display or sound settings, change the volume, and start the screensaver."

    val EXAMPLES = listOf(
        "Open YouTube",
        "Search for cooking videos on YouTube",
        "Go to Games",
        "What's the weather?",
        "How much memory is free?",
        "Turn on 24 hour time",
        "Open Wi-Fi settings",
        "Start the screensaver",
    )
}
