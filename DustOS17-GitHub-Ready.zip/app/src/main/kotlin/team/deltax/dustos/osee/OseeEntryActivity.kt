package team.deltax.dustos.osee

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import team.deltax.dustos.MainActivity
import team.deltax.dustos.data.LauncherPrefs

/**
 * Entry point for the system's assistant requests (ASSIST, VOICE_COMMAND, SEARCH_LONG_PRESS). It has no screen: it
 * passes the request to the launcher, which opens OSee and starts listening, then closes itself.
 *
 * This is only reached when Android or the user routes the assistant request to DustOS, for example by choosing it
 * under Default apps > Assist app. On Fire OS the Alexa button belongs to Alexa and is not routed here; DustOS does
 * not take it over and does not pretend to. Use the OSee button on screen instead.
 */
class OseeEntryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (LauncherPrefs.get(this).oseeEnabled) {
            open.putExtra(MainActivity.EXTRA_OSEE, true).putExtra(MainActivity.EXTRA_LISTEN, true)
        }
        try {
            startActivity(open)
        } catch (e: Exception) {
            // Nothing sensible to do; the user simply stays where they were.
        }
        finish()
    }
}
