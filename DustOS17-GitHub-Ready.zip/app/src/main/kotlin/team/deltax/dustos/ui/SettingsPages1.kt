package team.deltax.dustos.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.Wallpapers
import team.deltax.dustos.data.SystemIntents

@Composable
fun AppearancePage(vm: DustViewModel) {
    val p = vm.prefs
    SettingsColumn {
        SettingHeader("Theme")
        ThemeSwatches(p.themeId) { id ->
            val t = Wallpapers.themeById(id)
            p.themeId = id
            p.wallpaperId = t.wallpaperId
            vm.loadWallpaper(t.wallpaperId)
        }
        SettingNote("A theme sets the accent colours and picks a matching wallpaper. You can change the wallpaper separately.")
        SettingSlider("Glass strength", p.glass, 0..100, 5, "%", "How milky and bright the frosted panels look") { p.glass = it }
        SettingChoice("Corners", listOf("Compact", "Standard", "Round"), p.corners, "Roundness of cards, buttons and panels") { p.corners = it }
    }
}

@Composable
fun WallpaperPage(vm: DustViewModel) {
    val p = vm.prefs
    SettingsColumn {
        SettingHeader("Wallpaper")
        WallpaperGrid(p.wallpaperId) { id -> p.wallpaperId = id; vm.loadWallpaper(id) }
        SettingToggle("Live wallpaper", p.liveWallpaper, "A very slow drift and two soft light orbs. Off keeps it perfectly still and saves GPU time.") { p.liveWallpaper = it }
        SettingNote("Wallpapers are drawn by the launcher, so there are no large image files and it stays light on a Fire TV Stick. Cinematic scenes for the screensaver are in the Screensaver page.")
    }
}

@Composable
fun HomeLayoutPage(vm: DustViewModel) {
    val p = vm.prefs
    SettingsColumn {
        SettingHeader("Rows on the home screen")
        SettingToggle("Featured banner", p.showHero) { p.showHero = it }
        SettingToggle("Favourites", p.showFavorites, "Hold Select on any app to add, remove or reorder") { p.showFavorites = it }
        SettingToggle("Recently used", p.showRecents) { p.showRecents = it }
        SettingToggle("Recommended", p.showRecommended, "Shortcuts and tips built from this device. No streaming catalogue.") { p.showRecommended = it }
        SettingToggle("Installed apps", p.showInstalled) { p.showInstalled = it }
        SettingToggle("Weather card", p.wxEnabled) { p.wxEnabled = it; if (it) vm.refreshWeather(false) }
        SettingToggle("System widget", p.sysEnabled) { p.sysEnabled = it }
        SettingAction("Reset favourites", "Reset", "Go back to the suggested starter favourites") {
            p.favorites = emptyList(); p.favoritesSeeded = false; vm.refreshApps(); vm.showToast("Favourites reset")
        }
    }
}

@Composable
fun DisplayPage(vm: DustViewModel) {
    val p = vm.prefs
    val ctx = LocalContext.current
    SettingsColumn {
        SettingHeader("Display")
        SettingSlider("UI size", p.uiScale, 80..120, 5, "%", "Scales the whole interface. The layout adapts to 720p, 1080p and 4K automatically.") { p.uiScale = it }
        SettingSlider("Safe area", p.safeArea, 0..8, 1, "%", "Adds a margin on every side. Raise it if your TV crops the edges (overscan).") { p.safeArea = it }
        SettingAction("Android display settings", "Open", "Resolution, HDR and refresh rate are set by Android, not the launcher") {
            if (!SystemIntents.open(ctx, SystemIntents.display())) vm.showToast("This device has no display settings page")
        }
    }
}

@Composable
private fun ClockPreview(vm: DustViewModel) {
    val p = vm.prefs
    val now by rememberNowMs(everySecond = p.clockSeconds || p.clockAnalog)
    Box(Modifier.fillMaxWidth().height(250.dp).glass(rr(30), 0.6f), contentAlignment = Alignment.Center) {
        Box(Modifier.wrapContentSize(unbounded = true).graphicsLayer { scaleX = 0.46f; scaleY = 0.46f }) {
            ClockView(p.clockSpec(), now)
        }
    }
}

@Composable
fun ClockPage(vm: DustViewModel) {
    val p = vm.prefs
    SettingsColumn {
        ClockPreview(vm)
        SettingHeader("Look")
        SettingChoice("Design", ClockDesignNames, p.clockDesign, "Five ColorOS-inspired designs. Analog uses three dial skins.") { p.clockDesign = it }
        SettingChoice("Type", listOf("Digital", "Analog"), if (p.clockAnalog) 1 else 0) { p.clockAnalog = it == 1 }
        SettingChoice("Size style", listOf("Large", "Small"), if (p.clockLarge) 0 else 1) { p.clockLarge = it == 0 }
        SettingChoice("Font", ClockFontNames, p.clockFont) { p.clockFont = it }
        SettingSlider("Scale", p.clockSize, 50..200, 10, "%") { p.clockSize = it }
        SettingSlider("Opacity", p.clockOpacity, 20..100, 10, "%") { p.clockOpacity = it }
        SettingHeader("Time and date")
        SettingToggle("24-hour time", p.clock24h, "Also used by the top bar and the weather times") { p.clock24h = it }
        SettingToggle("Show seconds", p.clockSeconds, "Ticks once a second, so it uses a little more power") { p.clockSeconds = it }
        SettingToggle("Show date", p.clockDate) { p.clockDate = it }
        SettingToggle("Show weekday", p.clockWeekday) { p.clockWeekday = it }
        SettingHeader("Position")
        SettingChoice("Position", ClockPositionNames, p.clockPos) { p.clockPos = it }
        SettingSlider("Nudge left / right", p.clockOffX, -20..20, 2, "%") { p.clockOffX = it }
        SettingSlider("Nudge up / down", p.clockOffY, -20..20, 2, "%") { p.clockOffY = it }
        SettingNote("The floating clock is shown on the screensaver. The home screen keeps a compact clock in the top bar that follows the 12 or 24-hour setting.")
    }
}

@Composable
fun AnimationsPage(vm: DustViewModel) {
    val p = vm.prefs
    SettingsColumn {
        SettingHeader("Motion")
        SettingToggle("Animations", p.animations, "Off removes every transition and spring for the lowest load") { p.animations = it }
        SettingSlider("Animation speed", p.animSpeed, 50..200, 10, "%", "Applies to focus, dialogs and the banner") { p.animSpeed = it }
        SettingToggle("Focus glow", p.focusGlow, "Soft accent light around the selected item") { p.focusGlow = it }
        SettingToggle("Live wallpaper", p.liveWallpaper) { p.liveWallpaper = it }
        SettingToggle("Depth parallax", p.parallax, "Screensaver layers drift at different speeds. Off makes the scene move as one flat picture") { p.parallax = it }
        SettingNote("Animations pause by themselves when the TV is off or another app is in front, and the home screen draws nothing while the screensaver is showing.")
    }
}
