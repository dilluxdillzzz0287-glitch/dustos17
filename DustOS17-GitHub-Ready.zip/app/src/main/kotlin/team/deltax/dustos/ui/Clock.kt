package team.deltax.dustos.ui

import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.BasicText
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.offset
import kotlinx.coroutines.delay
import team.deltax.dustos.core.ClockMath
import team.deltax.dustos.data.LauncherPrefs
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

val ClockFontNames = listOf("Light", "Thin", "Bold", "Serif", "Mono")
val ClockDesignNames = listOf("Classic", "Stacked", "Outline", "Gradient", "Pill")
val ClockPositionNames = listOf("Top left", "Top centre", "Top right", "Middle left", "Centre", "Middle right", "Bottom left", "Bottom centre", "Bottom right")

/** One snapshot of every clock setting, so previews can show a clock without touching saved settings. */
data class ClockSpec(
    val design: Int, val analog: Boolean, val large: Boolean, val font: Int, val sizePct: Int, val opacity: Int,
    val is24: Boolean, val seconds: Boolean, val date: Boolean, val weekday: Boolean,
)

fun LauncherPrefs.clockSpec() = ClockSpec(clockDesign, clockAnalog, clockLarge, clockFont, clockSize, clockOpacity, clock24h, clockSeconds, clockDate, clockWeekday)

private val fontCache = HashMap<Int, FontFamily>()

fun clockFamily(i: Int): FontFamily = fontCache.getOrPut(i) {
    when (i) {
        1 -> FontFamily(Typeface.create("sans-serif-thin", Typeface.NORMAL))
        2 -> FontFamily(Typeface.create("sans-serif-black", Typeface.NORMAL))
        3 -> FontFamily.Serif
        4 -> FontFamily.Monospace
        else -> FontFamily(Typeface.create("sans-serif-light", Typeface.NORMAL))
    }
}

/** Current time in millis, ticking once a second only when something on screen needs seconds, otherwise once a minute. */
@Composable
fun rememberNowMs(everySecond: Boolean): State<Long> {
    val active = LocalActive.current
    return produceState(System.currentTimeMillis(), everySecond, active) {
        value = System.currentTimeMillis()
        if (!active) return@produceState
        while (true) {
            value = System.currentTimeMillis()
            val step = if (everySecond) 1000L else 60_000L
            delay(step - value % step + 5L)
        }
    }
}

@Composable
fun ClockView(spec: ClockSpec, nowMs: Long, modifier: Modifier = Modifier) {
    val cal = remember(nowMs) { Calendar.getInstance().apply { timeInMillis = nowMs } }
    val k = spec.sizePct / 100f
    Box(modifier.graphicsLayer { alpha = spec.opacity / 100f }) {
        if (spec.analog) AnalogClock(spec, cal, k) else DigitalClock(spec, cal, k)
    }
}

// Opt-in is insurance: text outline (drawStyle) was experimental in some Compose versions and stable in others.
@OptIn(ExperimentalTextApi::class)
@Composable
private fun DigitalClock(spec: ClockSpec, cal: Calendar, k: Float) {
    val pal = LocalPalette.current
    val h = cal.get(Calendar.HOUR_OF_DAY)
    val m = cal.get(Calendar.MINUTE)
    val s = cal.get(Calendar.SECOND)
    val base = (if (spec.large) 168f else 62f) * k
    val family = clockFamily(spec.font)
    val weight = if (spec.font == 2) FontWeight.Black else FontWeight.Normal
    val date = ClockMath.dateText(cal, Locale.getDefault(), spec.weekday, spec.date)
    val ampm = if (!spec.is24) ClockMath.amPm(h) else ""
    val dateSize = (base * 0.20f).coerceAtLeast(20f).sp

    @Composable
    fun big(text: String, size: Float, brush: Brush? = null, outline: Boolean = false) {
        val common = TextStyle(fontSize = size.sp, fontFamily = family, fontWeight = weight, letterSpacing = (-size * 0.02f).sp)
        if (outline) {
            BasicText(text, style = common.copy(color = pal.text.copy(alpha = 0.10f)), maxLines = 1)
            BasicText(text, style = common.copy(color = pal.text, drawStyle = Stroke(width = size * 0.022f)), maxLines = 1)
        } else if (brush != null) {
            BasicText(text, style = common.copy(brush = brush), maxLines = 1)
        } else {
            BasicText(text, style = common.copy(color = pal.text), maxLines = 1)
        }
    }

    when (spec.design) {
        1 -> Column(horizontalAlignment = Alignment.Start) {
            big(ClockMath.hourText(h, spec.is24), base * 0.92f)
            Box { big(ClockMath.two(m), base * 0.92f, Brush.verticalGradient(listOf(pal.accent2, pal.accent))) }
            if (spec.seconds) Txt(ClockMath.two(s), size = dateSize, color = pal.textDim)
            if (date.isNotEmpty() || ampm.isNotEmpty()) Txt("$ampm  $date".trim(), size = dateSize, color = pal.textDim)
        }
        2, 3 -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val t = ClockMath.timeText(h, m, s, spec.is24, spec.seconds, false)
            Box {
                if (spec.design == 2) Box { big(t, base, outline = true) }
                else big(t, base, Brush.verticalGradient(listOf(Color.White, pal.accent2, pal.accent)))
            }
            if (ampm.isNotEmpty() || date.isNotEmpty()) Txt("$ampm  $date".trim(), size = dateSize, color = pal.textDim)
        }
        4 -> Row(
            Modifier.glass(rr(60)).padding(horizontal = (36 * k).dp, vertical = (18 * k).dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy((24 * k).dp),
        ) {
            big(ClockMath.timeText(h, m, s, spec.is24, spec.seconds, true), base * 0.62f)
            if (date.isNotEmpty()) Txt(date, size = maxOf(base * 0.28f, 18f).sp, color = pal.textDim)
        }
        else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.Bottom) {
                big(ClockMath.timeText(h, m, s, spec.is24, spec.seconds, false), base)
                if (ampm.isNotEmpty()) Txt(ampm, size = (base * 0.24f).sp, color = pal.textDim, modifier = Modifier.padding(start = 10.dp, bottom = (base * 0.14f).dp))
            }
            if (date.isNotEmpty()) Txt(date, size = dateSize, color = pal.textDim)
        }
    }
}


@Composable
private fun AnalogClock(spec: ClockSpec, cal: Calendar, k: Float) {
    val pal = LocalPalette.current
    val h = cal.get(Calendar.HOUR_OF_DAY)
    val m = cal.get(Calendar.MINUTE)
    val s = cal.get(Calendar.SECOND)
    val d = (if (spec.large) 400f else 180f) * k
    val skin = spec.design % 3
    val date = ClockMath.dateText(cal, Locale.getDefault(), spec.weekday, spec.date)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(d.dp)) {
            val c = center
            val r = size.minDimension / 2f
            drawCircle(Color.White.copy(alpha = 0.10f), r, c)
            drawCircle(Color.White.copy(alpha = 0.55f), r, c, style = Stroke(width = r * 0.016f))
            when (skin) {
                0 -> for (i in 0 until 60) {
                    val big = i % 5 == 0
                    val a = i * (2f * PI.toFloat() / 60f)
                    val r1 = r * (if (big) 0.82f else 0.90f)
                    drawLine(
                        Color.White.copy(alpha = if (big) 0.95f else 0.45f), c + Offset(r1 * sin(a), -r1 * cos(a)),
                        c + Offset(r * 0.95f * sin(a), -r * 0.95f * cos(a)), strokeWidth = r * (if (big) 0.03f else 0.014f), cap = StrokeCap.Round,
                    )
                }
                1 -> for (i in 0 until 12) {
                    val a = i * (2f * PI.toFloat() / 12f)
                    drawCircle(if (i % 3 == 0) pal.accent else Color.White.copy(alpha = 0.85f), r * (if (i % 3 == 0) 0.045f else 0.028f), c + Offset(r * 0.84f * sin(a), -r * 0.84f * cos(a)))
                }
                else -> drawCircle(Brush.radialGradient(listOf(pal.accent.copy(alpha = 0.30f), Color.Transparent), c, r), r, c)
            }
            hand(c, ClockMath.hourAngle(h, m, s), r * 0.50f, r * 0.055f, Color.White)
            hand(c, ClockMath.minuteAngle(m, s), r * 0.74f, r * 0.04f, Color.White)
            if (spec.seconds) hand(c, ClockMath.secondAngle(s), r * 0.82f, r * 0.018f, pal.accent2)
            drawCircle(pal.accent, r * 0.045f, c)
        }
        if (date.isNotEmpty()) Txt(date, size = (22f + 14f * k).sp, color = pal.textDim, modifier = Modifier.padding(top = 12.dp))
    }
}

private fun DrawScope.hand(c: Offset, deg: Float, len: Float, width: Float, color: Color) {
    val a = deg * (PI.toFloat() / 180f)
    drawLine(color, c - Offset(len * 0.12f * sin(a), -len * 0.12f * cos(a)), c + Offset(len * sin(a), -len * cos(a)), strokeWidth = width, cap = StrokeCap.Round)
}

/** Places a clock on the 3 x 3 grid with the user's fine offset (percent of the screen). */
@Composable
fun PositionedClock(spec: ClockSpec, pos: Int, offX: Int, offY: Int, nowMs: Long, modifier: Modifier = Modifier) {
    val root = LocalRootSize.current
    val align = when (pos.coerceIn(0, 8)) {
        0 -> Alignment.TopStart; 1 -> Alignment.TopCenter; 2 -> Alignment.TopEnd
        3 -> Alignment.CenterStart; 4 -> Alignment.Center; 5 -> Alignment.CenterEnd
        6 -> Alignment.BottomStart; 7 -> Alignment.BottomCenter; else -> Alignment.BottomEnd
    }
    Box(modifier.padding(64.dp), contentAlignment = align) {
        ClockView(spec, nowMs, Modifier.offset { IntOffset((root.width * offX / 100f).roundToInt(), (root.height * offY / 100f).roundToInt()) })
    }
}
