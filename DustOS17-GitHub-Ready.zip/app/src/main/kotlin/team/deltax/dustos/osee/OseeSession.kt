package team.deltax.dustos.osee

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.AppMatcher
import team.deltax.dustos.core.LauncherOption
import team.deltax.dustos.core.MathAnswer
import team.deltax.dustos.core.OseeAction
import team.deltax.dustos.core.OseeParser
import team.deltax.dustos.core.OseeText
import team.deltax.dustos.core.Section
import team.deltax.dustos.core.SystemTarget
import team.deltax.dustos.data.KnownTvApps
import team.deltax.dustos.data.SystemIntents
import team.deltax.dustos.data.WeatherState
import team.deltax.dustos.ui.Host
import java.util.Calendar
import java.util.Locale

enum class OseeState { Idle, Listening, Processing, Responding }

/** A button OSee offers after a reply, such as "Search the web". */
class FollowUp(val label: String, val run: () -> Unit)

private class Reply(
    val text: String,
    val spoken: String = text,
    val speak: Boolean = true,
    val closeAfterMs: Long = -1L,
    val follow: List<FollowUp> = emptyList(),
)

/**
 * One OSee conversation. It exists only while the OSee screen is open, so the microphone and the speech engine
 * cannot be touched in the background. Listening starts only from a button press, stops after one phrase, and
 * [micOn] is true exactly while the recogniser is open, which is what the on-screen indicator shows.
 */
class OseeSession(
    context: Context,
    private val vm: DustViewModel,
    private val host: Host,
    private val onClose: () -> Unit,
) {
    private val ctx: Context = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    var state by mutableStateOf(OseeState.Idle); private set
    var heard by mutableStateOf(""); private set
    var heardFinal by mutableStateOf(false); private set
    var reply by mutableStateOf(""); private set
    var level by mutableFloatStateOf(0f); private set
    var micOn by mutableStateOf(false); private set
    var followUps by mutableStateOf<List<FollowUp>>(emptyList()); private set

    /** Set when the user asked for the weather before it had loaded. The screen calls [weatherArrived] later. */
    private var waitingForWeather = false
    private var pendingListen = false
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsState = TTS_NONE
    private var pendingSpeech: String? = null
    private var released = false

    // ---------------------------------------------------------------- listening

    fun toggleMic() {
        if (state == OseeState.Listening || state == OseeState.Processing) cancel() else startListening()
    }

    fun startListening() {
        if (released || state == OseeState.Listening) return
        stopSpeaking()
        if (!host.speechAvailable()) {
            say("Speech recognition isn't available on this device. Type below or pick a quick action.", speak = false)
            return
        }
        if (!host.micGranted()) {
            pendingListen = true
            reply = "Allow the microphone to talk to me. I only listen while this screen is open and you've pressed Talk."
            host.requestMicPermission()
            return
        }
        pendingListen = false
        heard = ""
        heardFinal = false
        reply = ""
        followUps = emptyList()
        val sr = recognizer ?: try {
            SpeechRecognizer.createSpeechRecognizer(ctx).also { it.setRecognitionListener(listener); recognizer = it }
        } catch (e: Exception) {
            null
        }
        if (sr == null) {
            say("I couldn't start speech recognition on this device. You can type instead.", speak = false)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        try {
            setMic(true)
            state = OseeState.Listening
            sr.startListening(intent)
            main.postDelayed(listenLimit, LISTEN_LIMIT_MS)
        } catch (e: Exception) {
            setMic(false)
            say("I couldn't use the microphone just now. You can type instead.", speak = false)
        }
    }

    /** Called when the permission dialog is answered. Carries on if the user had pressed Talk. */
    fun onPermissionResult() {
        if (!pendingListen || released) return
        pendingListen = false
        if (host.micGranted()) startListening()
        else say("The microphone wasn't allowed, so I can't listen. You can type to me instead.", speak = false)
    }

    /** Stops listening or speaking and returns to rest. Nothing is run. */
    fun cancel() {
        main.removeCallbacks(listenLimit)
        main.removeCallbacks(listenHardStop)
        try { recognizer?.cancel() } catch (e: Exception) { }
        stopSpeaking()
        setMic(false)
        level = 0f
        heard = ""
        heardFinal = false
        state = OseeState.Idle
    }

    private val listenLimit = Runnable {
        // Long enough for one phrase. Ask the recogniser to finish, then make sure it really did.
        if (state == OseeState.Listening) {
            try { recognizer?.stopListening() } catch (e: Exception) { }
            main.postDelayed(listenHardStop, 4000L)
        }
    }

    private val listenHardStop = Runnable {
        if (state == OseeState.Listening || state == OseeState.Processing) {
            cancel()
            say("I didn't get a clear phrase. Press Talk to try again.", speak = false)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        }

        override fun onEndOfSpeech() {
            // The recogniser has stopped taking audio. Results arrive next.
            setMic(false)
            level = 0f
            if (state == OseeState.Listening) state = OseeState.Processing
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank() && state != OseeState.Idle) {
                heard = t
                heardFinal = false
            }
        }

        override fun onResults(results: Bundle?) {
            main.removeCallbacks(listenLimit)
            main.removeCallbacks(listenHardStop)
            setMic(false)
            level = 0f
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) say("I didn't catch that. Press Talk and try again.", speak = false) else submit(t)
        }

        override fun onError(error: Int) {
            main.removeCallbacks(listenLimit)
            main.removeCallbacks(listenHardStop)
            setMic(false)
            level = 0f
            if (error == SpeechRecognizer.ERROR_CLIENT && state == OseeState.Idle) return // we cancelled it ourselves
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything. Press Talk and try again."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                    "The speech service couldn't be reached. It may need an internet connection. You can type instead."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "The microphone isn't allowed yet. You can allow it in Settings > OSee AI."
                SpeechRecognizer.ERROR_AUDIO -> "I couldn't use the microphone. You can type instead."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The speech service is busy. Try again in a moment."
                else -> "Speech recognition stopped unexpectedly. Press Talk to try again."
            }
            say(msg, speak = false)
        }
    }

    private fun setMic(on: Boolean) {
        micOn = on
        vm.micLive = on
    }

    // ---------------------------------------------------------------- understanding and doing

    /** Typed text, a chip, or the final phrase from the recogniser. */
    fun submit(text: String) {
        val t = text.trim()
        if (t.isEmpty() || released) return
        main.removeCallbacks(listenLimit)
        main.removeCallbacks(listenHardStop)
        try { recognizer?.cancel() } catch (e: Exception) { }
        stopSpeaking()
        setMic(false)
        level = 0f
        heard = t
        heardFinal = true
        reply = ""
        followUps = emptyList()
        waitingForWeather = false
        state = OseeState.Processing
        main.postDelayed({ if (!released) present(execute(OseeParser.parse(t))) }, 220L)
    }

    /** The home screen finished loading weather while OSee was waiting for it. */
    fun weatherArrived() {
        if (!waitingForWeather || released) return
        if (vm.weather is WeatherState.Ready || vm.weather is WeatherState.Failed) {
            waitingForWeather = false
            present(weatherReply())
        }
    }

    private fun present(r: Reply) {
        reply = r.text
        followUps = r.follow
        if (r.text.isEmpty()) {
            state = OseeState.Idle
        } else {
            say(r.text, r.spoken, r.speak)
        }
        if (r.closeAfterMs >= 0L) main.postDelayed({ if (!released) onClose() }, r.closeAfterMs)
    }

    private fun hourNow() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    private fun execute(a: OseeAction): Reply = when (a) {
        OseeAction.Empty -> Reply("I didn't catch that. Press Talk and try again, or type below.", speak = false)
        OseeAction.Close -> Reply("", closeAfterMs = 0L)
        OseeAction.Greeting -> Reply(OseeText.greeting(hourNow()))
        OseeAction.Thanks -> Reply("You're welcome.")
        OseeAction.WhoAreYou -> Reply(OseeText.WHO)
        OseeAction.Help -> Reply(OseeText.HELP, follow = OseeText.EXAMPLES.take(4).map { ex -> FollowUp(ex) { submit(ex) } })
        OseeAction.ShowTime -> {
            val c = Calendar.getInstance()
            Reply(OseeText.time(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), vm.prefs.clock24h))
        }
        OseeAction.ShowDate -> Reply(OseeText.date(Calendar.getInstance(), Locale.getDefault()))
        OseeAction.ShowWeather -> weatherReply()
        OseeAction.ShowMemory -> {
            val s = vm.stats.read()
            Reply(OseeText.memory(s.ramTotal, s.ramAvail, s.ramLow), follow = listOf(FollowUp("Show memory details") { vm.systemDetail = true; onClose() }))
        }
        OseeAction.ShowStorage -> {
            val s = vm.stats.read()
            Reply(OseeText.storage(s.storageTotal, s.storageFree))
        }
        OseeAction.StartScreensaver -> {
            vm.screensaverPreview = true
            Reply("Starting the screensaver. Press any button to come back.", speak = false, closeAfterMs = 150L)
        }
        is OseeAction.Navigate -> navigate(a.section)
        is OseeAction.OpenSystem -> openSystem(a.target)
        is OseeAction.SetOption -> setOption(a.option, a.enabled)
        is OseeAction.Volume -> Reply(OseeLaunch.volume(ctx, a.cmd))
        is OseeAction.OpenApp -> openApp(a.query)
        is OseeAction.Search -> search(a)
        is OseeAction.General -> general(a.text)
    }

    private fun navigate(s: Section): Reply {
        vm.section = s
        val name = when (s) { Section.HOME -> "Home"; Section.APPS -> "Apps"; Section.GAMES -> "Games"; Section.SETTINGS -> "Settings" }
        return Reply("Opening $name.", speak = false, closeAfterMs = 250L)
    }

    private fun openSystem(t: SystemTarget): Reply {
        val (name, actions) = when (t) {
            SystemTarget.WIFI -> "Wi-Fi settings" to SystemIntents.wifi()
            SystemTarget.DISPLAY -> "display settings" to SystemIntents.display()
            SystemTarget.SOUND -> "sound settings" to SystemIntents.sound()
            SystemTarget.BLUETOOTH -> "Bluetooth settings" to SystemIntents.bluetooth()
            SystemTarget.APP_MANAGER -> "the app manager" to SystemIntents.appManager()
            SystemTarget.ALL_SETTINGS -> "Android settings" to SystemIntents.all()
        }
        return if (SystemIntents.open(ctx, actions)) Reply("Opening $name.", speak = false, closeAfterMs = 300L)
        else Reply("This device has no $name page that I can open.")
    }

    private fun setOption(o: LauncherOption, on: Boolean): Reply {
        val p = vm.prefs
        val text = when (o) {
            LauncherOption.CLOCK_24H -> { p.clock24h = on; if (on) "24-hour time is on." else "12-hour time is on." }
            LauncherOption.ANIMATIONS -> { p.animations = on; if (on) "Animations are on." else "Animations are off." }
            LauncherOption.WEATHER_CARD -> { p.wxEnabled = on; if (on) vm.refreshWeather(false); if (on) "The weather card is on." else "The weather card is off." }
            LauncherOption.SYSTEM_WIDGET -> { p.sysEnabled = on; if (on) "The system widget is on." else "The system widget is off." }
            LauncherOption.CLOCK_SECONDS -> { p.clockSeconds = on; if (on) "Seconds are shown on the clock." else "Seconds are hidden." }
        }
        return Reply(text)
    }

    private fun weatherReply(): Reply {
        val p = vm.prefs
        if (!p.wxEnabled) {
            return Reply(
                "Weather is turned off. You can turn it on in Settings > Weather.",
                follow = listOf(FollowUp("Open weather settings") { vm.settingsPage = "weather"; vm.section = Section.SETTINGS; onClose() }),
            )
        }
        return when (val w = vm.weather) {
            is WeatherState.Ready -> Reply(OseeText.weather(w.snap, w.place, p.wxFahrenheit, w.stale))
            is WeatherState.Failed -> Reply(w.message)
            else -> {
                waitingForWeather = true
                vm.refreshWeather(false)
                Reply("One moment, I'm fetching the weather.", speak = false)
            }
        }
    }

    private fun openApp(query: String): Reply {
        val apps = vm.apps
        val idx = AppMatcher.best(query, apps.map { it.label })
        if (idx == null) {
            return Reply(
                "I couldn't find an app called “$query” on this device.",
                follow = listOf(
                    FollowUp("Search the web for “$query”") { webSearch(query) },
                    FollowUp("Show all apps") { vm.section = Section.APPS; onClose() },
                ),
            )
        }
        val app = apps[idx]
        vm.launch(app)
        return Reply("Opening ${app.label}.", speak = false, closeAfterMs = 350L)
    }

    private fun search(a: OseeAction.Search): Reply {
        val q = a.query
        val appName = a.inApp
        if (appName != null) {
            val idx = AppMatcher.best(appName, vm.apps.map { it.label })
                ?: return Reply(
                    "I couldn't find an app called “$appName”. I can search the web for “$q” instead.",
                    follow = listOf(FollowUp("Search the web") { webSearch(q) }),
                )
            return searchInApp(idx, q, a.play)
        }
        if (OseeLaunch.globalSearch(ctx, q)) return Reply("Searching for “$q”.", speak = false, closeAfterMs = 500L)
        // No system search here. Offer the installed apps that say they accept searches, plus the web.
        val searchable = OseeLaunch.searchablePackages(ctx)
        val order = KnownTvApps
        val choices = vm.apps
            .filter { it.tvApp && it.pkg in searchable }
            .sortedWith(compareBy({ order.indexOf(it.pkg).let { i -> if (i < 0) Int.MAX_VALUE else i } }, { it.label.lowercase() }))
            .take(4)
            .map { app -> FollowUp("In ${app.label}") { val r = searchInApp(vm.apps.indexOf(app), q, a.play); present(r) } }
        return Reply("Where should I look for “$q”?", follow = choices + FollowUp("On the web") { webSearch(q) })
    }

    private fun searchInApp(index: Int, q: String, play: Boolean): Reply {
        val app = vm.apps.getOrNull(index) ?: return Reply("I couldn't open that app.")
        return if (OseeLaunch.searchInApp(ctx, app.pkg, q, play)) {
            vm.noteLaunched(app.pkg)
            Reply("Asked ${app.label} to search for “$q”.", speak = false, closeAfterMs = 600L)
        } else {
            vm.launch(app)
            Reply("${app.label} doesn't take searches from other apps, so I opened it. Search for “$q” there.", closeAfterMs = 1800L)
        }
    }

    private fun webSearch(q: String) {
        if (OseeLaunch.webSearch(ctx, q)) {
            present(Reply("Searching the web for “$q”.", speak = false, closeAfterMs = 500L))
        } else {
            present(Reply("There's no web browser on this device to search with."))
        }
    }

    private fun general(text: String): Reply {
        MathAnswer.answer(text)?.let { return Reply(it.display, it.spoken) }
        return Reply(
            "I can't answer that on my own. I know your launcher, this device, the weather and simple sums. I can search the web for it if you like.",
            follow = listOf(FollowUp("Search the web for it") { webSearch(text) }),
        )
    }

    // ---------------------------------------------------------------- speaking

    /** Shows [text] and, if spoken replies are on and the device has a voice, says [spoken]. */
    private fun say(text: String, spoken: String = text, speak: Boolean = true) {
        reply = text
        state = OseeState.Responding
        if (speak && vm.prefs.oseeSpeak && ttsState != TTS_UNAVAILABLE) {
            ensureTts()
            if (ttsState == TTS_READY) startSpeaking(spoken) else pendingSpeech = spoken
            // If the engine never starts, do not stay in the responding state.
            main.postDelayed(restGuard, 6000L)
        } else {
            main.postDelayed(restGuard, 900L)
        }
    }

    private val restGuard = Runnable {
        if (state == OseeState.Responding && !speaking) state = OseeState.Idle
    }

    private var speaking = false

    private fun ensureTts() {
        if (tts != null) return
        ttsState = TTS_STARTING
        tts = try {
            TextToSpeech(ctx) { status -> main.post { onTtsReady(status) } }
        } catch (e: Exception) {
            ttsState = TTS_UNAVAILABLE
            null
        }
    }

    private fun onTtsReady(status: Int) {
        val engine = tts
        if (released || engine == null) return
        if (status != TextToSpeech.SUCCESS) {
            ttsState = TTS_UNAVAILABLE
            pendingSpeech = null
            return
        }
        var r = engine.setLanguage(Locale.getDefault())
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) r = engine.setLanguage(Locale.US)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            ttsState = TTS_UNAVAILABLE
            pendingSpeech = null
            return
        }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { main.post { finishSpeaking() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { main.post { finishSpeaking() } }
        })
        ttsState = TTS_READY
        pendingSpeech?.let { pendingSpeech = null; startSpeaking(it) }
    }

    private fun startSpeaking(text: String) {
        val engine = tts ?: return
        speaking = true
        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "osee")
        if (result != TextToSpeech.SUCCESS) finishSpeaking()
    }

    private fun finishSpeaking() {
        speaking = false
        if (state == OseeState.Responding) state = OseeState.Idle
    }

    private fun stopSpeaking() {
        pendingSpeech = null
        main.removeCallbacks(restGuard)
        if (speaking) {
            try { tts?.stop() } catch (e: Exception) { }
            speaking = false
        }
    }

    // ---------------------------------------------------------------- lifetime

    /** Closes the microphone and the speech engine. Called whenever the OSee screen leaves the screen. */
    fun release() {
        if (released) return
        released = true
        main.removeCallbacksAndMessages(null)
        try { recognizer?.cancel() } catch (e: Exception) { }
        try { recognizer?.destroy() } catch (e: Exception) { }
        recognizer = null
        try { tts?.stop() } catch (e: Exception) { }
        try { tts?.shutdown() } catch (e: Exception) { }
        tts = null
        setMic(false)
        level = 0f
    }

    private companion object {
        const val LISTEN_LIMIT_MS = 12_000L
        const val TTS_NONE = 0
        const val TTS_STARTING = 1
        const val TTS_READY = 2
        const val TTS_UNAVAILABLE = 3
    }
}
