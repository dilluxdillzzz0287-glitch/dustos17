package team.deltax.dustos.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/**
 * All launcher settings. Every property is Compose snapshot state backed by SharedPreferences,
 * so reading one inside a composable recomposes when it changes, and writing persists it.
 */
class LauncherPrefs private constructor(private val sp: SharedPreferences) {
    private val resetters = ArrayList<() -> Unit>()

    // ---- Appearance
    var themeId by str("themeId", "aurora")
    var wallpaperId by str("wallpaperId", "violet_flow")
    var glass by int("glass", 55, 0, 100)            // frosted tint strength
    var corners by int("corners", 1, 0, 2)           // 0 compact, 1 standard, 2 round
    var uiScale by int("uiScale", 100, 80, 120)      // percent
    var safeArea by int("safeArea", 2, 0, 8)         // overscan padding, percent of screen

    // ---- Animations
    var animations by bool("animations", true)
    var animSpeed by int("animSpeed", 100, 50, 200)  // percent
    var liveWallpaper by bool("liveWallpaper", true)
    var parallax by bool("parallax", true)
    var focusGlow by bool("focusGlow", true)

    // ---- Home layout
    var showHero by bool("showHero", true)
    var showFavorites by bool("showFavorites", true)
    var showRecents by bool("showRecents", true)
    var showRecommended by bool("showRecommended", true)
    var showInstalled by bool("showInstalled", true)

    // ---- Clock (home header and screensaver share these)
    var clock24h by bool("clock24h", false)
    var clockSeconds by bool("clockSeconds", false)
    var clockDate by bool("clockDate", true)
    var clockWeekday by bool("clockWeekday", true)
    var clockAnalog by bool("clockAnalog", false)
    var clockLarge by bool("clockLarge", true)
    var clockDesign by int("clockDesign", 0, 0, 4)
    var clockFont by int("clockFont", 0, 0, 4)
    var clockSize by int("clockSize", 100, 50, 200)
    var clockOpacity by int("clockOpacity", 100, 20, 100)
    var clockPos by int("clockPos", 4, 0, 8)         // 3x3 grid, 0 top-left .. 8 bottom-right
    var clockOffX by int("clockOffX", 0, -20, 20)    // percent of screen width
    var clockOffY by int("clockOffY", 6, -20, 20)    // percent of screen height

    // ---- Screensaver
    var ssEnabled by bool("ssEnabled", true)
    var ssDelay by int("ssDelay", 5, 1, 60)          // minutes
    var ssScene by str("ssScene", "peaks")
    var ssClock by bool("ssClock", true)
    var ssWeather by bool("ssWeather", true)
    var ssDepth by int("ssDepth", 65, 0, 100)
    var ssSpeed by int("ssSpeed", 100, 25, 200)
    var ssDim by int("ssDim", 10, 0, 80)
    var ssVideo by str("ssVideo", "")                // absolute path of a local video, empty = built-in scenes
    var ssAwake by bool("ssAwake", false)            // keep the TV awake while the screensaver is showing

    // ---- Weather
    var wxEnabled by bool("wxEnabled", true)
    var wxAuto by bool("wxAuto", false)
    var wxLat by dbl("wxLat", 11.2588)
    var wxLon by dbl("wxLon", 75.7804)
    var wxName by str("wxName", "Kozhikode, Kerala, India")
    var wxFahrenheit by bool("wxFahrenheit", false)
    var wxRefreshMin by int("wxRefreshMin", 60, 15, 360)
    var wxForecast by bool("wxForecast", true)

    // ---- System widget
    var sysEnabled by bool("sysEnabled", true)
    var sysSize by int("sysSize", 0, 0, 2)           // 0 small, 1 medium, 2 large
    var sysDetailed by bool("sysDetailed", true)
    var sysPos by int("sysPos", 0, 0, 2)             // 0 right column below weather, 1 right column above weather, 2 own row
    var sysRam by bool("sysRam", true)
    var sysCpu by bool("sysCpu", true)
    var sysStorage by bool("sysStorage", true)
    var sysTemp by bool("sysTemp", true)
    var sysBattery by bool("sysBattery", true)
    var sysRefresh by int("sysRefresh", 5, 0, 60)    // seconds, 0 = manual only

    // ---- Launcher behaviour
    var overrideHome by bool("overrideHome", false)  // needs the Home Guard accessibility service
    var overrideBack by bool("overrideBack", true)   // Back / Exit never leaves the launcher
    var startOnBoot by bool("startOnBoot", false)
    var guardPausedUntil by lng("guardPausedUntil", 0L)

    // ---- OSee AI
    var oseeEnabled by bool("oseeEnabled", true)
    var oseeSpeak by bool("oseeSpeak", true)
    var oseeKeys by bool("oseeKeys", true)           // react to assistant / search keys while the launcher is in front

    // ---- App lists
    var favorites by list("favorites")
    var favoritesSeeded by bool("favoritesSeeded", false)
    var hidden by list("hidden")
    var gameYes by list("gameYes")                   // user marked as a game
    var gameNo by list("gameNo")                     // user marked as not a game
    var recents by list("recents")                   // most recent first, launches made from DustOS

    fun resetAll() = resetters.forEach { it() }

    // ---------------------------------------------------------------- delegates
    private fun bool(key: String, def: Boolean): ReadWriteProperty<Any?, Boolean> = object : ReadWriteProperty<Any?, Boolean> {
        private val st = mutableStateOf(sp.getBoolean(key, def))
        init { resetters.add { st.value = def; sp.edit().remove(key).apply() } }
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = st.value
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            if (st.value != value) { st.value = value; sp.edit().putBoolean(key, value).apply() }
        }
    }

    private fun int(key: String, def: Int, min: Int, max: Int): ReadWriteProperty<Any?, Int> = object : ReadWriteProperty<Any?, Int> {
        private val st = mutableStateOf(sp.getInt(key, def).coerceIn(min, max))
        init { resetters.add { st.value = def; sp.edit().remove(key).apply() } }
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = st.value
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            val v = value.coerceIn(min, max)
            if (st.value != v) { st.value = v; sp.edit().putInt(key, v).apply() }
        }
    }

    private fun lng(key: String, def: Long): ReadWriteProperty<Any?, Long> = object : ReadWriteProperty<Any?, Long> {
        private val st = mutableStateOf(sp.getLong(key, def))
        init { resetters.add { st.value = def; sp.edit().remove(key).apply() } }
        override fun getValue(thisRef: Any?, property: KProperty<*>): Long = st.value
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Long) {
            if (st.value != value) { st.value = value; sp.edit().putLong(key, value).apply() }
        }
    }

    private fun dbl(key: String, def: Double): ReadWriteProperty<Any?, Double> = object : ReadWriteProperty<Any?, Double> {
        private val st = mutableStateOf(sp.getString(key, null)?.toDoubleOrNull() ?: def)
        init { resetters.add { st.value = def; sp.edit().remove(key).apply() } }
        override fun getValue(thisRef: Any?, property: KProperty<*>): Double = st.value
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Double) {
            if (st.value != value) { st.value = value; sp.edit().putString(key, value.toString()).apply() }
        }
    }

    private fun str(key: String, def: String): ReadWriteProperty<Any?, String> = object : ReadWriteProperty<Any?, String> {
        private val st = mutableStateOf(sp.getString(key, def) ?: def)
        init { resetters.add { st.value = def; sp.edit().remove(key).apply() } }
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = st.value
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            if (st.value != value) { st.value = value; sp.edit().putString(key, value).apply() }
        }
    }

    /** Ordered list of package names, stored newline separated. */
    private fun list(key: String): ReadWriteProperty<Any?, List<String>> = object : ReadWriteProperty<Any?, List<String>> {
        private val st = mutableStateOf(sp.getString(key, "")?.split('\n')?.filter { it.isNotBlank() } ?: emptyList())
        init { resetters.add { st.value = emptyList(); sp.edit().remove(key).apply() } }
        override fun getValue(thisRef: Any?, property: KProperty<*>): List<String> = st.value
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: List<String>) {
            if (st.value != value) { st.value = value; sp.edit().putString(key, value.joinToString("\n")).apply() }
        }
    }

    companion object {
        @Volatile private var instance: LauncherPrefs? = null

        fun get(context: Context): LauncherPrefs = instance ?: synchronized(this) {
            instance ?: LauncherPrefs(
                context.applicationContext.getSharedPreferences("dustos_settings", Context.MODE_PRIVATE)
            ).also { instance = it }
        }
    }
}
