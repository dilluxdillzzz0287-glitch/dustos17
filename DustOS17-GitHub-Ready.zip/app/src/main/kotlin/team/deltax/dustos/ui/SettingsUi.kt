package team.deltax.dustos.ui

import android.graphics.Bitmap
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import team.deltax.dustos.core.WallpaperRenderer
import team.deltax.dustos.core.WallpaperSpec
import team.deltax.dustos.core.Wallpapers
import kotlin.math.roundToInt

/** What the settings pages need from the activity: runtime permissions and the system "set default Home" request. */
interface Host {
    fun requestHomeRole(): Boolean
    fun requestMicPermission()
    fun requestLocationPermission()
    fun micGranted(): Boolean
    fun locationGranted(): Boolean
    fun speechAvailable(): Boolean
}

val LocalHost = staticCompositionLocalOf<Host> { error("Host not provided") }

/** The category item of the page on screen. Left from the left edge of a page goes here, not to the nearest category. */
val LocalPageExit = staticCompositionLocalOf<FocusRequester?> { null }

/** Put on the left-most focusable of a row. Everything else keeps the normal D-pad search. */
@Composable
fun Modifier.leftToCategories(): Modifier {
    val exit = LocalPageExit.current
    return if (exit != null) this.focusProperties { left = exit } else this
}

// ------------------------------------------------------------------ row kit

@Composable
private fun RowShell(onClick: (() -> Unit)?, onKey: ((KeyEvent) -> Boolean)?, content: @Composable RowScope.() -> Unit) {
    val shape = rr(26)
    Row(
        Modifier.fillMaxWidth()
            .then(if (onKey != null) Modifier.onKeyEvent(onKey) else Modifier)
            .leftToCategories()
            .tvFocus(shape, onClick = onClick, scale = 1.012f)
            .glass(shape, 0.8f)
            .padding(horizontal = 28.dp, vertical = 17.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

@Composable
private fun RowScope.Label(title: String, subtitle: String?) {
    Column(Modifier.weight(1f).padding(end = 24.dp)) {
        Txt(title, size = 26.sp, weight = FontWeight.Medium)
        if (subtitle != null) Txt(subtitle, size = 19.sp, color = LocalPalette.current.textDim, maxLines = 2)
    }
}

private fun stepKeys(left: () -> Boolean, right: () -> Boolean): (KeyEvent) -> Boolean = { ev ->
    if (ev.type != KeyEventType.KeyDown) false
    else when (ev.key) {
        Key.DirectionLeft -> left()
        Key.DirectionRight -> right()
        else -> false
    }
}

@Composable
private fun SwitchKnob(on: Boolean) {
    val pal = LocalPalette.current
    val motion = LocalMotion.current
    val k by animateFloatAsState(if (on) 1f else 0f, motion.spec(spring(dampingRatio = 0.7f, stiffness = 500f)), label = "switch")
    Box(Modifier.size(width = 78.dp, height = 42.dp).background(lerp(Color.White.copy(alpha = 0.22f), pal.accent, k), CircleShape)) {
        Box(
            Modifier.offset { IntOffset(((4f + 36f * k) * density).roundToInt(), (4f * density).roundToInt()) }
                .size(34.dp).background(Color.White, CircleShape)
        )
    }
}

@Composable
fun SettingToggle(title: String, value: Boolean, subtitle: String? = null, onChange: (Boolean) -> Unit) {
    RowShell(onClick = { onChange(!value) }, onKey = null) {
        Label(title, subtitle)
        SwitchKnob(value)
    }
}

/** Left and Right step through the options, Select cycles. Left at the first option moves focus back to the category list. */
@Composable
fun SettingChoice(title: String, options: List<String>, index: Int, subtitle: String? = null, onChange: (Int) -> Unit) {
    val i = index.coerceIn(0, options.lastIndex)
    RowShell(
        onClick = { onChange((i + 1) % options.size) },
        onKey = stepKeys(
            left = { if (i > 0) { onChange(i - 1); true } else false },
            right = { if (i < options.lastIndex) { onChange(i + 1); true } else false },
        ),
    ) {
        Label(title, subtitle)
        GlyphIcon(Glyph.ARROW_LEFT, Modifier.size(24.dp), tint = if (i > 0) LocalPalette.current.text else LocalPalette.current.textFaint)
        Txt(options[i], size = 25.sp, weight = FontWeight.Medium, modifier = Modifier.width(250.dp).padding(horizontal = 8.dp), align = androidx.compose.ui.text.style.TextAlign.Center)
        GlyphIcon(Glyph.ARROW_RIGHT, Modifier.size(24.dp), tint = if (i < options.lastIndex) LocalPalette.current.text else LocalPalette.current.textFaint)
    }
}

@Composable
fun SettingSlider(title: String, value: Int, range: IntRange, step: Int = 1, unit: String = "", subtitle: String? = null, onChange: (Int) -> Unit) {
    val pal = LocalPalette.current
    val v = value.coerceIn(range.first, range.last)
    val frac = (v - range.first).toFloat() / (range.last - range.first).coerceAtLeast(1)
    RowShell(
        onClick = null,
        onKey = stepKeys(
            left = { if (v > range.first) { onChange((v - step).coerceAtLeast(range.first)); true } else false },
            right = { if (v < range.last) { onChange((v + step).coerceAtMost(range.last)); true } else false },
        ),
    ) {
        Label(title, subtitle)
        Txt("$v$unit", size = 24.sp, weight = FontWeight.Medium, modifier = Modifier.width(110.dp), align = androidx.compose.ui.text.style.TextAlign.End)
        HSpace(18)
        Box(Modifier.width(300.dp).height(10.dp).background(Color.White.copy(alpha = 0.18f), CircleShape)) {
            Box(Modifier.fillMaxWidth(frac).height(10.dp).background(Brush.horizontalGradient(listOf(pal.accent2, pal.accent)), CircleShape))
        }
    }
}

@Composable
fun SettingAction(title: String, button: String? = null, subtitle: String? = null, onClick: () -> Unit) {
    RowShell(onClick = onClick, onKey = null) {
        Label(title, subtitle)
        if (button != null) Txt(button, size = 23.sp, weight = FontWeight.Medium, color = LocalPalette.current.accent)
        else GlyphIcon(Glyph.CHEVRON, Modifier.size(26.dp), tint = LocalPalette.current.textDim)
    }
}

/** Read-only line. Not focusable, so the D-pad skips it. */
@Composable
fun SettingInfo(title: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Txt(title, size = 23.sp, color = LocalPalette.current.textDim, modifier = Modifier.weight(1f))
        Txt(value, size = 23.sp, weight = FontWeight.Medium, maxLines = 2)
    }
}

@Composable
fun SettingNote(text: String) {
    Txt(text, size = 20.sp, color = LocalPalette.current.textDim, maxLines = 8, modifier = Modifier.padding(horizontal = 28.dp, vertical = 8.dp))
}

@Composable
fun SettingHeader(text: String) {
    Txt(text, size = 23.sp, weight = FontWeight.SemiBold, color = LocalPalette.current.accent, modifier = Modifier.padding(start = 10.dp, top = 22.dp, bottom = 4.dp))
}

@Composable
fun SettingsColumn(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) { content() }
}

// ------------------------------------------------------------------ pickers

private val previewCache = HashMap<String, ImageBitmap>()

@Composable
fun rememberWallpaperPreview(spec: WallpaperSpec): ImageBitmap? {
    val image by produceState<ImageBitmap?>(previewCache[spec.id], spec.id) {
        if (value == null) {
            val bmp = withContext(Dispatchers.Default) {
                val px = WallpaperRenderer.render(spec, 240, 135)
                Bitmap.createBitmap(px, 240, 135, Bitmap.Config.ARGB_8888).asImageBitmap()
            }
            previewCache[spec.id] = bmp
            value = bmp
        }
    }
    return image
}

@Composable
fun ThemeSwatches(selectedId: String, onPick: (String) -> Unit) {
    Row(Modifier.padding(vertical = 18.dp, horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(26.dp)) {
        for ((i, t) in Wallpapers.themes.withIndex()) {
            val a = Color(0xFF000000.toInt() or t.accent)
            val b = Color(0xFF000000.toInt() or t.accent2)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(96.dp).then(if (i == 0) Modifier.leftToCategories() else Modifier).tvFocus(CircleShape, onClick = { onPick(t.id) }, scale = 1.14f)
                        .background(Brush.linearGradient(listOf(a, b)), CircleShape),
                    contentAlignment = Alignment.Center,
                ) { if (t.id == selectedId) GlyphIcon(Glyph.CHECK, Modifier.size(44.dp), tint = Color.White) }
                Txt(t.name, size = 20.sp, color = LocalPalette.current.textDim, modifier = Modifier.padding(top = 10.dp))
            }
        }
    }
}

@Composable
fun WallpaperGrid(selectedId: String, onPick: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(24.dp), modifier = Modifier.padding(vertical = 14.dp, horizontal = 10.dp)) {
        for (rowSpecs in Wallpapers.all.chunked(3)) {
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                for ((i, spec) in rowSpecs.withIndex()) {
                    val shape = rr(24)
                    val img = rememberWallpaperPreview(spec)
                    Column {
                        Box(Modifier.size(width = 300.dp, height = 169.dp).then(if (i == 0) Modifier.leftToCategories() else Modifier).tvFocus(shape, onClick = { onPick(spec.id) }, scale = 1.06f).glass(shape, 0.4f)) {
                            if (img != null) Image(img, null, Modifier.size(width = 300.dp, height = 169.dp), contentScale = ContentScale.Crop)
                            if (spec.id == selectedId) {
                                Box(Modifier.align(Alignment.TopEnd).padding(12.dp).size(42.dp).background(LocalPalette.current.accent, CircleShape), contentAlignment = Alignment.Center) {
                                    GlyphIcon(Glyph.CHECK, Modifier.size(24.dp), tint = Color.White)
                                }
                            }
                        }
                        Txt(spec.name, size = 21.sp, color = LocalPalette.current.textDim, modifier = Modifier.padding(top = 8.dp, start = 6.dp))
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ category list

@Composable
fun CategoryItem(title: String, glyph: Glyph, selected: Boolean, onFocused: () -> Unit, requester: FocusRequester? = null) {
    val pal = LocalPalette.current
    val shape = rr(28)
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(focused) {
        if (focused) {
            delay(120)
            onFocused()
        }
    }
    Row(
        Modifier.fillMaxWidth()
            .tvFocus(shape, onClick = onFocused, scale = 1.03f, requester = requester, onFocusChange = { focused = it })
            .background(if (selected) Color.White.copy(alpha = 0.20f) else Color.Transparent, shape)
            .padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).background(if (selected) pal.accent else Color.White.copy(alpha = 0.16f), CircleShape), contentAlignment = Alignment.Center) {
            GlyphIcon(glyph, Modifier.size(22.dp), tint = Color.White)
        }
        HSpace(18)
        Txt(title, size = 25.sp, weight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}
