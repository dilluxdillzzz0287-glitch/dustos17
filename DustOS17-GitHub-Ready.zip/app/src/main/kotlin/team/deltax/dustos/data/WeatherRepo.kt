package team.deltax.dustos.data

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import team.deltax.dustos.core.GeoPlace
import team.deltax.dustos.core.WeatherParser
import team.deltax.dustos.core.WeatherSnapshot
import java.net.HttpURLConnection
import java.net.URL

sealed interface WeatherState {
    data object Idle : WeatherState
    data object Loading : WeatherState
    /** [stale] means the numbers come from the last good download because the network failed. */
    data class Ready(val snap: WeatherSnapshot, val place: String, val stale: Boolean, val note: String?) : WeatherState
    data class Failed(val message: String) : WeatherState
}

data class Place(val lat: Double, val lon: Double, val name: String, val auto: Boolean)

/** Open-Meteo (no API key). Everything is cached so the home screen still shows weather offline. */
class WeatherRepo(private val ctx: Context, private val prefs: LauncherPrefs) {
    private val sp = ctx.getSharedPreferences("dustos_weather", Context.MODE_PRIVATE)

    fun cached(): WeatherState.Ready? {
        val json = sp.getString("json", null) ?: return null
        val snap = WeatherParser.parseForecast(json, sp.getLong("ts", 0L)) ?: return null
        return WeatherState.Ready(snap, sp.getString("place", "") ?: "", stale = true, note = null)
    }

    /** Where to ask about. Automatic uses the last location Android already knows, and only with permission. */
    fun resolvePlace(): Pair<Place, String?> {
        val manual = Place(prefs.wxLat, prefs.wxLon, prefs.wxName, false)
        if (!prefs.wxAuto) return manual to null
        val auto = autoPlace()
        return if (auto != null) auto to null
        else manual to "Automatic location is not available on this device, using ${prefs.wxName}."
    }

    @SuppressLint("MissingPermission")
    private fun autoPlace(): Place? {
        if (Build.VERSION.SDK_INT >= 23 &&
            ctx.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        val best = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }
            .maxByOrNull { it.time } ?: return null
        return Place(best.latitude, best.longitude, "Current location", true)
    }

    suspend fun refresh(force: Boolean): WeatherState = withContext(Dispatchers.IO) {
        val (place, note) = resolvePlace()
        val key = "%.3f,%.3f".format(java.util.Locale.US, place.lat, place.lon)
        val ageMs = System.currentTimeMillis() - sp.getLong("ts", 0L)
        val cachedJson = sp.getString("json", null)
        if (!force && cachedJson != null && sp.getString("key", "") == key && ageMs < prefs.wxRefreshMin * 60_000L) {
            val snap = WeatherParser.parseForecast(cachedJson, sp.getLong("ts", 0L))
            if (snap != null) return@withContext WeatherState.Ready(snap, place.name, stale = false, note = note)
        }
        try {
            val json = httpGet(WeatherParser.url(place.lat, place.lon))
            val now = System.currentTimeMillis()
            val snap = WeatherParser.parseForecast(json, now) ?: throw IllegalStateException("Unreadable weather data")
            sp.edit().putString("json", json).putLong("ts", now).putString("key", key).putString("place", place.name).apply()
            WeatherState.Ready(snap, place.name, stale = false, note = note)
        } catch (e: Exception) {
            val snap = if (cachedJson != null && sp.getString("key", "") == key) WeatherParser.parseForecast(cachedJson, sp.getLong("ts", 0L)) else null
            if (snap != null) WeatherState.Ready(snap, place.name, stale = true, note = "Offline, showing the last update.")
            else WeatherState.Failed("Weather unavailable. Check the network connection.")
        }
    }

    suspend fun search(query: String): List<GeoPlace> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        try { WeatherParser.parseGeocode(httpGet(WeatherParser.geocodeUrl(query))) } catch (e: Exception) { emptyList() }
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "DustOS17/1.0 (Android TV launcher)")
            if (c.responseCode != 200) throw java.io.IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
