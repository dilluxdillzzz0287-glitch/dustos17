package team.deltax.dustos.ui

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.data.AppEntry

/** Apps and Games share this grid. Hold Select on a tile for options. */
@Composable
fun AppGridScreen(vm: DustViewModel, title: String, apps: List<AppEntry>, emptyText: String, firstFocus: FocusRequester) {
    val pal = LocalPalette.current
    CompositionLocalProvider(LocalRowKey provides "grid:$title") {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 8.dp, top = 6.dp, end = 8.dp), verticalAlignment = Alignment.Bottom) {
            Txt(title, size = 46.sp, weight = FontWeight.SemiBold)
            HSpace(20)
            Txt("${apps.size} ${if (apps.size == 1) "app" else "apps"}", size = 24.sp, color = pal.textDim, modifier = Modifier.padding(bottom = 6.dp))
            Box(Modifier.weight(1f))
            Txt("Hold Select for options", size = 20.sp, color = pal.textFaint, modifier = Modifier.padding(bottom = 6.dp))
        }
        if (apps.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(top = 60.dp), contentAlignment = Alignment.TopCenter) {
                Box(Modifier.width(900.dp).glass(rr(36)).padding(44.dp)) {
                    Txt(if (vm.appsLoaded) emptyText else "Looking for apps…", size = 28.sp, color = pal.textDim, maxLines = 4)
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(6),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 28.dp),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp),
            ) {
                items(apps, key = { it.pkg }) { app ->
                    IconTile(
                        app, vm,
                        Modifier.fillMaxWidth().height(158.dp),
                        iconSize = 76.dp, labelSize = 22.sp,
                        requester = if (app.pkg == apps.first().pkg) firstFocus else null,
                    )
                }
            }
        }
    }
    }
}

@Composable
private fun OptionRow(text: String, glyph: Glyph, requester: FocusRequester? = null, danger: Boolean = false, onClick: () -> Unit) {
    val shape = rr(30)
    Row(
        Modifier.fillMaxWidth()
            .tvFocus(shape, onClick = onClick, scale = 1.03f, requester = requester)
            .glass(shape)
            .padding(horizontal = 26.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GlyphIcon(glyph, Modifier.size(30.dp), tint = if (danger) androidx.compose.ui.graphics.Color(0xFFFF7A8A) else LocalPalette.current.text)
        HSpace(18)
        Txt(text, size = 25.sp, weight = FontWeight.Medium, color = if (danger) androidx.compose.ui.graphics.Color(0xFFFF7A8A) else LocalPalette.current.text)
    }
}

/** App management menu: open, favourites, game or not, hide, app info and uninstall. Nothing is changed silently. */
@Composable
fun AppOptionsDialog(vm: DustViewModel, app: AppEntry) {
    val ctx = LocalContext.current
    val first = remember { FocusRequester() }
    val isFav = app.pkg in vm.prefs.favorites
    val favIndex = vm.prefs.favorites.indexOf(app.pkg)
    val isGame = vm.isGame(app)
    fun done(block: () -> Unit) { block(); vm.optionsFor = null }
    fun start(i: Intent) {
        try { ctx.startActivity(i) } catch (e: Exception) { vm.showToast("Android could not open that") }
    }
    Modal(onDismiss = { vm.optionsFor = null }, width = 760.dp) {
        ModalTitle(app.label, app.pkg)
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OptionRow("Open", Glyph.PLAY, first) { done { vm.launch(app) } }
            OptionRow(if (isFav) "Remove from Favourites" else "Add to Favourites", Glyph.STAR) { done { vm.toggleFavorite(app.pkg) } }
            if (isFav && favIndex > 0) OptionRow("Move earlier in Favourites", Glyph.ARROW_LEFT) { done { vm.moveFavorite(app.pkg, -1) } }
            if (isFav && favIndex >= 0 && favIndex < vm.prefs.favorites.lastIndex) OptionRow("Move later in Favourites", Glyph.ARROW_RIGHT) { done { vm.moveFavorite(app.pkg, 1) } }
            OptionRow(if (isGame) "This is not a game" else "Show in Games", Glyph.GAMES) { done { vm.setGame(app.pkg, !isGame) } }
            OptionRow("Hide from launcher", Glyph.EYE_OFF) { done { vm.setHidden(app.pkg, true); vm.showToast("${app.label} hidden. Bring it back in Settings > Apps") } }
            OptionRow("App info", Glyph.INFO) { done { start(vm.repo.appInfoIntent(app.pkg)) } }
            if (!app.isSystem) OptionRow("Uninstall", Glyph.TRASH, danger = true) { done { start(vm.repo.uninstallIntent(app.pkg)) } }
        }
    }
    AutoFocus(first)
}
