package team.deltax.dustos

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import team.deltax.dustos.core.BoxBlur
import team.deltax.dustos.core.Section
import team.deltax.dustos.core.WallpaperRenderer
import team.deltax.dustos.core.Wallpapers
import team.deltax.dustos.data.AppEntry
import team.deltax.dustos.data.AppRepository
import team.deltax.dustos.data.IconCache
import team.deltax.dustos.data.KnownTvApps
import team.deltax.dustos.data.LauncherPrefs
import team.deltax.dustos.data.SystemStats
import team.deltax.dustos.data.UsageRecents
import team.deltax.dustos.data.WeatherRepo
import team.deltax.dustos.data.WeatherState

/** Wallpaper pixels plus the pre-blurred copy that frosted glass panels sample. Built once per wallpaper change. */
class Backdrop(val id: String, val sharp: ImageBitmap, val blurred: ImageBitmap)

/**
 * A plain explanation dialog (manual setup steps and similar). Lines that start with "$ " are shown as commands.
 * An optional action puts one highlighted button above Close.
 */
class InfoDialog(val title: String, val lines: List<String>, val actionLabel: String? = null, val action: (() -> Unit)? = null)

class DustViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = LauncherPrefs.get(app)
    val repo = AppRepository(app)
    val icons = IconCache(app)
    val weatherRepo = WeatherRepo(app, prefs)
    val stats = SystemStats(app)

    var apps by mutableStateOf<List<AppEntry>>(emptyList()); private set
    var appsLoaded by mutableStateOf(false); private set
    var weather by mutableStateOf<WeatherState>(WeatherState.Idle); private set
    var backdrop by mutableStateOf<Backdrop?>(null); private set
    var usageRecents by mutableStateOf<List<String>>(emptyList()); private set
    var toast by mutableStateOf<String?>(null); private set

    var section by mutableStateOf(Section.HOME)
    var screensaverActive by mutableStateOf(false)
    var screensaverPreview by mutableStateOf(false)
    var oseeVisible by mutableStateOf(false)
    /** True only while the microphone is really open for OSee. Drives the on-screen indicator. */
    var micLive by mutableStateOf(false)
    /** Set by a hardware assistant key: OSee opens and starts listening at once. */
    var oseeAutoListen by mutableStateOf(false)
    var optionsFor by mutableStateOf<AppEntry?>(null)
    var active by mutableStateOf(true)
    var info by mutableStateOf<InfoDialog?>(null)
    var resumeTick by mutableIntStateOf(0)
    var permTick by mutableIntStateOf(0)
    /** Bumped by every Home press (or Home intent). The home page scrolls back to the top and focus returns to the sidebar. */
    var homeTick by mutableIntStateOf(0)
    /** Text OSee should handle the moment it opens, set by shortcut cards. */
    var oseeQuery by mutableStateOf<String?>(null)
    var weatherDetail by mutableStateOf(false)
    var systemDetail by mutableStateOf(false)
    var settingsPage by mutableStateOf("appearance")

    private var scanJob: Job? = null
    private var toastJob: Job? = null
    private var wallpaperJob: Job? = null

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = refreshApps()
    }

    init {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        app.registerReceiver(pkgReceiver, f)
        refreshApps()
        loadWallpaper(prefs.wallpaperId)
    }

    override fun onCleared() {
        try { getApplication<Application>().unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
    }

    // ---------------------------------------------------------------- apps
    fun refreshApps() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            delay(300)
            val list = withContext(Dispatchers.IO) { repo.scan() }
            apps = list
            appsLoaded = true
            seedFavorites(list)
            usageRecents = withContext(Dispatchers.IO) { UsageRecents.recentPackages(getApplication<Application>()) }
        }
    }

    fun refreshUsageRecents() {
        viewModelScope.launch { usageRecents = withContext(Dispatchers.IO) { UsageRecents.recentPackages(getApplication<Application>()) } }
    }

    private fun seedFavorites(list: List<AppEntry>) {
        if (prefs.favoritesSeeded || list.isEmpty()) return
        val byPkg = list.associateBy { it.pkg }
        val seeded = KnownTvApps.filter { it in byPkg }.toMutableList()
        for (a in list) if (seeded.size < 8 && a.tvApp && !a.isSystem && a.pkg !in seeded) seeded.add(a.pkg)
        prefs.favorites = seeded
        prefs.favoritesSeeded = true
    }

    val visibleApps: List<AppEntry> get() = apps.filter { it.pkg !in prefs.hidden }

    fun isGame(e: AppEntry): Boolean = e.pkg in prefs.gameYes || (e.gameByDefault && e.pkg !in prefs.gameNo)

    val games: List<AppEntry> get() = visibleApps.filter { isGame(it) }

    val favoriteEntries: List<AppEntry>
        get() {
            val byPkg = apps.associateBy { it.pkg }
            return prefs.favorites.mapNotNull { byPkg[it] }.filter { it.pkg !in prefs.hidden }
        }

    val recentEntries: List<AppEntry>
        get() {
            val byPkg = apps.associateBy { it.pkg }
            val order = (prefs.recents + usageRecents).distinct()
            return order.mapNotNull { byPkg[it] }.filter { it.pkg !in prefs.hidden }.take(10)
        }

    fun launch(e: AppEntry) {
        if (repo.launch(e)) noteLaunched(e.pkg) else showToast("Couldn't open ${e.label}")
    }

    /** Puts an app at the front of Recently used. */
    fun noteLaunched(pkg: String) {
        prefs.recents = (listOf(pkg) + prefs.recents.filter { it != pkg }).take(20)
    }

    fun toggleFavorite(pkg: String) {
        prefs.favorites = if (pkg in prefs.favorites) prefs.favorites - pkg else prefs.favorites + pkg
    }

    fun moveFavorite(pkg: String, delta: Int) {
        val l = prefs.favorites.toMutableList()
        val i = l.indexOf(pkg)
        val j = i + delta
        if (i < 0 || j < 0 || j >= l.size) return
        l.removeAt(i)
        l.add(j, pkg)
        prefs.favorites = l
    }

    fun setHidden(pkg: String, hide: Boolean) {
        prefs.hidden = if (hide) (prefs.hidden + pkg).distinct() else prefs.hidden - pkg
    }

    fun setGame(pkg: String, game: Boolean) {
        prefs.gameYes = if (game) (prefs.gameYes + pkg).distinct() else prefs.gameYes - pkg
        prefs.gameNo = if (!game) (prefs.gameNo + pkg).distinct() else prefs.gameNo - pkg
    }

    // ---------------------------------------------------------------- weather
    fun refreshWeather(force: Boolean) {
        if (!prefs.wxEnabled) return
        viewModelScope.launch {
            if (weather !is WeatherState.Ready) weather = weatherRepo.cached() ?: WeatherState.Loading
            weather = weatherRepo.refresh(force)
        }
    }

    // ---------------------------------------------------------------- wallpaper
    fun loadWallpaper(id: String) {
        wallpaperJob?.cancel()
        wallpaperJob = viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                val spec = Wallpapers.byId(id)
                val sharpPx = WallpaperRenderer.render(spec, 640, 360)
                val smallPx = WallpaperRenderer.render(spec, 160, 90)
                val blurPx = BoxBlur.blur(smallPx, 160, 90, 6, 3)
                Backdrop(
                    spec.id,
                    Bitmap.createBitmap(sharpPx, 640, 360, Bitmap.Config.ARGB_8888).asImageBitmap(),
                    Bitmap.createBitmap(blurPx, 160, 90, Bitmap.Config.ARGB_8888).asImageBitmap(),
                )
            }
            backdrop = result
        }
    }

    // ---------------------------------------------------------------- feedback
    fun showToast(msg: String) {
        toast = msg
        toastJob?.cancel()
        toastJob = viewModelScope.launch { delay(2600); toast = null }
    }
}
