package team.deltax.dustos.core

/** Built-in screensaver scenes. They are drawn in code, so the APK carries no video or image files. */
data class SceneInfo(val id: String, val name: String)

object SceneCatalog {
    val all = listOf(
        SceneInfo("peaks", "Aurora Peaks"),
        SceneInfo("dunes", "Desert Dusk"),
        SceneInfo("flux", "Flux"),
        SceneInfo("cosmos", "Cosmos"),
        SceneInfo("city", "Neon City"),
    )

    fun indexOf(id: String): Int = all.indexOfFirst { it.id == id }.let { if (it < 0) 0 else it }
}
