package team.deltax.dustos.ui

import android.content.ComponentName
import android.content.Context
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.InfoDialog
import team.deltax.dustos.core.Units
import team.deltax.dustos.data.SystemIntents
import team.deltax.dustos.data.UsageRecents
import team.deltax.dustos.launcher.LauncherControl
import team.deltax.dustos.launcher.LauncherGuardService

// ------------------------------------------------------------------ small helpers

@Suppress("DEPRECATION")
private fun labelOf(ctx: Context, pkg: String?): String? {
    if (pkg == null) return null
    if (pkg == "android") return "Android chooser (none selected)"
    return try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}

private fun yesNo(v: Boolean) = if (v) "Yes" else "No"

private fun homeAppDialog() = InfoDialog(
    "Set DustOS as the Home app",
    listOf(
        "Android TV and Google TV: Settings > Apps > Default apps > Home app, then choose DustOS 17. On some versions it is under Device Preferences > Home screen.",
        "Fire TV: Fire OS has no Home app picker and may ignore the choice. Turn on Override Home button instead (it needs Home Guard), or use the ADB commands under Advanced.",
        "DustOS cannot change this by itself. Android and Fire OS decide, and the Launcher page always shows what the system is really using.",
    ),
)

private fun guardDialog(ctx: Context) = InfoDialog(
    "Turn on Home Guard",
    listOf(
        "Home Guard is a small accessibility service. It only sees which app window is in front and which remote buttons are pressed. It cannot read what is on screen.",
        "1. Open the accessibility settings and switch on DustOS Home Guard. Many Fire OS versions do not list third party services there.",
        "2. If it is missing, grant DustOS one permission over ADB, then come back here and press Turn on Home Guard:",
        "$ adb shell pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS",
        "Whether Fire OS lets any app react to the Home button depends on the version. Check the Home Guard line on the Launcher page after turning it on.",
    ),
    actionLabel = "Open accessibility settings",
    action = {
        if (!LauncherControl.openAccessibilitySettings(ctx)) android.widget.Toast.makeText(ctx, "This device has no accessibility settings page", android.widget.Toast.LENGTH_LONG).show()
    },
)

private fun overlayDialog(ctx: Context) = InfoDialog(
    "Display over other apps",
    listOf(
        "Android 10 and newer stop an app in the background from opening a screen unless it has this permission. Start on boot and Home Guard need it.",
        "If this device has no page for it, grant it over ADB:",
        "$ adb shell appops set ${ctx.packageName} SYSTEM_ALERT_WINDOW allow",
    ),
)

private fun adbDialog(ctx: Context): InfoDialog {
    val pkg = ctx.packageName
    return InfoDialog(
        "Advanced: ADB commands",
        listOf(
            "These are standard Android commands that DustOS cannot run for you. They need ADB debugging on (Fire TV: Settings > My Fire TV > Developer options). They have not been confirmed on every Fire OS version, so trust the status lines in Settings, not the command.",
            "Connect:",
            "$ adb connect <tv-ip-address>:5555",
            "Let DustOS switch its own Home Guard on and off:",
            "$ adb shell pm grant $pkg android.permission.WRITE_SECURE_SETTINGS",
            "Allow display over other apps:",
            "$ adb shell appops set $pkg SYSTEM_ALERT_WINDOW allow",
            "Allow usage access (Recently used across the device):",
            "$ adb shell appops set $pkg GET_USAGE_STATS allow",
            "Make DustOS the Home app, Android 10 and newer:",
            "$ adb shell cmd role add-role-holder --user 0 android.app.role.HOME $pkg",
            "Android 9 and older (the command may not exist on newer versions):",
            "$ adb shell pm set-home-activity ${ComponentName(ctx, team.deltax.dustos.MainActivity::class.java).flattenToString()}",
        ),
    )
}

// ------------------------------------------------------------------ Launcher

@Composable
fun LauncherPage(vm: DustViewModel) {
    val p = vm.prefs
    val ctx = LocalContext.current
    val host = LocalHost.current
    val tick = vm.resumeTick + vm.permTick
    val homePkg = remember(tick) { LauncherControl.currentHomePackage(ctx) }
    val isDefault = homePkg == ctx.packageName
    val homeName = remember(tick) { labelOf(ctx, homePkg) }
    val guardOn = remember(tick) { LauncherControl.guardEnabled(ctx) }
    val canSecure = remember(tick) { LauncherControl.canWriteSecure(ctx) }
    val others = remember(tick) { LauncherControl.otherHomePackages(ctx).mapNotNull { labelOf(ctx, it) }.sorted() }

    var clockTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(p.guardPausedUntil) {
        val left = p.guardPausedUntil - System.currentTimeMillis()
        if (left > 0L) {
            delay(left + 200L)
            clockTick++
        }
    }
    val paused = remember(p.guardPausedUntil, clockTick) { p.guardPausedUntil > System.currentTimeMillis() }

    SettingsColumn {
        SettingHeader("Home app")
        SettingInfo("Home app in use", if (isDefault) "DustOS 17" else (homeName ?: "None chosen"))
        if (others.isNotEmpty()) SettingInfo("Other launchers installed", others.joinToString(", "))
        if (!isDefault) {
            SettingAction("Make DustOS the Home app", "Ask", "Shows Android's own request where the device has one") {
                if (!host.requestHomeRole() && !LauncherControl.openHomeSettings(ctx)) vm.info = homeAppDialog()
            }
            SettingAction("How to set it by hand", "Show") { vm.info = homeAppDialog() }
        }
        SettingNote("Android decides which app answers the Home button, and Fire OS keeps its own launcher in charge on many versions. DustOS only asks, then shows here what the system is really doing.")

        SettingHeader("Home button")
        SettingToggle(
            "Override Home button",
            p.overrideHome,
            "When another launcher or the Fire TV home screen opens, DustOS brings itself back. Needs Home Guard.",
        ) {
            p.overrideHome = it
            if (it && !guardOn) vm.info = guardDialog(ctx)
        }
        SettingInfo("Home Guard service", if (guardOn) (if (paused && p.overrideHome) "On, paused" else "On") else "Off")
        if (!guardOn && canSecure) {
            SettingAction("Turn on Home Guard", "Turn on", "Uses the permission you granted over ADB") {
                if (LauncherControl.setGuardEnabled(ctx, true)) vm.showToast("Home Guard switched on") else vm.showToast("Android refused. Use the accessibility settings.")
                vm.permTick++
            }
        }
        if (guardOn && canSecure) {
            SettingAction("Turn off Home Guard", "Turn off") {
                if (LauncherControl.setGuardEnabled(ctx, false)) vm.showToast("Home Guard switched off") else vm.showToast("Android refused. Use the accessibility settings.")
                vm.permTick++
            }
        }
        SettingAction("Accessibility settings", "Open", "Switch DustOS Home Guard on or off there") {
            if (!LauncherControl.openAccessibilitySettings(ctx)) vm.info = guardDialog(ctx)
        }
        if (p.overrideHome) {
            if (paused) {
                SettingAction("Home Guard is paused", "Resume", "Paused so you can use the other home screen") { p.guardPausedUntil = 0L }
            } else {
                SettingAction("Pause Home Guard for 10 minutes", "Pause", "Use this when you need the Fire TV home screen") {
                    p.guardPausedUntil = System.currentTimeMillis() + 10 * 60_000L
                    vm.showToast("Home Guard paused for 10 minutes")
                }
            }
        }
        SettingNote("Android does not let an app block the Home button outright. Home Guard watches which window comes to the front and returns to DustOS, so there can be a short flash of the other screen. If it does nothing on your device, Fire OS is not letting an accessibility service see it.")

        SettingHeader("Back and Exit")
        SettingToggle("Keep Back inside DustOS", p.overrideBack, "Back on the home screen stays here instead of leaving the launcher") { p.overrideBack = it }

        SettingHeader("Escape hatches")
        SettingAction("Open Android settings", "Open", "Always works, even with Home Guard on") {
            if (!SystemIntents.open(ctx, SystemIntents.all())) vm.showToast("This device has no settings page")
        }
        SettingAction("Advanced: ADB commands", "Show", "For setups Fire OS hides from normal menus") { vm.info = adbDialog(ctx) }
    }
}

// ------------------------------------------------------------------ Boot

@Composable
fun BootPage(vm: DustViewModel) {
    val p = vm.prefs
    val ctx = LocalContext.current
    val tick = vm.resumeTick + vm.permTick
    val overlayOk = remember(tick) { LauncherControl.overlayGranted(ctx) }
    val isDefault = remember(tick) { LauncherControl.isDefaultHome(ctx) }
    val overlayNeeded = Build.VERSION.SDK_INT >= 29

    SettingsColumn {
        SettingHeader("Start on boot")
        SettingToggle("Open DustOS after a restart", p.startOnBoot, "Opens the launcher a couple of seconds after the device has finished booting") { p.startOnBoot = it }
        SettingInfo("Home app in use", if (isDefault) "DustOS 17" else "Another launcher")
        SettingInfo(
            "Display over other apps",
            if (!overlayNeeded) "Not needed on Android ${Build.VERSION.RELEASE}" else if (overlayOk) "Allowed" else "Not allowed",
        )
        if (overlayNeeded && !overlayOk) {
            SettingAction("Allow display over other apps", "Open", "Android 10 and newer need this before a background app can open a screen") {
                if (!LauncherControl.openOverlaySettings(ctx)) vm.info = overlayDialog(ctx)
            }
        }
        SettingNote("If DustOS is already the Home app, Android opens it after a restart and nothing here is needed. Start on boot is for devices where another launcher still comes first.")
        SettingNote("Open DustOS at least once after installing it. Android sends no boot message to an app that has never been opened. Some Fire OS versions delay or ignore the message, so check it with a real restart.")
    }
}

// ------------------------------------------------------------------ OSee AI

@Composable
fun OseePage(vm: DustViewModel) {
    val p = vm.prefs
    val host = LocalHost.current
    val tick = vm.resumeTick + vm.permTick
    val micOk = remember(tick) { host.micGranted() }
    val speechOk = remember(tick) { host.speechAvailable() }

    SettingsColumn {
        SettingHeader("OSee AI")
        SettingToggle("OSee AI", p.oseeEnabled, "The assistant button in the top bar and the Ask OSee card") { p.oseeEnabled = it }
        SettingAction("Try OSee", "Open", "Opens the assistant now") { vm.oseeVisible = true }

        SettingHeader("Voice")
        SettingInfo("Microphone permission", if (micOk) "Allowed" else "Not allowed yet")
        if (!micOk) SettingAction("Allow microphone", "Allow", "Also asked when you press the microphone in OSee") { host.requestMicPermission() }
        SettingInfo("Speech recognition", if (speechOk) "Available" else "Not available on this device")
        SettingToggle("Spoken replies", p.oseeSpeak, "Uses Android text-to-speech when the device has a voice installed") { p.oseeSpeak = it }
        if (!speechOk) SettingNote("Without speech recognition you can still type to OSee or pick a quick action. Everything else works the same.")

        SettingHeader("Buttons")
        SettingToggle("Assistant and search buttons", p.oseeKeys, "Opens OSee when the launcher is in front and the remote sends an assistant or search key") { p.oseeKeys = it }
        SettingNote("Fire TV keeps the Alexa button for Alexa, so DustOS cannot take it over and does not try to. Open OSee from the top bar, or map a spare remote button to DustOS with a button mapping app.")

        SettingHeader("Privacy")
        SettingNote("OSee listens only after you open it and press the microphone. It shows a clear Microphone on indicator while it listens, and stops when it understands you, when you press Back, or after a short silence. DustOS never records in the background and saves no audio.")
        SettingNote("Recognising speech is done by the speech service already on your device. Some of those services, Google's for example, may send the audio to their servers. That is up to the service, not DustOS.")
        SettingNote("OSee is its own assistant. It does not replace Alexa, and both can be installed together.")
    }
}

// ------------------------------------------------------------------ Apps

@Composable
fun AppsPage(vm: DustViewModel) {
    val p = vm.prefs
    val ctx = LocalContext.current
    val tick = vm.resumeTick + vm.permTick
    val usageOk = remember(tick) { UsageRecents.hasAccess(ctx) }
    LaunchedEffect(vm.resumeTick) { vm.refreshUsageRecents() }
    val hidden = p.hidden.map { pkg -> pkg to (vm.apps.firstOrNull { it.pkg == pkg }?.label ?: pkg) }

    SettingsColumn {
        SettingHeader("Manage apps")
        SettingAction("Open Android app manager", "Open", "Uninstall, clear data or stop apps with Android's own screens") {
            if (!SystemIntents.open(ctx, SystemIntents.appManager())) vm.showToast("This device has no app manager page")
        }
        SettingNote("In Apps and Games, hold Select on an app for favourites, reordering, hide, app info and uninstall. Android always asks you to confirm an uninstall. DustOS removes nothing silently.")

        SettingHeader("Recently used")
        SettingInfo("Usage access", if (usageOk) "Allowed" else "Not allowed")
        if (!usageOk) {
            SettingAction("Allow usage access", "Open", "Lets Recently used include apps you opened outside DustOS") {
                if (!SystemIntents.open(ctx, SystemIntents.usageAccess())) vm.info = InfoDialog(
                    "Usage access",
                    listOf("This device has no usage access page. Without it, Recently used lists only apps opened from DustOS.", "If you use ADB:", "$ adb shell appops set ${ctx.packageName} GET_USAGE_STATS allow"),
                )
            }
        }
        SettingAction("Clear recently used", "Clear", "Forgets the apps DustOS has launched") { p.recents = emptyList(); vm.showToast("Recently used cleared") }

        SettingHeader("Hidden apps")
        if (hidden.isEmpty()) {
            SettingNote("Nothing is hidden. Hold Select on an app and choose Hide from launcher.")
        } else {
            for ((pkg, label) in hidden) {
                key(pkg) { SettingAction(label, "Show", pkg) { vm.setHidden(pkg, false) } }
            }
        }

        SettingHeader("Games")
        SettingAction("Reset Games sorting", "Reset", "Forgets which apps you moved into or out of Games") {
            p.gameYes = emptyList(); p.gameNo = emptyList(); vm.showToast("Games sorting reset")
        }
    }
}

// ------------------------------------------------------------------ About

@Composable
fun AboutPage(vm: DustViewModel) {
    val p = vm.prefs
    val ctx = LocalContext.current
    val host = LocalHost.current
    val root = LocalRootSize.current
    val tick = vm.resumeTick + vm.permTick
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(armed) {
        if (armed) {
            delay(5000)
            armed = false
        }
    }
    val version = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0" } catch (e: Exception) { "1.0" }
    }
    val ramTotal = remember { vm.stats.read().ramTotal }
    val diag = remember(tick) {
        listOf(
            "Home app in use is DustOS" to yesNo(LauncherControl.isDefaultHome(ctx)),
            "Home Guard service on" to yesNo(LauncherControl.guardEnabled(ctx)),
            "Display over other apps" to if (Build.VERSION.SDK_INT < 29) "Not needed" else yesNo(LauncherControl.overlayGranted(ctx)),
            "Microphone allowed" to yesNo(host.micGranted()),
            "Speech recognition available" to yesNo(host.speechAvailable()),
            "Location allowed" to yesNo(host.locationGranted()),
            "Usage access allowed" to yesNo(UsageRecents.hasAccess(ctx)),
        )
    }

    SettingsColumn {
        SettingHeader("DustOS 17")
        SettingInfo("Version", version)
        SettingInfo("Made by", "DeltaX Team")
        SettingNote("Interface inspired by ColorOS 17 TV Edition and Apple tvOS. DustOS is not affiliated with or endorsed by Oppo, Apple or Amazon. Fire TV and Alexa are trademarks of Amazon.")

        SettingHeader("This device")
        SettingInfo("Device", "${Build.MANUFACTURER} ${Build.MODEL}")
        SettingInfo("System", (if (Build.MANUFACTURER.equals("Amazon", ignoreCase = true)) "Fire OS, " else "") + "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        SettingInfo("Screen", "${root.width} × ${root.height} pixels")
        SettingInfo("Memory", Units.humanBytes(ramTotal))

        SettingHeader("What works here right now")
        for ((name, value) in diag) key(name) { SettingInfo(name, value) }
        SettingNote("These lines are read from Android just now. They show permissions and switches, not whether Fire OS then lets the feature act.")

        SettingHeader("Credits")
        SettingNote("Weather data by Open-Meteo.com (CC BY 4.0). Everything else, including the wallpapers, icons and weather art, is drawn by the launcher itself.")

        SettingHeader("Maintenance")
        SettingAction("Android system settings", "Open") {
            if (!SystemIntents.open(ctx, SystemIntents.all())) vm.showToast("This device has no settings page")
        }
        SettingAction(
            "Reset all DustOS settings",
            if (armed) "Press again to confirm" else "Reset",
            "Themes, layout, clock, screensaver, weather and favourites go back to the defaults. Installed apps are untouched.",
        ) {
            if (!armed) {
                armed = true
            } else {
                armed = false
                p.resetAll()
                vm.loadWallpaper(p.wallpaperId)
                vm.refreshApps()
                vm.settingsPage = "appearance"
                vm.showToast("Settings reset")
            }
        }
    }
}
