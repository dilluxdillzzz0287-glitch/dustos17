package team.deltax.dustos.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.ClockMath
import team.deltax.dustos.core.Section
import team.deltax.dustos.data.SystemIntents
import java.util.Calendar
import java.util.Locale

@Composable
private fun PillIcon(glyph: Glyph, level: Int = 3, tint: Color = LocalPalette.current.text, onClick: () -> Unit) {
    Box(Modifier.size(54.dp).tvFocus(CircleShape, onClick = onClick, scale = 1.16f, memoryKey = "pill:${glyph.name}"), contentAlignment = Alignment.Center) {
        GlyphIcon(glyph, Modifier.size(32.dp), tint = tint, level = level)
    }
}

/** Search, settings, network and the clock in one glass pill, with the date underneath. */
@Composable
private fun StatusPill(vm: DustViewModel, micLive: Boolean) {
    val ctx = LocalContext.current
    val prefs = vm.prefs
    val pal = LocalPalette.current
    val net by rememberNetState()
    val now by rememberNowMs(everySecond = false)
    val cal = remember(now) { Calendar.getInstance().apply { timeInMillis = now } }
    Column(horizontalAlignment = Alignment.End) {
        Row(
            Modifier.glass(rr(60), 1.3f).padding(start = 14.dp, end = 30.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (micLive) {
                // Shown only while the microphone is really open.
                Box(Modifier.size(54.dp), contentAlignment = Alignment.Center) { GlyphIcon(Glyph.MIC, Modifier.size(32.dp), tint = Color(0xFFFF5A6E)) }
            }
            if (prefs.oseeEnabled) PillIcon(Glyph.SEARCH) { vm.oseeVisible = true }
            PillIcon(Glyph.SETTINGS) { vm.section = Section.SETTINGS }
            when (net.kind) {
                NetKind.WIFI -> PillIcon(Glyph.WIFI, level = net.level) { SystemIntents.open(ctx, SystemIntents.wifi()) }
                NetKind.ETHERNET, NetKind.OTHER -> PillIcon(Glyph.ETHERNET) { SystemIntents.open(ctx, SystemIntents.wifi()) }
                NetKind.NONE -> PillIcon(Glyph.OFFLINE) { SystemIntents.open(ctx, SystemIntents.wifi()) }
            }
            HSpace(16)
            Txt(ClockMath.timeText(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), 0, prefs.clock24h, false, true), size = 34.sp, weight = FontWeight.Medium)
        }
        val date = ClockMath.dateText(cal, Locale.getDefault(), prefs.clockWeekday, prefs.clockDate)
        if (date.isNotEmpty()) Txt(date, size = 21.sp, color = pal.textDim, modifier = Modifier.padding(top = 10.dp, end = 20.dp))
    }
}

/** Brand block on the left, status pill on the right. */
@Composable
fun Header(vm: DustViewModel, micLive: Boolean, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    Row(modifier.fillMaxWidth().height(150.dp), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f).padding(start = 14.dp, top = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt("DustOS 17", size = 58.sp, weight = FontWeight.Medium)
                HSpace(22)
                Box(Modifier.border(2.dp, Color.White.copy(alpha = 0.78f), rr(32)).padding(horizontal = 22.dp, vertical = 6.dp)) {
                    Txt("by DeltaX", size = 23.sp, weight = FontWeight.Medium)
                }
            }
            Txt("Smooth by design. Powered by OSee AI.", size = 28.sp, color = pal.textDim, modifier = Modifier.padding(top = 6.dp, start = 4.dp))
        }
        StatusPill(vm, micLive)
    }
}
