package team.deltax.dustos.core

import kotlin.math.exp
import kotlin.math.hypot

/** Soft radial colour glow. x/y are 0..1 of the frame, r is relative to frame height. */
data class Blob(val x: Float, val y: Float, val r: Float, val color: Int, val strength: Float)

/** A big translucent dome with a thin light rim, the "ColorOS arc" look. cx is 0..1 of width, cy and r relative to height. */
data class Arc(val cx: Float, val cy: Float, val r: Float, val rim: Int, val fill: Int, val fillAlpha: Float)

data class WallpaperSpec(
    val id: String,
    val name: String,
    val top: Int,
    val bottom: Int,
    val blobs: List<Blob>,
    val arcs: List<Arc>,
    val vignette: Float = 0.35f,
)

data class ThemePreset(val id: String, val name: String, val accent: Int, val accent2: Int, val wallpaperId: String)

object Wallpapers {
    val all: List<WallpaperSpec> = listOf(
        // The default. Bright violet at the top, magenta and coral warmth below, and big pale domes.
        WallpaperSpec(
            "violet_flow", "Violet Flow", 0x4A3BB4, 0x9A48B8,
            listOf(
                Blob(0.00f, 0.52f, 0.70f, 0xFF7FC0, 0.85f), Blob(1.04f, 0.50f, 0.85f, 0xFF7048, 0.95f),
                Blob(0.08f, 1.10f, 0.85f, 0xFF8438, 0.90f), Blob(0.58f, -0.04f, 0.62f, 0x9A78FF, 0.55f),
                Blob(0.72f, 1.05f, 0.75f, 0xFF63B8, 0.65f), Blob(0.40f, 0.62f, 0.45f, 0xC060E0, 0.35f),
            ),
            listOf(
                Arc(0.60f, 1.12f, 0.98f, 0xF4EAFF, 0xB69BFF, 0.22f),
                Arc(1.00f, 1.18f, 0.84f, 0xFFE8F4, 0xFFA0C8, 0.20f),
                Arc(0.16f, 1.32f, 0.74f, 0xFFEAD6, 0xFFAA70, 0.18f),
            ),
            vignette = 0.12f,
        ),
        WallpaperSpec(
            "aurora_dusk", "Aurora Dusk", 0x1B1250, 0x4B2BB0,
            listOf(Blob(0.12f, 1.00f, 0.85f, 0xFF7A45, 0.85f), Blob(0.92f, 0.12f, 0.62f, 0xE0489F, 0.70f), Blob(0.50f, 0.45f, 0.50f, 0x8A63FF, 0.50f)),
            listOf(Arc(0.62f, 1.38f, 0.98f, 0xE9DDFF, 0x8F6BFF, 0.30f), Arc(0.98f, 1.30f, 0.80f, 0xFFD6EE, 0xFF6AA8, 0.22f), Arc(0.20f, 1.55f, 0.70f, 0xFFE2C8, 0xFF9A5C, 0.18f)),
        ),
        WallpaperSpec(
            "midnight_glass", "Midnight Glass", 0x050B1E, 0x0E2F5E,
            listOf(Blob(0.20f, 0.95f, 0.75f, 0x2D9CDB, 0.55f), Blob(0.88f, 0.15f, 0.55f, 0x5B6CFF, 0.45f), Blob(0.50f, 0.50f, 0.45f, 0x1B4F8F, 0.40f)),
            listOf(Arc(0.60f, 1.40f, 0.95f, 0xBFE6FF, 0x3AA0FF, 0.22f), Arc(0.10f, 1.35f, 0.70f, 0xD7E6FF, 0x6C7BFF, 0.16f)),
        ),
        WallpaperSpec(
            "ember_horizon", "Ember Horizon", 0x2A0D2E, 0x8E2B3C,
            listOf(Blob(0.50f, 1.05f, 0.90f, 0xFF9A3C, 0.90f), Blob(0.10f, 0.20f, 0.60f, 0x7B2FBF, 0.60f), Blob(0.95f, 0.50f, 0.50f, 0xFF4D6D, 0.50f)),
            listOf(Arc(0.50f, 1.45f, 1.00f, 0xFFE3B8, 0xFFB259, 0.26f), Arc(0.90f, 1.40f, 0.65f, 0xFFD0D8, 0xFF5C7A, 0.20f)),
        ),
        WallpaperSpec(
            "emerald_night", "Emerald Night", 0x03140F, 0x0B4A3A,
            listOf(Blob(0.30f, 0.95f, 0.80f, 0x20D6A0, 0.55f), Blob(0.88f, 0.22f, 0.55f, 0x2F7BFF, 0.40f), Blob(0.55f, 0.40f, 0.40f, 0x0F7A5E, 0.45f)),
            listOf(Arc(0.45f, 1.42f, 0.95f, 0xC8FFE9, 0x2EE6B0, 0.20f), Arc(0.95f, 1.30f, 0.70f, 0xCFE8FF, 0x4C9BFF, 0.16f)),
        ),
        WallpaperSpec(
            "graphite", "Graphite", 0x0C0D12, 0x23262F,
            listOf(Blob(0.80f, 0.15f, 0.60f, 0x4A5170, 0.50f), Blob(0.20f, 0.90f, 0.70f, 0x39405A, 0.50f)),
            listOf(Arc(0.60f, 1.40f, 0.95f, 0xDDE3F5, 0x8C97C2, 0.14f)),
            vignette = 0.45f,
        ),
        WallpaperSpec(
            "rose_quartz", "Rose Quartz", 0x2B1030, 0x7A3A8C,
            listOf(Blob(0.85f, 0.90f, 0.80f, 0xFF8FB8, 0.70f), Blob(0.15f, 0.20f, 0.60f, 0xB28CFF, 0.55f), Blob(0.50f, 0.55f, 0.40f, 0xD46BFF, 0.35f)),
            listOf(Arc(0.55f, 1.40f, 0.95f, 0xFFE6F2, 0xFF9EC8, 0.24f), Arc(0.05f, 1.30f, 0.65f, 0xF3E1FF, 0xC59BFF, 0.18f)),
        ),
    )

    val themes: List<ThemePreset> = listOf(
        ThemePreset("aurora", "Aurora", 0x9B7BFF, 0xFF7AB6, "violet_flow"),
        ThemePreset("ice", "Ice", 0x5CC8FF, 0x7B8CFF, "midnight_glass"),
        ThemePreset("ember", "Ember", 0xFFA24D, 0xFF5C7A, "ember_horizon"),
        ThemePreset("emerald", "Emerald", 0x35E0B0, 0x4CC9F0, "emerald_night"),
        ThemePreset("graphite", "Graphite", 0xB8C0D8, 0x8FA3FF, "graphite"),
        ThemePreset("rose", "Rose", 0xFF8FC0, 0xC59BFF, "rose_quartz"),
    )

    fun byId(id: String): WallpaperSpec = all.firstOrNull { it.id == id } ?: all[0]
    fun themeById(id: String): ThemePreset = themes.firstOrNull { it.id == id } ?: themes[0]
}

object WallpaperRenderer {
    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** Opaque ARGB pixels, row-major. Cheap enough to run once per wallpaper change on a Fire TV Stick. */
    fun render(spec: WallpaperSpec, w: Int, h: Int): IntArray {
        val out = IntArray(w * h)
        val aspect = w.toFloat() / h
        val tr = ((spec.top shr 16) and 255).toFloat(); val tg = ((spec.top shr 8) and 255).toFloat(); val tb = (spec.top and 255).toFloat()
        val br = ((spec.bottom shr 16) and 255).toFloat(); val bg = ((spec.bottom shr 8) and 255).toFloat(); val bb = (spec.bottom and 255).toFloat()
        for (y in 0 until h) {
            val v = (y + 0.5f) / h
            for (x in 0 until w) {
                val u = (x + 0.5f) / w
                var r = tr + (br - tr) * v
                var g = tg + (bg - tg) * v
                var b = tb + (bb - tb) * v
                for (bl in spec.blobs) {
                    val d = hypot((u - bl.x) * aspect, v - bl.y) / bl.r
                    if (d < 1f) {
                        val m = (1f - d) * (1f - d) * bl.strength
                        r += (((bl.color shr 16) and 255) - r) * m
                        g += (((bl.color shr 8) and 255) - g) * m
                        b += ((bl.color and 255) - b) * m
                    }
                }
                for (a in spec.arcs) {
                    val d = hypot((u - a.cx) * aspect, v - a.cy)
                    val inside = 1f - smooth(a.r - 0.004f, a.r + 0.004f, d)
                    if (inside > 0f) {
                        val m = a.fillAlpha * inside * (0.55f + 0.45f * (1f - v))
                        r += (((a.fill shr 16) and 255) - r) * m
                        g += (((a.fill shr 8) and 255) - g) * m
                        b += ((a.fill and 255) - b) * m
                    }
                    val k = (d - a.r) / 0.006f
                    val rim = exp(-k * k) * 0.45f
                    if (rim > 0.003f) {
                        r += (((a.rim shr 16) and 255) - r) * rim
                        g += (((a.rim shr 8) and 255) - g) * rim
                        b += ((a.rim and 255) - b) * rim
                    }
                }
                val vd = hypot(u - 0.5f, v - 0.5f) * 1.4f
                val dark = 1f - spec.vignette * smooth(0.45f, 1.0f, vd)
                out[y * w + x] = (0xFF shl 24) or
                    ((r * dark).toInt().coerceIn(0, 255) shl 16) or
                    ((g * dark).toInt().coerceIn(0, 255) shl 8) or
                    (b * dark).toInt().coerceIn(0, 255)
            }
        }
        return out
    }
}

/** Separable box blur on opaque ARGB pixels. Three passes approximate a gaussian. */
object BoxBlur {
    fun blur(src: IntArray, w: Int, h: Int, radius: Int, passes: Int = 3): IntArray {
        require(src.size == w * h) { "size mismatch" }
        if (radius <= 0 || passes <= 0) return src.copyOf()
        var a = src.copyOf()
        var b = IntArray(src.size)
        repeat(passes) {
            pass(a, b, w, h, radius, true)
            pass(b, a, w, h, radius, false)
        }
        return a
    }

    private fun pass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val lines = if (horizontal) h else w
        val len = if (horizontal) w else h
        val stride = if (horizontal) 1 else w
        val lineStride = if (horizontal) w else 1
        val div = 2 * r + 1
        for (line in 0 until lines) {
            val base = line * lineStride
            var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val c = src[base + i.coerceIn(0, len - 1) * stride]
                sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
            }
            for (i in 0 until len) {
                dst[base + i * stride] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[base + (i + r + 1).coerceIn(0, len - 1) * stride]
                val rem = src[base + (i - r).coerceIn(0, len - 1) * stride]
                sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                sb += (add and 255) - (rem and 255)
            }
        }
    }
}
