package team.deltax.dustos.launcher

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import team.deltax.dustos.data.LauncherPrefs

/**
 * Home Guard: the optional, best-effort way for DustOS to behave like the Home app when Fire OS will not make it the
 * default. It only runs after the user switches it on in Accessibility, and only does anything while "Override Home
 * button" is on and the guard is not paused.
 *
 *  - When another launcher's window comes to the front, DustOS is brought back.
 *  - The Home button press is taken and DustOS is opened instead, when Android lets the service see that key.
 *
 * It never reads text, labels or anything else on screen (see accessibility_service_config.xml: canRetrieveWindowContent
 * is false), it stores nothing, and it does nothing at all when the user has not asked for it.
 *
 * Limits, stated plainly: whether a given Fire OS build passes the Home key to accessibility services, and whether it
 * lets DustOS start from the background, differs by version. The service checks the second one first and leaves the
 * Home key alone if DustOS could not open anyway, so pressing Home can never be turned into a dead button.
 */
class LauncherGuardService : AccessibilityService() {
    private val prefs by lazy { LauncherPrefs.get(applicationContext) }
    private var homes: Set<String> = emptySet()
    private var homesCheckedAt = 0L
    private var lastBring = 0L
    private var homeKeyDown = false

    private fun active(): Boolean = prefs.overrideHome && System.currentTimeMillis() >= prefs.guardPausedUntil

    /** Other launchers installed on the device. Looked up at most once a minute. */
    private fun otherHomes(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (homesCheckedAt == 0L || now - homesCheckedAt > 60_000L) {
            homes = LauncherControl.otherHomePackages(this)
            homesCheckedAt = now
        }
        return homes
    }

    /** At most once every 1.2 seconds, so two launchers can never fight over the screen. */
    private fun bringDustOsToFront() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBring < 1_200L) return
        lastBring = now
        LauncherControl.bringToFront(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!active() || !LauncherControl.canStartFromBackground(this)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg !in otherHomes()) return
        bringDustOsToFront()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_HOME) return false
        if (!active() || !LauncherControl.canStartFromBackground(this)) {
            homeKeyDown = false
            return false
        }
        when (event.action) {
            KeyEvent.ACTION_DOWN -> if (!homeKeyDown) {
                homeKeyDown = true
                bringDustOsToFront()
            }
            KeyEvent.ACTION_UP -> homeKeyDown = false
        }
        return true
    }

    override fun onInterrupt() {
        // Nothing to interrupt: the service holds no feedback, audio or timers.
    }
}
