package team.deltax.dustos.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.Section
import team.deltax.dustos.launcher.LauncherControl
import kotlin.math.sin

private class HeroCard(
    val title: String, val subtitle: String, val action: String,
    val c1: Color, val c2: Color, val phase: Float, val onClick: () -> Unit,
)

/**
 * Featured banner. Its cards are about the launcher itself (OSee, setup, screensaver, your apps). Fire OS does not let
 * a launcher read other apps' recommendation feeds, so nothing here pretends to be streaming content.
 */
@Composable
fun Hero(vm: DustViewModel, requester: FocusRequester, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val motion = LocalMotion.current
    val isHome = remember(vm.resumeTick) { LauncherControl.isDefaultHome(ctx) }
    val appCount = vm.visibleApps.size
    val cards = remember(isHome, appCount, vm.prefs.oseeEnabled) {
        buildList {
            if (vm.prefs.oseeEnabled) add(
                HeroCard(
                    "Just ask OSee",
                    "Say “Open YouTube”, “What’s the weather?” or “Go to Games”. Type instead if your remote has no voice.",
                    "Talk to OSee", Color(0xFF7C5CFF), Color(0xFFFF6AA8), 0.9f,
                ) { vm.oseeVisible = true }
            )
            add(
                HeroCard(
                    if (isHome) "DustOS 17 is your Home" else "Set DustOS 17 as Home",
                    if (isHome) "The Home button brings you back here. Boot and override options are in Launcher settings."
                    else "Pick DustOS 17 as the default launcher. Fire OS may need the extra steps in Launcher settings.",
                    if (isHome) "Launcher settings" else "Set up", Color(0xFF3B7BFF), Color(0xFFB57CFF), 2.4f,
                ) { vm.settingsPage = "launcher"; vm.section = Section.SETTINGS }
            )
            add(
                HeroCard(
                    "A clock in the scenery",
                    "Layered depth scenes with parallax, your clock and the weather. It starts when you step away.",
                    "Preview", Color(0xFF2FC8B0), Color(0xFF5B8CFF), 4.1f,
                ) { vm.screensaverPreview = true }
            )
            add(
                HeroCard(
                    "$appCount apps ready",
                    "Hold Select on any app for favourites, hide, app info and uninstall.",
                    "Open Apps", Color(0xFFFF8A3D), Color(0xFFE0489F), 5.6f,
                ) { vm.section = Section.APPS }
            )
        }
    }
    var index by remember { mutableIntStateOf(0) }
    var focused by remember { mutableStateOf(false) }
    val safeIndex = index.coerceIn(0, cards.lastIndex)
    val active = LocalActive.current
    LaunchedEffect(safeIndex, motion.enabled, focused, cards.size, active) {
        if (active && motion.enabled && !focused && cards.size > 1) {
            delay(9000)
            index = (safeIndex + 1) % cards.size
        }
    }
    Box(
        modifier
            .glass(rr(40), 0.9f)
            .onKeyEvent { ev ->
                if (ev.type != KeyEventType.KeyDown) false
                else when (ev.key) {
                    Key.DirectionRight -> if (safeIndex < cards.lastIndex) { index = safeIndex + 1; true } else false
                    Key.DirectionLeft -> if (safeIndex > 0) { index = safeIndex - 1; true } else false
                    else -> false
                }
            }
    ) {
        AnimatedContent(
            targetState = safeIndex,
            transitionSpec = {
                if (motion.enabled) fadeIn(tween(520)) togetherWith fadeOut(tween(320))
                else EnterTransition.None togetherWith ExitTransition.None
            },
            label = "hero",
        ) { i -> HeroFace(cards[i.coerceIn(0, cards.lastIndex)]) }

        Row(Modifier.align(Alignment.BottomStart).padding(start = 44.dp, bottom = 34.dp)) {
            PillButton(
                text = cards[safeIndex].action,
                onClick = { cards[safeIndex].onClick() },
                requester = requester,
                onFocusChange = { focused = it },
                memoryKey = "hero",
            )
        }
        Row(Modifier.align(Alignment.BottomEnd).padding(end = 40.dp, bottom = 32.dp), verticalAlignment = Alignment.CenterVertically) {
            for (i in cards.indices) {
                Box(
                    Modifier.padding(horizontal = 4.dp)
                        .size(width = if (i == safeIndex) 26.dp else 9.dp, height = 9.dp)
                        .background(if (i == safeIndex) Color.White else Color.White.copy(alpha = 0.42f), CircleShape)
                )
            }
        }
    }
}

@Composable
private fun HeroFace(c: HeroCard) {
    val pal = LocalPalette.current
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(c.c1.copy(alpha = 0.62f), c.c2.copy(alpha = 0.28f), Color.Transparent))))
        Canvas(Modifier.fillMaxSize()) { heroArt(c.c1, c.c2, c.phase) }
        Column(Modifier.padding(start = 44.dp, top = 36.dp).fillMaxWidth(0.60f)) {
            Box(Modifier.background(Color.White.copy(alpha = 0.26f), rr(24)).padding(horizontal = 22.dp, vertical = 6.dp)) {
                Txt("Featured", size = 21.sp, weight = FontWeight.Medium)
            }
            VSpace(16)
            Txt(c.title, size = 54.sp, weight = FontWeight.SemiBold, maxLines = 1)
            VSpace(6)
            Txt(c.subtitle, size = 24.sp, color = pal.textDim, maxLines = 2)
        }
    }
}

private fun DrawScope.ridge(x0: Float, baseY: Float, amp: Float, phase: Float, color: Color) {
    val w = size.width
    val path = Path()
    path.moveTo(x0, size.height)
    var x = x0
    val step = 12.dp.toPx()
    while (x <= w + step) {
        val t = (x - x0) / (w - x0).coerceAtLeast(1f)
        val y = baseY - amp * (0.6f * sin(t * 3.1f + phase) + 0.4f * sin(t * 7.3f + phase * 1.7f))
        path.lineTo(x, y)
        x += step
    }
    path.lineTo(w, size.height)
    path.close()
    drawPath(path, color)
}

/** Pale domes, a glowing sun and layered ridges. Drawn once, never animated, so it costs nothing while idle. */
private fun DrawScope.heroArt(c1: Color, c2: Color, phase: Float) {
    val w = size.width
    val h = size.height
    val dome = Offset(w * 0.76f, h * 1.14f)
    drawCircle(Color.White.copy(alpha = 0.10f), h * 1.06f, dome)
    drawCircle(Color.White.copy(alpha = 0.26f), h * 1.06f, dome, style = Stroke(width = 2.dp.toPx()))
    drawCircle(Color.White.copy(alpha = 0.07f), h * 0.66f, Offset(w * 0.90f, h * 1.06f))
    drawCircle(Color.White.copy(alpha = 0.18f), h * 0.66f, Offset(w * 0.90f, h * 1.06f), style = Stroke(width = 1.5.dp.toPx()))
    val sun = Offset(w * 0.83f, h * 0.36f)
    drawCircle(Brush.radialGradient(listOf(c2.copy(alpha = 0.60f), Color.Transparent), sun, h * 0.56f), h * 0.56f, sun)
    drawCircle(Color.White.copy(alpha = 0.88f), h * 0.034f, sun)
    ridge(w * 0.46f, h * 0.80f, h * 0.10f, phase, lerp(c1, Color.Black, 0.30f).copy(alpha = 0.50f))
    ridge(w * 0.52f, h * 0.89f, h * 0.07f, phase + 1.7f, lerp(c1, Color.Black, 0.52f).copy(alpha = 0.72f))
    ridge(w * 0.58f, h * 0.96f, h * 0.045f, phase + 3.1f, Color(0xFF1B0F3C).copy(alpha = 0.85f))
}
