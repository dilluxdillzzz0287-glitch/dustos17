package team.deltax.dustos.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * The screensaver scenes, as plain data plus a small pixel renderer. Everything is pure Kotlin so it can be tested
 * and previewed on a computer. The Android side only turns the pixel arrays into bitmaps and slides them sideways at
 * different speeds, which is what makes the depth.
 *
 * A scene is a sky gradient, a few glowing bodies (sun, moon, planet) and layers from far (z near 0) to near (z near 1).
 * Layers wrap around horizontally, so a layer can drift forever without a seam.
 */

/** A glowing disc in the sky. [x], [y] are fractions of the screen size, [r] is a fraction of the screen height. */
class Body(val x: Float, val y: Float, val r: Float, val color: Int, val glow: Int, val z: Float, val ring: Boolean = false)

enum class LayerKind { RIDGE, PEAKS, BUILDINGS, STARS, NEBULA, RIBBON }

/** One term of a ridge or ribbon outline. [k] whole repeats across the screen keep the layer seamless. */
class Wave(val k: Int, val amp: Float, val phase: Float = 0f)

class LayerDef(
    val kind: LayerKind,
    val z: Float,
    /** Top of the baked band, as a fraction of the screen height. Everything above it is empty and is not stored. */
    val top: Float,
    val c1: Int,
    val c2: Int,
    /** Ridges and ribbons: baseline as a fraction of the screen height. Stars: the lowest row they may use. */
    val base: Float = 1f,
    val waves: List<Wave> = emptyList(),
    val alpha: Float = 1f,
    val seed: Int = 1,
    /** Stars: how many. Nebula and ribbon: how many. Buildings: percent of windows that are lit. */
    val count: Int = 0,
    /** Stars: share of bigger stars. Nebula: radius. Ribbon: thickness. Buildings: typical width (fractions). */
    val size: Float = 0f,
    val hMin: Float = 0f,
    val hMax: Float = 0f,
    /** Ribbon only: 0 soft band, 1 curtain that is bright at its lower edge. */
    val style: Int = 0,
)

class SceneDef(
    val id: String,
    val sky: IntArray,
    val skyStops: FloatArray,
    /** Colour that distant layers fade towards, so depth reads as air between the layers. */
    val haze: Int,
    val bodies: List<Body>,
    val layers: List<LayerDef>,
    /** Layers with a z above this are drawn in front of the clock. */
    val clockZ: Float = 0.6f,
)

private class Rng(seed: Int) {
    private var s = seed * 7919 + 17
    fun next(): Float {
        s = s * 1664525 + 1013904223
        return ((s ushr 8) and 0xFFFFFF) / 16777216f
    }
}

object SceneArt {
    /** Size the layers are baked at. They are drawn at screen size, so one baked pixel covers two screen pixels. */
    const val RENDER_W = 960
    const val RENDER_H = 540

    fun byId(id: String): SceneDef = when (id) {
        "dunes" -> dunes()
        "flux" -> flux()
        "cosmos" -> cosmos()
        "city" -> city()
        else -> peaks()
    }

    fun bandTop(def: LayerDef, h: Int): Int = (def.top * h).toInt().coerceIn(0, h - 1)

    fun bandHeight(def: LayerDef, h: Int): Int = h - bandTop(def, h)

    /** Height of a ridge above its baseline at horizontal position [u] in 0..1. Periodic: height(0) equals height(1). */
    fun ridgeHeight(def: LayerDef, u: Float): Float {
        var s = 0f
        for (w in def.waves) {
            s += if (def.kind == LayerKind.PEAKS) {
                w.amp * (1f - abs(sin(PI.toFloat() * w.k * u + w.phase)))
            } else {
                w.amp * (0.5f + 0.5f * sin(2f * PI.toFloat() * w.k * u + w.phase))
            }
        }
        return s
    }

    /**
     * Bakes one layer to non-premultiplied ARGB pixels, [w] wide and [bandHeight] tall. [depth] (0..1) is the Depth
     * setting: the further a layer is, the more it fades into the haze colour, which separates the layers.
     */
    fun render(scene: SceneDef, def: LayerDef, depth: Float, w: Int = RENDER_W, h: Int = RENDER_H): IntArray {
        val top = bandTop(def, h)
        val bh = h - top
        val out = IntArray(w * bh)
        val fade = (depth.coerceIn(0f, 1f) * (1f - def.z) * 0.6f).coerceIn(0f, 0.7f)
        val c1 = mix(def.c1, scene.haze, fade)
        val c2 = mix(def.c2, scene.haze, fade)
        when (def.kind) {
            LayerKind.RIDGE, LayerKind.PEAKS -> ridge(out, w, bh, top, h, def, c1, c2)
            LayerKind.BUILDINGS -> buildings(out, w, bh, top, h, def, c1, c2)
            LayerKind.STARS -> stars(out, w, bh, h, def, c1, c2)
            LayerKind.NEBULA -> nebula(out, w, bh, def, c1, c2)
            LayerKind.RIBBON -> ribbon(out, w, bh, top, h, def, c1, c2)
        }
        return out
    }

    // ------------------------------------------------------------------ renderers

    private fun ridge(out: IntArray, w: Int, bh: Int, topPx: Int, h: Int, def: LayerDef, c1: Int, c2: Int) {
        var peak = 0f
        for (wv in def.waves) peak += wv.amp
        val minY = (def.base - peak) * h
        val span = max(1f, h - minY)
        for (x in 0 until w) {
            val u = x / w.toFloat()
            val yTop = (def.base - ridgeHeight(def, u)) * h
            val first = ceil(yTop).toInt()
            val cover = first - yTop
            for (ys in max(first - 1, topPx) until h) {
                val y = ys - topPx
                if (y < 0 || y >= bh) continue
                var col = mix(c1, c2, ((ys - minY) / span).coerceIn(0f, 1f))
                var a = def.alpha
                if (ys == first - 1) {
                    a *= cover
                } else if (ys - first < 3) {
                    col = mix(col, 0xFFFFFF, 0.22f * (1f - (ys - first) / 3f))
                }
                out[y * w + x] = argb(a, col)
            }
        }
    }

    private val Neon = intArrayOf(0xFF4FC8, 0x4FD8FF, 0xFFB84F)
    private val Window = intArrayOf(0xFFD27A, 0xFFD27A, 0xFF7AC8, 0x7AE6FF)

    private fun buildings(out: IntArray, w: Int, bh: Int, topPx: Int, h: Int, def: LayerDef, c1: Int, c2: Int) {
        val rng = Rng(def.seed)
        val minW = max(8, (def.size * w * 0.6f).toInt())
        val maxW = max(minW + 4, (def.size * w * 1.5f).toInt())
        // Widths add up to exactly w, so the last building meets the first one when the layer wraps.
        val widths = ArrayList<Int>()
        var x = 0
        while (x < w) {
            var bw = (minW + rng.next() * (maxW - minW)).toInt()
            if (x + bw > w - minW) bw = w - x
            widths.add(bw)
            x += bw
        }
        var bx = 0
        for (bw in widths) {
            val heightFrac = def.hMin + (def.hMax - def.hMin) * rng.next()
            val top = ((def.base - heightFrac) * h).toInt()
            val neon = if (rng.next() < 0.30f) Neon[(rng.next() * Neon.size).toInt().coerceIn(0, Neon.size - 1)] else -1
            val span = max(1, h - top)
            for (xx in bx until bx + bw) {
                for (ys in max(top, topPx) until h) {
                    val y = ys - topPx
                    if (y < 0 || y >= bh) continue
                    var col = mix(c1, c2, ((ys - top).toFloat() / span).coerceIn(0f, 1f))
                    if (xx == bx || xx == bx + bw - 1) col = mix(col, 0x000000, 0.25f)
                    if (neon >= 0 && ys - top < 2) col = neon
                    out[y * w + xx] = argb(def.alpha, col)
                }
            }
            // lit windows
            var wy = top + 7
            while (wy < h - 6) {
                var wx = bx + 4
                while (wx < bx + bw - 5) {
                    if (rng.next() * 100f < def.count) {
                        val col = Window[(rng.next() * Window.size).toInt().coerceIn(0, Window.size - 1)]
                        for (dy in 0 until 4) for (dx in 0 until 3) {
                            val y = wy + dy - topPx
                            val px = wx + dx
                            if (y in 0 until bh && px in 0 until w) out[y * w + px] = argb(def.alpha * 0.9f, col)
                        }
                    }
                    wx += 8
                }
                wy += 9
            }
            bx += bw
        }
    }

    private fun stars(out: IntArray, w: Int, bh: Int, h: Int, def: LayerDef, c1: Int, c2: Int) {
        val rng = Rng(def.seed)
        val yMax = (def.base * h).toInt().coerceIn(1, bh)
        repeat(def.count) {
            val x = (rng.next() * w).toInt().coerceIn(0, w - 1)
            val y = (rng.next() * yMax).toInt().coerceIn(0, yMax - 1)
            val bright = 0.35f + 0.65f * rng.next()
            val big = rng.next() < def.size
            val col = if (rng.next() < 0.3f) mix(0xFFFFFF, c2, 0.6f) else mix(0xFFFFFF, c1, 0.25f)
            plot(out, w, bh, x, y, col, bright * def.alpha)
            if (big) {
                val s = bright * def.alpha * 0.55f
                plot(out, w, bh, x - 1, y, col, s)
                plot(out, w, bh, x + 1, y, col, s)
                plot(out, w, bh, x, y - 1, col, s)
                plot(out, w, bh, x, y + 1, col, s)
            }
        }
    }

    private fun plot(out: IntArray, w: Int, bh: Int, x: Int, y: Int, rgb: Int, a: Float) {
        if (x < 0 || x >= w || y < 0 || y >= bh) return
        val old = (out[y * w + x] ushr 24) / 255f
        if (a > old) out[y * w + x] = argb(a, rgb)
    }

    private fun nebula(out: IntArray, w: Int, bh: Int, def: LayerDef, c1: Int, c2: Int) {
        val rng = Rng(def.seed)
        for (i in 0 until def.count) {
            val cx = rng.next() * w
            val cy = rng.next() * bh
            val r = def.size * w * (0.6f + 0.6f * rng.next())
            val col = if (i % 2 == 0) c1 else c2
            val strength = def.alpha * (0.5f + 0.5f * rng.next())
            for (shift in intArrayOf(-w, 0, w)) {
                val mx = cx + shift
                val x0 = (mx - r).toInt().coerceAtLeast(0)
                val x1 = (mx + r).toInt().coerceAtMost(w - 1)
                if (x1 < x0) continue
                val y0 = (cy - r).toInt().coerceAtLeast(0)
                val y1 = (cy + r).toInt().coerceAtMost(bh - 1)
                for (y in y0..y1) for (x in x0..x1) {
                    val dx = x - mx
                    val dy = y - cy
                    val d = sqrt(dx * dx + dy * dy) / r
                    if (d >= 1f) continue
                    val f = 1f - d
                    blendOver(out, y * w + x, col, strength * f * f * (3f - 2f * f))
                }
            }
        }
    }

    private fun ribbon(out: IntArray, w: Int, bh: Int, topPx: Int, h: Int, def: LayerDef, c1: Int, c2: Int) {
        val rng = Rng(def.seed)
        val twoPi = 2f * PI.toFloat()
        for (rb in 0 until def.count) {
            val ph1 = rng.next() * twoPi
            val ph2 = rng.next() * twoPi
            val offset = (rb - (def.count - 1) / 2f) * def.size * 0.35f
            for (x in 0 until w) {
                val u = x / w.toFloat()
                var yc = def.base + offset
                for (wv in def.waves) yc += wv.amp * sin(twoPi * wv.k * u + wv.phase + ph1)
                val thick = def.size * (0.65f + 0.35f * sin(twoPi * 2f * u + ph2))
                val yTop = (yc - thick / 2f) * h - topPx
                val yBot = (yc + thick / 2f) * h - topPx
                val col = mix(c1, c2, 0.5f + 0.5f * cos(twoPi * u + rb))
                val y0 = yTop.toInt().coerceAtLeast(0)
                val y1 = yBot.toInt().coerceAtMost(bh - 1)
                val span = max(1f, yBot - yTop)
                for (y in y0..y1) {
                    val v = ((y - yTop) / span).coerceIn(0f, 1f)
                    val prof = if (def.style == 1) curtain(v) else silk(v)
                    blendOver(out, y * w + x, col, def.alpha * prof)
                }
            }
        }
    }

    private fun silk(v: Float): Float {
        val e = 1f - abs(2f * v - 1f)
        return e * e * (3f - 2f * e)
    }

    private fun curtain(v: Float): Float = if (v < 0.85f) (v / 0.85f).pow(1.8f) else (1f - v) / 0.15f

    // ------------------------------------------------------------------ colour helpers

    fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val r = ((a shr 16 and 255) + ((b shr 16 and 255) - (a shr 16 and 255)) * k).roundToInt()
        val g = ((a shr 8 and 255) + ((b shr 8 and 255) - (a shr 8 and 255)) * k).roundToInt()
        val bl = ((a and 255) + ((b and 255) - (a and 255)) * k).roundToInt()
        return (r shl 16) or (g shl 8) or bl
    }

    fun argb(alpha: Float, rgb: Int): Int = ((alpha * 255f + 0.5f).toInt().coerceIn(0, 255) shl 24) or (rgb and 0xFFFFFF)

    private fun blendOver(out: IntArray, i: Int, rgb: Int, a: Float) {
        if (a <= 0f) return
        val sa = a.coerceAtMost(1f)
        val d = out[i]
        val da = (d ushr 24) / 255f
        if (da <= 0f) {
            out[i] = argb(sa, rgb)
            return
        }
        val oa = sa + da * (1f - sa)
        val sr = rgb shr 16 and 255
        val sg = rgb shr 8 and 255
        val sb = rgb and 255
        val dr = d shr 16 and 255
        val dg = d shr 8 and 255
        val db = d and 255
        val r = ((sr * sa + dr * da * (1f - sa)) / oa).roundToInt().coerceIn(0, 255)
        val g = ((sg * sa + dg * da * (1f - sa)) / oa).roundToInt().coerceIn(0, 255)
        val b = ((sb * sa + db * da * (1f - sa)) / oa).roundToInt().coerceIn(0, 255)
        out[i] = ((oa * 255f + 0.5f).toInt().coerceIn(0, 255) shl 24) or (r shl 16) or (g shl 8) or b
    }

    // ------------------------------------------------------------------ scenes

    private fun ridgeLayer(z: Float, base: Float, waves: List<Wave>, c1: Int, c2: Int, kind: LayerKind = LayerKind.PEAKS, alpha: Float = 1f): LayerDef {
        var peak = 0f
        for (w in waves) peak += w.amp
        return LayerDef(kind, z, (base - peak - 0.015f).coerceAtLeast(0f), c1, c2, base = base, waves = waves, alpha = alpha)
    }

    private fun skyline(z: Float, base: Float, hMin: Float, hMax: Float, width: Float, c1: Int, c2: Int, lit: Int, seed: Int): LayerDef =
        LayerDef(LayerKind.BUILDINGS, z, (base - hMax - 0.02f).coerceAtLeast(0f), c1, c2, base = base, seed = seed, count = lit, size = width, hMin = hMin, hMax = hMax)

    private fun starLayer(z: Float, rows: Float, count: Int, big: Float, seed: Int, alpha: Float = 1f, c1: Int = 0xFFFFFF, c2: Int = 0xB9C8FF): LayerDef =
        LayerDef(LayerKind.STARS, z, 0f, c1, c2, base = rows, alpha = alpha, seed = seed, count = count, size = big)

    private fun peaks() = SceneDef(
        "peaks",
        intArrayOf(0x1B1448, 0x4A2F8F, 0xB5509E, 0xFF9A7A),
        floatArrayOf(0f, 0.45f, 0.78f, 1f),
        haze = 0xE79BB8,
        bodies = listOf(Body(0.74f, 0.20f, 0.045f, 0xFFF3E0, 0xB99BFF, 0.05f)),
        layers = listOf(
            starLayer(0.03f, 0.55f, 170, 0.12f, 3),
            LayerDef(LayerKind.RIBBON, 0.12f, 0f, 0x5BF0C8, 0xB99BFF, base = 0.30f, waves = listOf(Wave(1, 0.04f, 0.3f), Wave(3, 0.015f, 1.1f)), alpha = 0.34f, seed = 5, count = 2, size = 0.20f, style = 1),
            ridgeLayer(0.18f, 0.66f, listOf(Wave(2, 0.10f, 0.4f), Wave(5, 0.035f, 1.3f)), 0x9B7BD8, 0x6C4FB4, alpha = 0.95f),
            ridgeLayer(0.34f, 0.74f, listOf(Wave(3, 0.12f, 2.0f), Wave(7, 0.04f, 0.2f)), 0x7455BE, 0x4B3592),
            ridgeLayer(0.52f, 0.82f, listOf(Wave(2, 0.15f, 0.9f), Wave(5, 0.07f, 2.7f), Wave(11, 0.02f, 0.5f)), 0x5238A0, 0x2E2370),
            ridgeLayer(0.78f, 0.92f, listOf(Wave(1, 0.30f, 0.6f), Wave(3, 0.12f, 2.2f), Wave(6, 0.04f, 1.0f)), 0x30226E, 0x150F3D),
            ridgeLayer(1.0f, 1.0f, listOf(Wave(2, 0.05f, 0.4f), Wave(4, 0.03f, 1.9f)), 0x120C30, 0x0A0720, kind = LayerKind.RIDGE),
        ),
    )

    private fun dunes() = SceneDef(
        "dunes",
        intArrayOf(0x3A2A7A, 0xB04A9A, 0xFF7E5F, 0xFFC07A),
        floatArrayOf(0f, 0.42f, 0.76f, 1f),
        haze = 0xFFB08A,
        bodies = listOf(Body(0.50f, 0.60f, 0.075f, 0xFFF1C8, 0xFF8A5A, 0.05f)),
        layers = listOf(
            starLayer(0.03f, 0.32f, 90, 0.10f, 4, alpha = 0.7f),
            ridgeLayer(0.15f, 0.67f, listOf(Wave(1, 0.05f, 0.5f), Wave(2, 0.03f, 1.6f)), 0xF08A8A, 0xC85E86, kind = LayerKind.RIDGE),
            ridgeLayer(0.30f, 0.75f, listOf(Wave(2, 0.07f, 2.1f), Wave(3, 0.03f, 0.3f)), 0xD4638A, 0x9C4380, kind = LayerKind.RIDGE),
            ridgeLayer(0.50f, 0.83f, listOf(Wave(1, 0.09f, 0.2f), Wave(3, 0.04f, 1.4f)), 0xA44A7E, 0x6A3070, kind = LayerKind.RIDGE),
            ridgeLayer(0.80f, 0.92f, listOf(Wave(1, 0.14f, 1.1f), Wave(2, 0.07f, 0.4f), Wave(5, 0.02f, 2.2f)), 0x4A2768, 0x26143F, kind = LayerKind.RIDGE),
            ridgeLayer(1.0f, 1.0f, listOf(Wave(3, 0.03f, 0.7f), Wave(5, 0.015f, 2.0f)), 0x170B2C, 0x0D0620, kind = LayerKind.RIDGE),
        ),
    )

    private fun cosmos() = SceneDef(
        "cosmos",
        intArrayOf(0x04021A, 0x0F0730, 0x1E0C4C),
        floatArrayOf(0f, 0.55f, 1f),
        haze = 0x2E2066,
        bodies = listOf(
            Body(0.22f, 0.30f, 0.030f, 0xE8E0FF, 0x7A6AE0, 0.3f),
            Body(0.76f, 1.00f, 0.34f, 0x4B2E9A, 0xB07CFF, 0.85f, ring = true),
        ),
        layers = listOf(
            LayerDef(LayerKind.NEBULA, 0.08f, 0f, 0x7A3CE0, 0xE0489F, alpha = 0.30f, seed = 7, count = 6, size = 0.24f),
            starLayer(0.10f, 1f, 260, 0.06f, 21),
            starLayer(0.30f, 1f, 130, 0.12f, 22),
            starLayer(0.60f, 1f, 60, 0.25f, 23),
        ),
        clockZ = 0.7f,
    )

    private fun flux() = SceneDef(
        "flux",
        intArrayOf(0x2B0F6B, 0x7B2FBE, 0xE0489F, 0xFF9A3D),
        floatArrayOf(0f, 0.40f, 0.75f, 1f),
        haze = 0xE0489F,
        bodies = emptyList(),
        layers = listOf(
            LayerDef(LayerKind.RIBBON, 0.12f, 0f, 0xFF9A3D, 0xFF5A9A, base = 0.62f, waves = listOf(Wave(1, 0.08f, 0.3f), Wave(2, 0.04f, 1.2f)), alpha = 0.30f, seed = 11, count = 2, size = 0.30f),
            LayerDef(LayerKind.RIBBON, 0.30f, 0f, 0xB57CFF, 0xFF7AB6, base = 0.55f, waves = listOf(Wave(1, 0.10f, 2.0f), Wave(3, 0.03f, 0.5f)), alpha = 0.38f, seed = 12, count = 2, size = 0.22f),
            LayerDef(LayerKind.RIBBON, 0.50f, 0f, 0x7DA2FF, 0xE0A0FF, base = 0.48f, waves = listOf(Wave(2, 0.09f, 0.9f), Wave(3, 0.04f, 2.2f)), alpha = 0.42f, seed = 13, count = 2, size = 0.18f),
            LayerDef(LayerKind.RIBBON, 0.80f, 0f, 0xFF6AA8, 0xFFB07A, base = 0.72f, waves = listOf(Wave(1, 0.12f, 1.4f), Wave(2, 0.05f, 0.1f)), alpha = 0.35f, seed = 14, count = 1, size = 0.34f),
            LayerDef(LayerKind.RIBBON, 1.0f, 0f, 0x2B0F6B, 0x5B2FA0, base = 0.92f, waves = listOf(Wave(1, 0.06f, 0.2f), Wave(3, 0.03f, 1.7f)), alpha = 0.50f, seed = 15, count = 1, size = 0.30f),
            starLayer(0.20f, 1f, 60, 0.30f, 31, alpha = 0.8f, c1 = 0xFFE8F4, c2 = 0xFFD0A0),
        ),
    )

    private fun city() = SceneDef(
        "city",
        intArrayOf(0x120A3A, 0x4B1D8C, 0xD6459A, 0xFF9A6A),
        floatArrayOf(0f, 0.45f, 0.80f, 1f),
        haze = 0xE7699A,
        bodies = listOf(Body(0.80f, 0.22f, 0.05f, 0xFFF0E0, 0xFF8AD0, 0.05f)),
        layers = listOf(
            starLayer(0.03f, 0.45f, 110, 0.10f, 41),
            skyline(0.15f, 0.70f, 0.06f, 0.20f, 0.035f, 0x5A3AA8, 0x3C2A86, 10, 51),
            skyline(0.30f, 0.80f, 0.08f, 0.26f, 0.045f, 0x40298F, 0x2A1D6A, 25, 52),
            skyline(0.50f, 0.90f, 0.10f, 0.30f, 0.055f, 0x2B1C6A, 0x1B1248, 35, 53),
            skyline(0.80f, 1.00f, 0.10f, 0.46f, 0.080f, 0x170C3C, 0x0D0726, 30, 54),
        ),
    )
}
