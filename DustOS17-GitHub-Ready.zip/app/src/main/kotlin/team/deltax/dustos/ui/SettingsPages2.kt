package team.deltax.dustos.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import team.deltax.dustos.DustViewModel
import team.deltax.dustos.core.ClockMath
import team.deltax.dustos.core.GeoPlace
import team.deltax.dustos.core.SceneCatalog
import team.deltax.dustos.data.SystemIntents
import team.deltax.dustos.data.VideoSources
import team.deltax.dustos.data.WeatherState
import java.io.File
import java.util.Calendar
import java.util.Locale

@Composable
fun ScreensaverPage(vm: DustViewModel) {
    val p = vm.prefs
    val ctx = LocalContext.current
    var videos by remember { mutableStateOf<List<File>>(emptyList()) }
    var scanned by remember { mutableStateOf(false) }
    LaunchedEffect(vm.resumeTick) {
        videos = withContext(Dispatchers.IO) { VideoSources.list(ctx) }
        scanned = true
    }
    val scenes = SceneCatalog.all
    val videoIndex = videos.indexOfFirst { it.absolutePath == p.ssVideo } + 1
    val folder = remember { VideoSources.folders(ctx).firstOrNull()?.path ?: "the DustOS app folder" }

    SettingsColumn {
        SettingHeader("Screensaver")
        SettingToggle("Screensaver", p.ssEnabled, "Starts by itself when nothing has been pressed for the time below") { p.ssEnabled = it }
        SettingSlider("Start after", p.ssDelay, 1..60, 1, " min", "Idle time with the launcher in front") { p.ssDelay = it }
        SettingAction("Preview screensaver", "Preview", "Shows it now. Press any button to come back") { vm.screensaverPreview = true }

        SettingHeader("Scene")
        SettingChoice("Built-in scene", scenes.map { it.name }, SceneCatalog.indexOf(p.ssScene), "Layered scenery drawn by the launcher. No video file needed.") { p.ssScene = scenes[it].id }
        SettingChoice(
            "Video screensaver",
            listOf("Off, use the scene") + videos.map { it.name },
            videoIndex,
            "Plays a video file from this device instead of the scene",
        ) { i -> p.ssVideo = if (i <= 0 || i - 1 >= videos.size) "" else videos[i - 1].absolutePath }
        if (scanned && p.ssVideo.isNotEmpty() && videoIndex == 0) {
            SettingNote("The video you chose is no longer there, so the built-in scene is used.")
        }
        if (scanned && videos.isEmpty()) {
            SettingNote("No video files found. Copy a short looping .mp4 or .webm into $folder, then come back here. Whether it plays depends on the video formats your device's hardware decoder supports.")
        } else {
            SettingNote("Video files are read from $folder. They are never uploaded anywhere.")
        }

        SettingHeader("What it shows")
        SettingToggle("Clock", p.ssClock, "Style, size and position are set in the Clock page") { p.ssClock = it }
        SettingToggle("Weather", p.ssWeather, "Needs the weather setting to be on") { p.ssWeather = it }
        SettingSlider("Depth", p.ssDepth, 0..100, 5, "%", "How strongly the layers separate. The clock sits between the layers, so the foreground can overlap it.") { p.ssDepth = it }
        SettingSlider("Speed", p.ssSpeed, 25..200, 25, "%", "How fast the scenery moves") { p.ssSpeed = it }
        SettingSlider("Dimming", p.ssDim, 0..80, 5, "%", "Darkens the picture, useful in a dark room") { p.ssDim = it }
        SettingToggle("Keep the TV awake", p.ssAwake, "Stops the TV from going to sleep while the screensaver is showing, so it can work as a clock. Off by default: leave it off if you want the TV to sleep by itself.") { p.ssAwake = it }
        SettingNote("This is DustOS's own screensaver. It only starts while the launcher is in front and nothing is pressed, and it stops drawing when the TV turns off or another app opens. It does not replace Android's system screensaver.")
    }
}

@Composable
fun WeatherPage(vm: DustViewModel) {
    val p = vm.prefs
    val host = LocalHost.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<GeoPlace>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var searchedFor by remember { mutableStateOf<String?>(null) }
    val locationOk = remember(vm.permTick, vm.resumeTick) { host.locationGranted() }

    fun runSearch() {
        val q = query.trim()
        if (q.length < 2 || busy) return
        busy = true
        scope.launch {
            results = vm.weatherRepo.search(q)
            searchedFor = q
            busy = false
        }
    }

    val refreshValues = listOf(15, 30, 60, 120, 180, 360)
    val refreshNames = listOf("15 minutes", "30 minutes", "1 hour", "2 hours", "3 hours", "6 hours")
    val refreshIndex = refreshValues.indexOfFirst { it >= p.wxRefreshMin }.let { if (it < 0) refreshValues.lastIndex else it }

    SettingsColumn {
        SettingHeader("Weather")
        SettingToggle("Weather", p.wxEnabled, "Shows the weather card on Home and on the screensaver") { p.wxEnabled = it; if (it) vm.refreshWeather(false) }

        SettingHeader("Location")
        SettingChoice(
            "Location",
            listOf("Manual city", "Automatic"),
            if (p.wxAuto) 1 else 0,
            "Automatic uses the last location Android already knows, with your permission",
        ) { i ->
            p.wxAuto = i == 1
            if (i == 1 && !host.locationGranted()) host.requestLocationPermission() else vm.refreshWeather(true)
        }
        SettingInfo("Showing weather for", if (p.wxAuto && locationOk) "Current location (approximate)" else p.wxName)
        if (p.wxAuto && !locationOk) {
            SettingAction("Allow location", "Allow", "Until you do, the manual city is used") { host.requestLocationPermission() }
        }
        SettingNote("Many Fire TV sticks have no location source at all. If Android has no location, DustOS keeps using the manual city and says so on the weather card.")

        SettingHeader("Choose a city")
        TvTextField(query, { query = it }, "Select to type a city name", onSubmit = { runSearch() })
        SettingAction("Search for this city", if (busy) "Searching…" else "Search", "Looks the name up online") { runSearch() }
        if (searchedFor != null && results.isEmpty() && !busy) {
            SettingNote("No city found for “$searchedFor”. Check the spelling, or try the nearest larger town. Searching needs an internet connection.")
        }
        for (r in results) {
            SettingAction(r.label, "Use", String.format(Locale.US, "%.2f, %.2f", r.lat, r.lon)) {
                p.wxLat = r.lat
                p.wxLon = r.lon
                p.wxName = r.label
                p.wxAuto = false
                results = emptyList()
                query = ""
                searchedFor = null
                vm.refreshWeather(true)
                vm.showToast("Weather location set to ${r.name}")
            }
        }

        SettingHeader("Units and updates")
        SettingChoice("Temperature", listOf("Celsius", "Fahrenheit"), if (p.wxFahrenheit) 1 else 0, "Wind speed follows it: km/h or mph") { p.wxFahrenheit = it == 1 }
        SettingChoice("Update every", refreshNames, refreshIndex, "The last good update is kept, so the card still shows weather offline") { p.wxRefreshMin = refreshValues[it] }
        SettingToggle("Forecast", p.wxForecast, "Show the coming days on the weather card") { p.wxForecast = it }
        SettingAction("Update now", "Update", "Fetches fresh weather") { vm.refreshWeather(true); vm.showToast("Updating weather") }

        val w = vm.weather
        if (w is WeatherState.Ready) {
            val c = Calendar.getInstance().apply { timeInMillis = w.snap.fetchedAtMs }
            val time = ClockMath.timeText(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), 0, p.clock24h, false, true)
            SettingInfo("Last update", if (w.stale) "$time (offline copy)" else time)
        }
        SettingInfo("Data source", "Open-Meteo.com")
        SettingNote("Weather data by Open-Meteo.com (CC BY 4.0). No account or key is needed. DustOS only sends the coordinates of the chosen place.")
    }
}

@Composable
fun SystemPage(vm: DustViewModel) {
    val p = vm.prefs
    val ctx = LocalContext.current
    val refreshValues = listOf(0, 2, 5, 10, 30, 60)
    val refreshNames = listOf("Manual only", "Every 2 seconds", "Every 5 seconds", "Every 10 seconds", "Every 30 seconds", "Every minute")
    val refreshIndex = refreshValues.indexOfFirst { it >= p.sysRefresh }.let { if (it < 0) refreshValues.lastIndex else it }

    SettingsColumn {
        SettingHeader("RAM and system widget")
        SettingToggle("Show the widget on Home", p.sysEnabled) { p.sysEnabled = it }
        SettingChoice("Size", listOf("Small", "Medium", "Large"), p.sysSize, "Small is one line. Large shows every statistic. Select the widget for the memory-heavy apps list, where Android allows it.") { p.sysSize = it }
        SettingChoice("Detail", listOf("Minimal", "Detailed"), if (p.sysDetailed) 1 else 0, "Minimal shows just the RAM gauge. Detailed adds storage, CPU and the other statistics you turned on, in Medium and Large.") { p.sysDetailed = it == 1 }
        SettingChoice("Position", listOf("Right column, below weather", "Right column, above weather", "Own row"), p.sysPos) { p.sysPos = it }
        SettingChoice("Auto-refresh", refreshNames, refreshIndex, "It only refreshes while the home screen is showing") { p.sysRefresh = refreshValues[it] }

        SettingHeader("Statistics")
        SettingToggle("RAM", p.sysRam, "Total, used, available and percentage") { p.sysRam = it }
        SettingToggle("CPU", p.sysCpu, "Many devices don't let apps read it. The widget then says it isn't available.") { p.sysCpu = it }
        SettingToggle("Storage", p.sysStorage) { p.sysStorage = it }
        SettingToggle("Temperature", p.sysTemp, "Thermal state on Android 10+, battery temperature where there is a battery") { p.sysTemp = it }
        SettingToggle("Battery", p.sysBattery, "Hidden on devices without a battery, such as Fire TV sticks") { p.sysBattery = it }

        SettingHeader("Memory")
        SettingAction("Open Android app manager", "Open", "Stop or clear apps with Android's own controls") {
            if (!SystemIntents.open(ctx, SystemIntents.appManager())) vm.showToast("This device has no app manager page")
        }
        SettingNote("The numbers come straight from Android. DustOS never claims to free memory, never force-stops apps and runs no cleaner. Android manages RAM itself, and a low \"available\" number is normal. Since Android 5.1, apps can only see their own process, so the heavy-apps list is often short.")
    }
}
