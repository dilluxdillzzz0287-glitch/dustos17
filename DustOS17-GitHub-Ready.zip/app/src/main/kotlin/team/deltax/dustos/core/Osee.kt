package team.deltax.dustos.core

enum class Section { HOME, APPS, GAMES, SETTINGS }
enum class SystemTarget { WIFI, DISPLAY, SOUND, BLUETOOTH, APP_MANAGER, ALL_SETTINGS }
enum class LauncherOption { CLOCK_24H, ANIMATIONS, WEATHER_CARD, SYSTEM_WIDGET, CLOCK_SECONDS }
enum class VolumeCmd { UP, DOWN, MUTE, UNMUTE }

/** What OSee AI understood. Executing these is the job of the Android layer. */
sealed interface OseeAction {
    data class OpenApp(val query: String) : OseeAction
    data class Search(val query: String, val inApp: String?, val play: Boolean) : OseeAction
    data class Navigate(val section: Section) : OseeAction
    data class OpenSystem(val target: SystemTarget) : OseeAction
    data class SetOption(val option: LauncherOption, val enabled: Boolean) : OseeAction
    data class Volume(val cmd: VolumeCmd) : OseeAction
    data class General(val text: String) : OseeAction
    data object ShowTime : OseeAction
    data object ShowDate : OseeAction
    data object ShowWeather : OseeAction
    data object ShowMemory : OseeAction
    data object ShowStorage : OseeAction
    data object StartScreensaver : OseeAction
    data object Greeting : OseeAction
    data object Thanks : OseeAction
    data object Help : OseeAction
    data object WhoAreYou : OseeAction
    data object Close : OseeAction
    data object Empty : OseeAction
}

object OseeParser {
    private val prefixes = listOf(
        "hey osee", "hi osee", "hello osee", "ok osee", "okay osee", "osee",
        "please", "can you", "could you", "would you", "will you", "i want you to", "i want to",
        "i would like to", "id like to", "i need to", "i wanna", "lets", "go ahead and", "just", "kindly",
    )
    private val trailing = listOf("please", "for me", "now", "thanks", "thank you")

    private val closeWords = setOf("close", "cancel", "never mind", "nevermind", "stop", "dismiss", "exit", "go away", "quit", "bye", "goodbye", "forget it")
    private val greetings = setOf("hello", "hi", "hey", "hello there", "hi there", "good morning", "good afternoon", "good evening", "namaste")
    private val thanks = setOf("thanks", "thank you", "thank you osee", "thanks osee", "cheers")
    private val webWords = setOf("web", "the web", "internet", "the internet", "google", "online")

    private val sectionMap = mapOf(
        "home" to Section.HOME, "home screen" to Section.HOME, "main screen" to Section.HOME, "main menu" to Section.HOME, "back" to Section.HOME,
        "apps" to Section.APPS, "all apps" to Section.APPS, "app list" to Section.APPS, "my apps" to Section.APPS,
        "applications" to Section.APPS, "app drawer" to Section.APPS,
        "games" to Section.GAMES, "game" to Section.GAMES, "gaming" to Section.GAMES, "my games" to Section.GAMES,
        "settings" to Section.SETTINGS, "setting" to Section.SETTINGS, "preferences" to Section.SETTINGS,
        "launcher settings" to Section.SETTINGS, "dustos settings" to Section.SETTINGS,
    )

    private val navVerbs = listOf("take me to", "bring up", "switch to", "go to", "goto", "show me", "launch", "open", "start", "run", "load", "show", "go")
    private val searchVerbs = listOf("search for", "look up", "lookup", "search", "find", "google", "watch", "play")

    fun normalize(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            when {
                ch == '\'' || ch == '’' -> Unit
                ch == '+' -> sb.append(" plus ")
                ch.isLetterOrDigit() -> sb.append(ch)
                else -> sb.append(' ')
            }
        }
        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }

    private fun stripPrefixes(text: String): String {
        var s = text
        var changed = true
        while (changed && s.isNotEmpty()) {
            changed = false
            for (p in prefixes) {
                if (s == p) { s = ""; changed = true; break }
                if (s.startsWith("$p ")) { s = s.removePrefix("$p ").trim(); changed = true; break }
            }
        }
        return s
    }

    private fun stripTrailing(text: String): String {
        var s = text
        var changed = true
        while (changed && s.isNotEmpty()) {
            changed = false
            for (p in trailing) {
                if (s.endsWith(" $p")) { s = s.removeSuffix(" $p").trim(); changed = true; break }
            }
        }
        return s
    }

    fun parse(raw: String): OseeAction {
        val original = normalize(raw)
        if (original.isEmpty()) return OseeAction.Empty
        val t = stripTrailing(stripPrefixes(original))
        if (t.isEmpty()) return OseeAction.Greeting
        val words = t.split(' ')
        fun has(vararg w: String) = w.any { it in words }
        fun phrase(vararg p: String) = p.any { t.contains(it) }

        if (t in closeWords) return OseeAction.Close
        if (t in greetings) return OseeAction.Greeting
        if (t in thanks) return OseeAction.Thanks
        if (phrase("who are you", "what are you", "your name", "are you alexa", "are you google")) return OseeAction.WhoAreYou
        if (t == "help" || phrase("what can you do", "what can i say", "what can i ask", "list commands", "show commands")) return OseeAction.Help

        parseOption(t, words)?.let { return it }

        // Volume
        if (phrase("volume up", "louder", "increase volume", "raise the volume", "volume higher") || Regex("^turn (it )?up( the volume)?$").matches(t)) {
            return OseeAction.Volume(VolumeCmd.UP)
        }
        if (phrase("volume down", "quieter", "lower the volume", "decrease volume", "reduce volume", "softer") || Regex("^turn (it )?down( the volume)?$").matches(t)) {
            return OseeAction.Volume(VolumeCmd.DOWN)
        }
        if (has("unmute")) return OseeAction.Volume(VolumeCmd.UNMUTE)
        if (has("mute")) return OseeAction.Volume(VolumeCmd.MUTE)

        if (phrase("screensaver", "screen saver")) return OseeAction.StartScreensaver

        parseSearch(t)?.let { return it }

        // Information questions
        if (phrase("what time", "the time", "current time", "time is it", "time now") || t == "time") return OseeAction.ShowTime
        if (phrase("what day", "which day", "todays date", "the date", "what date", "date today", "date is it", "what is today", "whats today", "day is it")) {
            return OseeAction.ShowDate
        }
        if (has("weather", "temperature", "forecast", "humidity", "humid", "raining", "windy", "sunrise", "sunset") || phrase("how hot", "how cold", "how warm", "is it raining")) {
            return OseeAction.ShowWeather
        }
        if (has("ram", "memory") && !has("game")) return OseeAction.ShowMemory
        if (has("storage") || phrase("disk space", "free space")) return OseeAction.ShowStorage

        // Navigation, system pages and apps
        var target = t
        var hadVerb = false
        for (v in navVerbs) {
            if (t == v) return OseeAction.Help
            if (t.startsWith("$v ")) { target = t.removePrefix("$v ").trim(); hadVerb = true; break }
        }
        target = target.removePrefix("the ").removePrefix("my ").trim()
        if (target.isEmpty()) return OseeAction.Help
        sectionMap[target]?.let { return OseeAction.Navigate(it) }
        systemTarget(target)?.let { return OseeAction.OpenSystem(it) }

        if (hadVerb) return OseeAction.OpenApp(target.removeSuffix(" app").removeSuffix(" application").trim())

        val first = words.first()
        if (first in setOf("who", "what", "whats", "when", "where", "why", "how", "which", "is", "are", "does", "do", "did", "can", "tell", "explain", "define", "calculate", "translate")) {
            return OseeAction.General(raw.trim())
        }
        return if (words.size <= 3) OseeAction.OpenApp(t) else OseeAction.General(raw.trim())
    }

    private fun systemTarget(target: String): SystemTarget? = when {
        target.contains("manage apps") || target.contains("app manager") || target.contains("application manager") ||
            target.contains("manage applications") || target.contains("app settings") -> SystemTarget.APP_MANAGER
        target.contains("wifi") || target.contains("wi fi") || target.contains("network") || target.contains("internet settings") -> SystemTarget.WIFI
        target.contains("bluetooth") || target.contains("remote settings") || target.contains("controller") -> SystemTarget.BLUETOOTH
        target.contains("sound") || target.contains("audio settings") -> SystemTarget.SOUND
        target == "display" || target.contains("display settings") || target.contains("screen settings") || target.contains("resolution") -> SystemTarget.DISPLAY
        target.contains("system settings") || target.contains("android settings") || target.contains("device settings") ||
            target.contains("all settings") || target.contains("fire tv settings") -> SystemTarget.ALL_SETTINGS
        else -> null
    }

    private fun parseSearch(t: String): OseeAction? {
        if (t.startsWith("find out")) return null
        for (v in searchVerbs.sortedByDescending { it.length }) {
            if (!t.startsWith("$v ")) continue
            var rest = t.removePrefix("$v ").trim()
            if (rest.isEmpty()) return null
            val play = v == "play" || v == "watch"
            var app: String? = null
            val idx = rest.lastIndexOf(" on ")
            if (idx > 0) {
                app = rest.substring(idx + 4).trim()
                rest = rest.substring(0, idx).trim()
            } else if (v == "search" && " for " in rest && !rest.startsWith("for ")) {
                app = rest.substringBefore(" for ").trim()
                rest = rest.substringAfter(" for ").trim()
            }
            if (app != null && (app.isEmpty() || app in webWords)) app = null
            if (rest.isEmpty()) return null
            return OseeAction.Search(rest, app?.removeSuffix(" app")?.trim(), play)
        }
        return null
    }

    private fun parseOption(t: String, words: List<String>): OseeAction? {
        val off = Regex("^(turn off|switch off|disable|hide|stop showing)\\b").containsMatchIn(t) ||
            Regex("\\b(turn|switch)\\b.*\\boff\\b").containsMatchIn(t)
        val on = Regex("^(turn on|switch on|enable|show|use|switch to|start showing)\\b").containsMatchIn(t) ||
            Regex("\\b(turn|switch)\\b.*\\bon\\b").containsMatchIn(t)
        val verb = on || off
        val enable = !off

        fun any(vararg p: String) = p.any { t.contains(it) }
        if (any("24 hour", "24h", "twenty four hour", "military time")) {
            return OseeAction.SetOption(LauncherOption.CLOCK_24H, enable)
        }
        if (any("12 hour", "12h", "twelve hour")) {
            return OseeAction.SetOption(LauncherOption.CLOCK_24H, off)
        }
        if (!verb) return null
        if (any("animation", "motion")) return OseeAction.SetOption(LauncherOption.ANIMATIONS, enable)
        if (t.contains("weather") && any("card", "widget", "tile", "panel")) return OseeAction.SetOption(LauncherOption.WEATHER_CARD, enable)
        if (any("widget", "monitor") && ("ram" in words || "memory" in words || "system" in words || "performance" in words || "stats" in words)) {
            return OseeAction.SetOption(LauncherOption.SYSTEM_WIDGET, enable)
        }
        if ("seconds" in words) return OseeAction.SetOption(LauncherOption.CLOCK_SECONDS, enable)
        return null
    }
}

/** Fuzzy "which installed app did the user mean" matching. */
object AppMatcher {
    private val noise = setOf("app", "application", "the", "my", "a")
    private val aliases = mapOf(
        "yt" to "youtube", "you tube" to "youtube", "prime" to "prime video", "amazon prime" to "prime video",
        "amazon prime video" to "prime video", "hot star" to "hotstar", "jio cinema" to "jiocinema",
        "net flix" to "netflix", "apple television" to "apple tv", "files" to "file manager",
    )

    fun canonical(s: String): String {
        val n = OseeParser.normalize(s).split(' ').filter { it.isNotEmpty() && it !in noise }.joinToString(" ")
        return aliases[n] ?: n
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[b.length]
    }

    fun score(q: String, l: String): Int {
        if (q.isEmpty() || l.isEmpty()) return 0
        if (q == l) return 100
        val qt = q.split(' ')
        val lt = l.split(' ')
        if (l.startsWith(q)) return 90 - (l.length - q.length).coerceAtMost(20)
        if (q.startsWith(l)) return 85 - (q.length - l.length).coerceAtMost(20)
        if (qt.all { a -> lt.any { it.startsWith(a) } }) return 80
        if (l.contains(q)) return 70
        if (lt.all { a -> qt.any { it.startsWith(a) } }) return 60
        val d = levenshtein(q.replace(" ", ""), l.replace(" ", ""))
        val limit = if (maxOf(q.length, l.length) <= 5) 1 else 2
        return if (d <= limit) 55 - d else 0
    }

    /** Index of the best matching label, or null when nothing is close enough. */
    fun best(query: String, labels: List<String>): Int? {
        val q = canonical(query)
        if (q.isEmpty()) return null
        var bestIdx = -1
        var bestScore = 49
        for (i in labels.indices) {
            val s = score(q, canonical(labels[i]))
            if (s > bestScore) { bestScore = s; bestIdx = i }
        }
        return if (bestIdx >= 0) bestIdx else null
    }
}
