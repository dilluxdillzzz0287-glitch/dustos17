# DustOS 17 by DeltaX

A native launcher for Amazon Fire TV Sticks and Android TV, written in Kotlin and Jetpack Compose. Frosted-glass
interface, a left sidebar, a featured banner with weather / OSee / device cards beside it, coloured app tiles, a layered
depth-clock screensaver and a small voice assistant called OSee AI. The look follows the ColorOS 17 TV Edition
reference screenshot and Apple TV's glass style; no artwork from either is used (all wallpapers and scenes are drawn in
code, so the APK carries no image or video files except the icon and banner).

## Read this first: what has and has not been checked

This project was written without an Android SDK, so **it has never been compiled and never run on a device.**
Expect to fix a few compile errors on the first build. Nothing below that says NOT TESTED should be trusted yet.

| Area | Status | How it was checked |
|---|---|---|
| Kotlin syntax, all 47 app source files and the test file | PASS | Parsed with the Kotlin compiler's own parser: 0 errors |
| Pure logic: JSON, weather parsing, number formatting, voice-command parser, app-name matching, maths answers, wallpaper and screensaver renderers | PASS | 46 JVM unit tests (`app/src/test`), compiled with kotlinc and run with JUnit |
| Project-internal references: imports of project symbols, argument names and counts of calls to project functions | PASS | Custom checker over the whole source tree; every finding was triaged, none was real |
| Compose rules: composable calls only where Compose allows them (about 1,070 checked), none inside try / catch, `weight` / `align` / `matchParentSize` only in the right Row / Column / Box scope, property-delegate imports | PASS | Custom checker, first proven on deliberately broken code; 0 findings |
| Imports and API names: every import path, Android / Compose constant, named argument and API-level guard | PASS (read by the author) | Read one by one against the Android and Compose APIs; no compiler involved, so a wrong overload could still slip through |
| Resources and manifest: every `@string`, `@style`, `@xml`, icon and banner reference resolves; every class named in the manifest exists | PASS | Scripted check |
| Whole project compiled without the Android and Compose libraries | PARTIAL | About 4,000 "unknown class" errors from the missing libraries. The errors of any other kind were read one by one and all trace back to those missing libraries |
| Wallpaper and screensaver artwork | PASS (looks right) | Rendered to PNG on the JVM and inspected |
| Gradle build: Compose and Android code compiles | NOT TESTED | No Android SDK, Compose libraries or internet available while writing |
| Cloud build workflow (`.github/workflows/build-apk.yml`) | NOT TESTED | The file parses as valid YAML; it has never been run |
| Independent read-through of Compose / Android API usage | NOT DONE | The review run was cut off by a usage limit before it produced anything; the author's own read is the row above |
| Every feature on a real Fire TV Stick or Android TV | NOT TESTED | See the checklist at the end; please report PASS / FAIL for each line |

## Build and install

**Option A: build in the cloud, no Android Studio needed (GitHub Actions, free).** NOT TESTED yet, but it is the
quickest way to get an APK.

1. Make a free GitHub account and a new empty repository (private is fine).
2. Upload the contents of this project so that `gradlew` and the `.github` folder sit at the top level of the
   repository. On a computer: unzip, then in the repository choose Add file > Upload files and drag everything in,
   including the `.github` folder. Some file managers hide folders that start with a dot; if yours does, choose
   Add file > Create new file, type the name `.github/workflows/build-apk.yml` and paste in the text of that file.
   With git: `git init`, `git add .`, `git commit -m dustos`, then push.
3. The build starts by itself after the upload (or: Actions tab > Build DustOS 17 APK > Run workflow). It takes about
   5 to 10 minutes.
4. Open the finished run and download **DustOS17-release-apk** (release builds are normally faster than debug builds on
   weak hardware) or **DustOS17-debug-apk**. Each download is a zip with the `.apk` inside. If the run is red, download
   **build-logs** or copy the red error lines and send them to Claude: those first compile errors are what gets fixed
   next.

**Option B: Android Studio.** Koala (2024.1.1) or newer, JDK 17. Open the `DustOS17` folder and let Gradle sync
(Gradle 8.9, Android Gradle Plugin 8.5.2, Kotlin 2.0.21, Compose BOM 2024.09.03). Build with `./gradlew assembleDebug`
(or `assembleRelease`). Unit tests: `./gradlew test`.

**Install on the Fire TV (either option).** Settings > My Fire TV > Developer options > turn on ADB debugging and Apps
from unknown sources, then from your computer:
```
adb connect <tv-ip-address>:5555
adb install -r app-debug.apk        # or app-release.apk; path from Option B: app/build/outputs/apk/debug/app-debug.apk
```
Open DustOS 17 from "Your Apps & Channels". The first start shows the home page with the sidebar focused.

`minSdk 22` (Fire TV Stick 2nd gen and newer), `targetSdk 33`, `compileSdk 34`. The release build is signed with the
debug key so it can be sideloaded; use your own keystore if you publish it.

## Becoming the Home app on Fire OS (read the limits)

Android has an official "default Home app" mechanism. **Fire OS usually hides it**, and Amazon can change this with any
update. DustOS therefore offers several routes, none of them silent, and reports the real state in Settings > Launcher.

* **Set as Home** (Settings > Launcher): asks Android's role dialog (Android 10+) or opens the Default apps page. Many
  Fire OS builds have neither.
* **Home Guard** (optional accessibility service, off by default): while "Override Home button" is on, it brings DustOS
  back when another launcher's window appears and tries to take the Home key. It never reads text or content on
  screen, stores nothing, and does nothing unless you switch it on. Whether a given Fire OS build passes the Home key to
  an accessibility service, and whether it lets DustOS open from the background, differs by version, so treat it as
  best effort. If DustOS cannot be opened from the background (Android 10+ without "Display over other apps"), the
  guard leaves the Home key alone so it can never become a dead button. "Pause for 10 minutes" in the same page lets you
  use the stock home screen briefly.
* **Open after restart** (Settings > Boot): a boot receiver opens DustOS two seconds after boot. Android 10 and newer
  need "Display over other apps" for this.
* **ADB** (for builds with no settings page; run from your computer, at your own risk, and note that some of these
  are not allowed on every Fire OS version):
  ```
  adb shell appops set team.deltax.dustos17 SYSTEM_ALERT_WINDOW allow      # open from the background
  adb shell appops set team.deltax.dustos17 GET_USAGE_STATS allow          # Recently used across the device
  adb shell pm grant team.deltax.dustos17 android.permission.WRITE_SECURE_SETTINGS   # lets DustOS switch its own Home Guard on and off
  adb shell cmd role add-role-holder --user 0 android.app.role.HOME team.deltax.dustos17   # Android 10+ only
  ```
  DustOS does not disable or uninstall Amazon's launcher and does not need that. People who do it themselves can lose
  Fire TV features and updates may undo it; to undo it: `adb shell pm enable com.amazon.tv.launcher`.

**The Alexa / voice button is not taken over and DustOS never claims to replace Alexa.** On Fire OS that button belongs to
Alexa. OSee opens from the on-screen OSee button, the search icon, the sidebar entry, or (where Android routes them to
the foreground launcher) the assistant / search keys.

## What is in it

* **Home**: sidebar (Home, Apps, Games, Settings, OSee AI), header with brand, live clock, date, Wi-Fi/Ethernet icon;
  featured banner (OSee, Home setup, screensaver, your apps) with dots and a button; cards for weather, OSee and RAM;
  Favourites (editable), Recently used, Recommended, Installed apps. Hold Select on any app for favourites, move,
  show in Games, hide, app info and uninstall. App tiles take their colour from each app's own icon.
  "Recommended" is built from what is on the device (your recent apps, OSee shortcuts, launcher tips). Fire OS gives
  launchers no access to other apps' content feeds, so there is no streaming catalogue and no fake progress bars.
* **Settings** (ColorOS-style, categories on the left): Appearance (6 themes, glass strength, corner roundness),
  Wallpaper (7 procedural wallpapers with previews), Home layout (show or hide each row), Display (UI size, overscan
  safe area), Clock (5 designs, digital or analog, 5 fonts, size, opacity, 3x3 position plus fine offset), Screensaver,
  Weather, System widget, Animations (speed, focus glow, live wallpaper, depth parallax), Launcher, Boot, OSee AI,
  Apps (Android app manager, hidden apps, recently-used access), About.
* **OSee AI**: glass full-screen assistant with animated logo, waveform, listening / thinking / answering states,
  recognised-speech text, spoken replies where a TTS engine exists, follow-up buttons, typed input and example chips.
  Commands: open apps, go to Home / Apps / Games / Settings, open system pages (Wi-Fi, display, sound, Bluetooth,
  app manager), time and date, weather, simple maths, switch clock format / animations / widgets, volume, search content
  (hands the search to a media app or the system search; "handed over" is never reported as "found results"), general
  questions get an honest "I can't answer that on my own" and an offer to search the web, because there is no cloud
  model. The microphone opens only
  after you press Talk (or an assistant key), for one phrase of at most 12 seconds, with a red "Microphone on" badge
  in OSee and an icon in the header; nothing is recorded or stored. Many Fire TV sticks have no speech recognizer; then
  OSee says so and typing and the example chips still work.
* **Screensaver**: starts after 1-60 idle minutes while the launcher is in front, or from Preview. Five built-in layered
  scenes (Aurora Peaks, Desert Dusk, Flux, Cosmos, Neon City) drawn in code; the layers move at different speeds
  (parallax) and the clock sits *between* layers so the foreground can overlap it. Clock style, size, position and
  opacity are shared with the Clock page. Weather strip (temperature, condition, feels like, humidity, wind with
  direction, sunrise / sunset, optional 4-day outlook, place). Depth, speed, dimming, optional "keep the TV awake" (off by
  default). Optional looping video from the app's own folder
  (`Android/data/team.deltax.dustos17/files/screensavers/`, no permission needed; other folders only if Android lets
  DustOS read them; which formats play depends on your device's hardware decoder). Any button wakes it and the same
  press is swallowed, so it never clicks something underneath. It stops drawing when the TV turns off or another app is
  in front. It does not replace Android's own screensaver; set DustOS's delay shorter than the system one.
* **Weather**: Open-Meteo (no key, CC BY 4.0, https://open-meteo.com), cached for offline use, manual place by default
  (Kozhikode), optional coarse location only if you pick Automatic and grant it.
* **RAM and system widget**: real numbers from Android (`ActivityManager.MemoryInfo`, `StatFs`, `/proc` CPU deltas
  where readable, thermal / battery temperature where reported). Small, medium and large, above or below the weather
  card or in its own row, minimal or detailed, hide any statistic, refresh button plus auto-refresh interval. It
  **never claims memory was freed**, never force-stops anything, and has no "boost" button. Since Android 5.1 apps cannot see
  other apps' memory use, so the widget shows what the device really allows and links to Android's own app manager.
  CPU is often not readable on newer Android; the widget then says "not available".

## How it is built

* `core/`: pure Kotlin, no Android classes, unit-tested on the JVM: `MiniJson`, `Weather` (Open-Meteo parsing and WMO
  codes), `Format` (units, clock maths, CPU maths), `Osee` (voice-command parser, app-name matcher), `MathAnswer`,
  `OseeText`, `Wallpaper` (procedural wallpaper renderer and box blur), `SceneArt` (layered screensaver scenes).
* `data/`: preferences (every setting is Compose state backed by SharedPreferences), app scanning and icon cache,
  weather repository, system statistics, video folders.
* `ui/`: Compose only (foundation, animation, ui; no Material). The layout is designed on a 1920 x 1080 canvas and
  scaled, so it matches on 720p, 1080p and 4K sticks. `Glass.kt` has the frosted glass and the D-pad focus modifier.
* `osee/`, `launcher/`: the assistant session, hand-off helpers, boot receiver, Home Guard service, role / settings
  helpers.
* **Frosted glass without live blur**: the wallpaper is rendered once and blurred once; each panel draws its own slice of
  that blurred copy plus a tint, a sheen and a rim. No per-frame blur, which is what keeps it light on a Fire TV Stick.
* **Light on hardware**: no service, worker or thread starts with the app. The idle timer is one Handler callback that
  exists only while the launcher is in front. The wallpaper breathes slowly (one bitmap draw plus a few gradients), loops
  stop when the launcher is not in front, the screensaver replaces the home screen instead of drawing on top of it, and its
  layers are baked once and then only translated (about 30 fps).
* **Focus**: sidebar items preview their page after a short pause; Right from the sidebar goes to the page's first item,
  Left from a page returns to the selected sidebar item; closing a dialog, OSee or the screensaver puts focus back on the
  item you left; the home page remembers its scroll position.

## Manual test checklist (please report PASS / FAIL per line)

1. Build succeeds. (If not, send the first compile errors.)
2. Installs and appears in "Your Apps & Channels"; opens to the home page with the sidebar's Home item focused.
3. D-pad: Right from the sidebar lands on the banner button; Left from any page item returns to the selected sidebar
   item and never switches pages by itself; Up/Down in the sidebar switches Home / Apps / Games / Settings after a moment.
4. Hold Select on an app: the options dialog opens, Back closes it, focus returns to the same tile.
5. Favourites: add, move earlier / later, remove. Hide an app, bring it back from Settings > Apps.
6. Settings: every category opens; changing the theme, glass, corners, UI size and wallpaper takes effect at once.
7. Clock page: all 5 designs, analog, fonts, position; the screensaver clock follows.
8. Screensaver: Preview shows it; any button closes it and does nothing else; it starts by itself after the delay
   (try 1 minute); it stops when you open another app.
9. OSee: opens from the sidebar; typing "open YouTube" or "what time is it" works; Talk shows the red microphone badge
   only while listening, and says so if the device has no recognizer; Close releases the microphone.
10. Weather: shows data after the first refresh, shows "offline" with cached data when the network is off.
11. RAM widget: numbers look plausible next to Settings > My Fire TV > About; Refresh works; no "freed" claims anywhere.
12. Home override: with Home Guard on and overlay permission granted, Home from another app returns to DustOS. This is
    the least certain line; please say which Fire OS version you tested.
13. Boot: turn on "Open DustOS after a restart", reboot, DustOS opens a couple of seconds after the system home screen.
14. Back on the home page stays in DustOS when "Keep Back inside DustOS" is on.

## Credits

Weather data by [Open-Meteo.com](https://open-meteo.com/) (CC BY 4.0). Built on AndroidX, Jetpack Compose and Kotlin
coroutines. DustOS 17 by DeltaX Team.
